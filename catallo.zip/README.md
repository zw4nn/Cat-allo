# Allocat v0.1.6

- Création du chantier avant sélection matériel
- Recherche instantanée dans le chantier
- Clic produit = ajout au panier
- Quantité par - / + ou saisie directe
- Validation puis copie / partage de la liste
- Import / export visible uniquement depuis le catalogue (menu ⋮)
- JSON / CSV / XLSX + modèles vierges
- Stock camion uniquement
- Alertes de stock et copie d’une demande de réassort

applicationId fr.catallo.app
versionCode 7
versionName 0.1.6
