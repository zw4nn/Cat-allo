Allocat v0.1.2
applicationId: fr.catallo.app
versionCode: 3
versionName: 0.1.2
