# Allocat v0.2.2 — Félix réglé

Corrections Félix :
- correction du sens de marche : plus de moonwalk
- marche ralentie
- animations ralenties
- pauses beaucoup plus longues entre deux comportements
- Félix reste parfois posé 7 à 15 secondes
- pause de 3,5 secondes à son apparition
- bouton × réduit à 24 dp
- overlay permanent conservé pendant la navigation

Timings :
- marche : 165 ms par frame
- assis : 360 ms par frame
- poses : 420 ms par frame
- jeu : 250 ms par frame
- traversée écran : 10 à 15 secondes
- repos entre animations : 7 à 15 secondes

Version :
- applicationId : fr.catallo.app
- versionName : 0.2.2
- versionCode : 13
