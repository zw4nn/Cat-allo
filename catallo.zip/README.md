# Allocat v0.1.9 — correctif compilation

Correctifs :
- find(long) restauré
- showShareDialog(Worksite) restauré
- copyText(String,String) restauré
- références Page.* contrôlées
- méthodes dupliquées contrôlées

Conservé :
- fr.catallo.app
- versionCode 10
- versionName 0.1.9
- chantier panier
- stock camion au delta
- exceptions de déduction par produit
- sauvegarde JSON à la sortie
- import/export
- filtres marque/catégorie
