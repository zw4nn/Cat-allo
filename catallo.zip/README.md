# Allocat v0.1.8

Chantiers :
- modification nom / note
- suppression avec confirmation
- menu ⋮ dans chaque chantier

Sauvegarde :
- choix persistant d'un dossier Android
- Google Drive utilisable si proposé par le sélecteur système
- `allocat-backup.json` contient catalogue + chantiers
- sauvegarder maintenant
- restauration
- sauvegarde automatique tentée après les modifications

Signature Android stable à partir de cette version :
- keystore inclus : app/allocat-signing.jks
- alias : allocat
- applicationId : fr.catallo.app
- versionCode : 9
- versionName : 0.1.8
- certificat SHA-256 :
  64:57:6C:8F:09:09:4C:D8:A0:66:B9:D7:D2:05:46:6F:22:49:97:46:75:7D:83:5F:54:15:DF:44:B8:87:7D:2E
- assembleDebug et assembleRelease utilisent cette même clé.

Les APK 0.1.6 et 0.1.7 ont des signatures différentes.
Il faut donc désinstaller une dernière fois l'ancienne version pour installer la 0.1.8.
À partir de 0.1.8, conserver ce keystore permet les mises à jour Android.

Attention : le keystore est inclus dans le ZIP comme demandé. Si le dépôt GitHub est public,
la clé privée est donc publiquement récupérable.

## Ajustement panier v0.1.8
- le dernier produit ajouté ou dont la quantité vient d'être modifiée remonte en tête du panier chantier
