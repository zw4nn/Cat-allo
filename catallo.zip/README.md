# Allocat v0.1.5

- Icône launcher adaptative : chat agrandi réellement
- Import / export JSON
- Import / export CSV
- Import / export Excel XLSX
- Modèle vierge CSV et XLSX même avec catalogue vide
- Import : Ajouter ou Remplacer
- Sélecteur de fichiers Android, aucune permission stockage globale

Colonnes : designation, reference, marque, categorie, alias, mots_cles, unite, stock_camion, stock_agence, stock_mini

applicationId fr.catallo.app
versionCode 6
versionName 0.1.5
AGP 8.6.1 / Gradle 8.7 / Java 17
