# Allocat v0.1.3

Changements :
- catalogue vide par défaut
- logo agrandi sur l'accueil
- fiche matériel réorganisée
- stock séparé Camion / Agence
- vue Stocks avec totaux et alertes
- bouton Retour Android : revient à l'accueil de l'app avant de quitter
- migration des anciennes données : l'ancien stock devient stock camion
- possibilité de vider le catalogue depuis Réglages

Configuration :
- applicationId : fr.catallo.app
- versionCode : 4
- versionName : 0.1.3
- AGP 8.6.1
- workflow : Gradle 8.7 / Java 17
