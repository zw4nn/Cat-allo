# CAT’Allo v0.1.1 — version fonctionnelle

Fonctions incluses :
- Catalogue local hors ligne
- Ajout, modification et suppression de matériel
- Champs : désignation, référence, marque, catégorie, alias, mots-clés, unité
- Recherche multi-champs
- Sélection de matériel avec quantités
- Génération d'un compte rendu chantier
- Copie du texte dans le presse-papiers
- Données persistées localement
- applicationId : fr.catallo.app
- versionCode : 2
- versionName : 0.1.1
