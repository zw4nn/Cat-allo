# Allocat v0.1.4

Refonte UI :
- vraie barre supérieure fixe, placée sous la barre système
- navigation basse compacte
- contenu protégé des barres système Android 15
- logo agrandi dans l'app
- icône launcher recadrée et agrandie au maximum
- ajout / modification du matériel sur une page dédiée
- formulaire organisé en Identification / Stock / Recherche
- stock séparé Camion / Agence
- catalogue vide au premier lancement
- retour Android : fiche/formulaire -> catalogue, autres pages -> accueil

Configuration :
- applicationId : fr.catallo.app
- versionCode : 5
- versionName : 0.1.4
- AGP 8.6.1
- workflow attendu : Gradle 8.7 / Java 17
