# Allocat v0.1.9

Chantiers / stock :
- option à la création du chantier : déduire du stock camion par défaut
- exception possible par produit avec case Stock camion
- rien n'est déduit pendant la préparation
- la déduction se fait à la validation
- mémorisation des quantités déjà déduites
- revalidation idempotente : pas de double retrait
- si quantité augmente : seule la différence est retirée
- si quantité diminue / produit retiré / déduction désactivée : le stock est recrédité

Sauvegarde :
- dossier de sauvegarde configurable dans Réglages
- sauvegarde JSON complète : catalogue + chantiers + états de déduction
- depuis l'accueil, bouton Retour Android :
  - Sauvegarder et quitter
  - Quitter sans sauvegarder
  - Annuler
- sauvegarde manuelle également disponible dans Réglages

Compatibilité :
- applicationId : fr.catallo.app
- versionCode : 10
- versionName : 0.1.9
