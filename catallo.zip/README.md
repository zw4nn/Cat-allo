# Allocat v0.2.0 — Easter egg Félix

Le 7e clic rapide sur le logo depuis l'accueil déclenche désormais le vrai Félix
extrait du programme fourni par l'utilisateur.

Animation :
- 12 images originales de marche
- Félix traverse l'écran de droite à gauche
- animation invisible tant que l'easter egg n'est pas déclenché
- impossible de lancer deux Félix simultanément

Version :
- applicationId : fr.catallo.app
- versionName : 0.2.0
- versionCode : 12

Le versionCode passe à 12 afin que cette révision puisse mettre à jour une éventuelle
v0.2.0 précédente (versionCode 11).
