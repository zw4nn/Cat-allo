# CAT’Allo v0.1.0

Version Android native simplifiée et robuste.

- applicationId : fr.catallo.app
- versionName : 0.1.0
- versionCode : 1
- aucune dépendance AEPG
- aucune dépendance Compose
