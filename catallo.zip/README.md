# Allocat v0.1.7

- Autocomplétion de la marque
- Autocomplétion de la catégorie
- Une nouvelle marque/catégorie peut être saisie librement
- Catégories proposées : Appareillage, Modulaire, Interphone, Contrôle d'accès
- Filtres catalogue par marque et catégorie
- Recherche texte et filtres combinables
- Résultats mis à jour instantanément
- Import/export toujours discret dans le catalogue
- Stock camion uniquement
- Workflow chantier panier conservé

applicationId : fr.catallo.app
versionCode : 8
versionName : 0.1.7
AGP 8.6.1 / Gradle 8.7 / Java 17
