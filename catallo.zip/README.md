# Allocat v0.1.2

- applicationId : fr.catallo.app
- versionCode : 3
- versionName : 0.1.2
- Android Gradle Plugin : 8.6.1
- workflow attendu : Gradle 8.7 + Java 17

Contrôles effectués sur le ZIP :
- structure du projet
- fichiers obligatoires
- XML valides
- cohérence applicationId/version
- package Java
- absence de référence AEPG
- intégrité de l'archive ZIP

Le build Android complet reste exécuté par GitHub Actions.
