# Allocat v0.1.2

Correctif de compilation :
- ClipboardManager explicitement résolu avec android.content.ClipboardManager
- import générique android.text.* supprimé

Configuration :
- applicationId : fr.catallo.app
- namespace : fr.catallo.app
- versionCode : 3
- versionName : 0.1.2
- Android Gradle Plugin : 8.6.1
- workflow attendu : Gradle 8.7 + Java 17

Contrôles effectués :
- structure ZIP
- fichiers obligatoires
- XML valides
- cohérence Gradle / version / package
- packages Java
- accolades Java équilibrées
- absence de références AEPG / CAT'Allo
- branding Allocat
- intégrité ZIP
