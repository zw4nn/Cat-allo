package fr.catallo.app;

import android.content.*;
import org.json.*;
import java.util.*;

public class WorksiteStore {
    private static final String PREF="allocat_store";
    private static final String KEY="worksites";

    public static ArrayList<Worksite> load(Context c){
        ArrayList<Worksite> out=new ArrayList<>();
        String raw=c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString(KEY,"");
        if(raw==null || raw.isEmpty()) return out;

        try{
            JSONArray a=new JSONArray(raw);
            for(int i=0;i<a.length();i++){
                JSONObject o=a.getJSONObject(i);
                Worksite w=new Worksite(
                    o.optLong("id"),
                    o.optString("name"),
                    o.optString("note"),
                    o.optLong("createdAt")
                );
                w.validated=o.optBoolean("validated",false);
                w.deductFromTruck=o.has("deductFromTruck") ? o.optBoolean("deductFromTruck",true) : true;

                JSONObject q=o.optJSONObject("quantities");
                if(q!=null){
                    Iterator<String> it=q.keys();
                    while(it.hasNext()){
                        String k=it.next();
                        try{w.quantities.put(Long.parseLong(k),q.optInt(k,0));}catch(Exception ignored){}
                    }
                }

                JSONObject d=o.optJSONObject("deductOverrides");
                if(d!=null){
                    Iterator<String> it=d.keys();
                    while(it.hasNext()){
                        String k=it.next();
                        try{w.deductOverrides.put(Long.parseLong(k),d.optBoolean(k,true));}catch(Exception ignored){}
                    }
                }

                JSONObject dq=o.optJSONObject("deductedQuantities");
                if(dq!=null){
                    Iterator<String> it=dq.keys();
                    while(it.hasNext()){
                        String k=it.next();
                        try{w.deductedQuantities.put(Long.parseLong(k),dq.optInt(k,0));}catch(Exception ignored){}
                    }
                }

                out.add(w);
            }
        }catch(Exception ignored){}

        return out;
    }

    public static void save(Context c,ArrayList<Worksite> items){
        JSONArray a=new JSONArray();
        try{
            for(Worksite w:items){
                JSONObject o=new JSONObject();
                o.put("id",w.id);
                o.put("name",w.name);
                o.put("note",w.note);
                o.put("createdAt",w.createdAt);
                o.put("validated",w.validated);
                o.put("deductFromTruck",w.deductFromTruck);

                JSONObject q=new JSONObject();
                for(Map.Entry<Long,Integer> e:w.quantities.entrySet())
                    q.put(String.valueOf(e.getKey()),e.getValue());
                o.put("quantities",q);

                JSONObject d=new JSONObject();
                for(Map.Entry<Long,Boolean> e:w.deductOverrides.entrySet())
                    d.put(String.valueOf(e.getKey()),e.getValue());
                o.put("deductOverrides",d);

                JSONObject dq=new JSONObject();
                for(Map.Entry<Long,Integer> e:w.deductedQuantities.entrySet())
                    dq.put(String.valueOf(e.getKey()),e.getValue());
                o.put("deductedQuantities",dq);

                a.put(o);
            }
        }catch(Exception ignored){}

        c.getSharedPreferences(PREF,Context.MODE_PRIVATE)
            .edit().putString(KEY,a.toString()).apply();
    }
}
