package fr.catallo.app;

public class MaterialItem {
    public long id;
    public String name;
    public String reference;
    public String brand;
    public String category;
    public String alias;
    public String keywords;
    public String unit;

    public MaterialItem(long id, String name, String reference, String brand,
                        String category, String alias, String keywords, String unit) {
        this.id = id;
        this.name = name == null ? "" : name;
        this.reference = reference == null ? "" : reference;
        this.brand = brand == null ? "" : brand;
        this.category = category == null ? "" : category;
        this.alias = alias == null ? "" : alias;
        this.keywords = keywords == null ? "" : keywords;
        this.unit = unit == null || unit.trim().isEmpty() ? "u" : unit;
    }

    public boolean matches(String q) {
        if (q == null || q.trim().isEmpty()) return true;
        String s = q.toLowerCase();
        return (name + " " + reference + " " + brand + " " + category + " " + alias + " " + keywords)
                .toLowerCase().contains(s);
    }

    public String subtitle() {
        StringBuilder b = new StringBuilder();
        if (!reference.isEmpty()) b.append(reference);
        if (!brand.isEmpty()) {
            if (b.length() > 0) b.append(" • ");
            b.append(brand);
        }
        if (!category.isEmpty()) {
            if (b.length() > 0) b.append(" • ");
            b.append(category);
        }
        if (!alias.isEmpty()) {
            if (b.length() > 0) b.append(" • ");
            b.append(alias);
        }
        return b.toString();
    }
}
