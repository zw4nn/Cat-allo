package fr.catallo.app;
public class MaterialItem {
 public long id; public String name,reference,brand,category,alias,keywords,unit; public int stock,minStock; public boolean favorite;
 public MaterialItem(long id,String name,String reference,String brand,String category,String alias,String keywords,String unit,int stock,int minStock){this.id=id;this.name=n(name);this.reference=n(reference);this.brand=n(brand);this.category=n(category);this.alias=n(alias);this.keywords=n(keywords);this.unit=n(unit).isEmpty()?"u":n(unit);this.stock=stock;this.minStock=minStock;}
 private static String n(String s){return s==null?"":s;} public boolean matches(String q){if(q==null||q.trim().isEmpty())return true;String x=q.toLowerCase();return(name+" "+reference+" "+brand+" "+category+" "+alias+" "+keywords).toLowerCase().contains(x);} public String displayRef(){return reference.isEmpty()?"Sans référence":"Réf. "+reference;}
}