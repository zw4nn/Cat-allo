package fr.catallo.app;

import android.content.*;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class BackupManager {
    public static final String FILE_NAME="allocat-backup.json";

    public static class BackupData {
        public ArrayList<MaterialItem> materials=new ArrayList<>();
        public ArrayList<Worksite> worksites=new ArrayList<>();
    }

    public static void save(Context c, Uri treeUri, ArrayList<MaterialItem> materials, ArrayList<Worksite> worksites) throws Exception {
        Uri file=findOrCreate(c,treeUri,FILE_NAME);
        OutputStream out=c.getContentResolver().openOutputStream(file,"wt");
        if(out==null) throw new IOException("Impossible d'écrire la sauvegarde");

        JSONObject root=new JSONObject();
        root.put("format","allocat-backup");
        root.put("version",1);
        root.put("createdAt",System.currentTimeMillis());

        JSONArray mats=new JSONArray();
        for(MaterialItem m:materials){
            JSONObject o=new JSONObject();
            o.put("id",m.id); o.put("name",m.name); o.put("reference",m.reference);
            o.put("brand",m.brand); o.put("category",m.category); o.put("alias",m.alias);
            o.put("keywords",m.keywords); o.put("unit",m.unit); o.put("stockCamion",m.stockCamion);
            o.put("minStock",m.minStock); o.put("favorite",m.favorite); mats.put(o);
        }
        root.put("materials",mats);

        JSONArray sites=new JSONArray();
        for(Worksite w:worksites){
            JSONObject o=new JSONObject();
            o.put("id",w.id); o.put("name",w.name); o.put("note",w.note);
            o.put("createdAt",w.createdAt); o.put("validated",w.validated);
            JSONObject q=new JSONObject();
            for(Map.Entry<Long,Integer> e:w.quantities.entrySet()) q.put(String.valueOf(e.getKey()),e.getValue());
            o.put("quantities",q); sites.put(o);
        }
        root.put("worksites",sites);

        out.write(root.toString(2).getBytes(StandardCharsets.UTF_8));
        out.close();
    }

    public static BackupData restore(Context c,Uri treeUri)throws Exception{
        Uri file=find(c,treeUri,FILE_NAME);
        if(file==null) throw new FileNotFoundException(FILE_NAME+" introuvable");

        InputStream in=c.getContentResolver().openInputStream(file);
        if(in==null) throw new IOException("Impossible de lire la sauvegarde");
        ByteArrayOutputStream out=new ByteArrayOutputStream();
        byte[] buf=new byte[8192]; int n;
        while((n=in.read(buf))>0) out.write(buf,0,n);
        in.close();

        JSONObject root=new JSONObject(new String(out.toByteArray(),StandardCharsets.UTF_8));
        if(!"allocat-backup".equals(root.optString("format"))) throw new IOException("Sauvegarde Allocat invalide");

        BackupData data=new BackupData();

        JSONArray mats=root.optJSONArray("materials");
        if(mats!=null) for(int i=0;i<mats.length();i++){
            JSONObject o=mats.getJSONObject(i);
            MaterialItem m=new MaterialItem(
                o.optLong("id",System.nanoTime()),o.optString("name"),o.optString("reference"),
                o.optString("brand"),o.optString("category"),o.optString("alias"),o.optString("keywords"),
                o.optString("unit","u"),o.optInt("stockCamion",0),o.optInt("minStock",0)
            );
            m.favorite=o.optBoolean("favorite",false);
            data.materials.add(m);
        }

        JSONArray sites=root.optJSONArray("worksites");
        if(sites!=null) for(int i=0;i<sites.length();i++){
            JSONObject o=sites.getJSONObject(i);
            Worksite w=new Worksite(
                o.optLong("id",System.nanoTime()),o.optString("name"),o.optString("note"),
                o.optLong("createdAt",System.currentTimeMillis())
            );
            w.validated=o.optBoolean("validated",false);
            JSONObject q=o.optJSONObject("quantities");
            if(q!=null){
                Iterator<String> it=q.keys();
                while(it.hasNext()){
                    String k=it.next();
                    try{w.quantities.put(Long.parseLong(k),q.optInt(k));}catch(Exception ignored){}
                }
            }
            data.worksites.add(w);
        }
        return data;
    }

    private static Uri findOrCreate(Context c,Uri tree,String name)throws Exception{
        Uri found=find(c,tree,name);
        if(found!=null)return found;
        String parent=DocumentsContract.getTreeDocumentId(tree);
        Uri parentUri=DocumentsContract.buildDocumentUriUsingTree(tree,parent);
        Uri created=DocumentsContract.createDocument(c.getContentResolver(),parentUri,"application/json",name);
        if(created==null)throw new IOException("Impossible de créer "+name);
        return created;
    }

    private static Uri find(Context c,Uri tree,String name)throws Exception{
        String parent=DocumentsContract.getTreeDocumentId(tree);
        Uri children=DocumentsContract.buildChildDocumentsUriUsingTree(tree,parent);
        String[] projection={DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME};

        Cursor cur=c.getContentResolver().query(children,projection,null,null,null);
        if(cur==null)return null;
        try{
            while(cur.moveToNext()){
                if(name.equals(cur.getString(1))){
                    return DocumentsContract.buildDocumentUriUsingTree(tree,cur.getString(0));
                }
            }
        }finally{cur.close();}
        return null;
    }
}
