package fr.catallo.app;

import android.content.*;
import android.net.Uri;
import androidx.documentfile.provider.DocumentFile;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;

public class BackupManager {
    private static final String PREF="allocat_backup";
    private static final String KEY_URI="folder_uri";

    public static void setFolder(Context c, Uri uri){
        c.getSharedPreferences(PREF,Context.MODE_PRIVATE)
            .edit().putString(KEY_URI,uri.toString()).apply();
    }

    public static Uri getFolder(Context c){
        String raw=c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString(KEY_URI,"");
        if(raw==null || raw.isEmpty()) return null;
        try{return Uri.parse(raw);}catch(Exception e){return null;}
    }

    public static String folderLabel(Context c){
        Uri uri=getFolder(c);
        if(uri==null) return "Non défini";
        try{
            DocumentFile d=DocumentFile.fromTreeUri(c,uri);
            if(d!=null && d.getName()!=null) return d.getName();
        }catch(Exception ignored){}
        return uri.toString();
    }

    public static String save(
        Context c,
        ArrayList<MaterialItem> materials,
        ArrayList<Worksite> worksites
    ) throws Exception {
        Uri tree=getFolder(c);
        if(tree==null) throw new IOException("Aucun dossier de sauvegarde défini");

        DocumentFile dir=DocumentFile.fromTreeUri(c,tree);
        if(dir==null || !dir.canWrite()) throw new IOException("Dossier de sauvegarde non accessible");

        JSONObject root=new JSONObject();
        root.put("format","allocat-backup");
        root.put("version",1);
        root.put("createdAt",System.currentTimeMillis());

        JSONArray mats=new JSONArray();
        for(MaterialItem m:materials){
            JSONObject o=new JSONObject();
            o.put("id",m.id);
            o.put("designation",m.name);
            o.put("reference",m.reference);
            o.put("marque",m.brand);
            o.put("categorie",m.category);
            o.put("alias",m.alias);
            o.put("mots_cles",m.keywords);
            o.put("unite",m.unit);
            o.put("stock_camion",m.stockCamion);
            o.put("stock_mini",m.minStock);
            mats.put(o);
        }
        root.put("materiel",mats);

        JSONArray ws=new JSONArray();
        for(Worksite w:worksites){
            JSONObject o=new JSONObject();
            o.put("id",w.id);
            o.put("name",w.name);
            o.put("note",w.note);
            o.put("createdAt",w.createdAt);
            o.put("validated",w.validated);
            o.put("deductFromTruck",w.deductFromTruck);

            JSONObject q=new JSONObject();
            for(Map.Entry<Long,Integer> e:w.quantities.entrySet())
                q.put(String.valueOf(e.getKey()),e.getValue());
            o.put("quantities",q);

            JSONObject ov=new JSONObject();
            for(Map.Entry<Long,Boolean> e:w.deductOverrides.entrySet())
                ov.put(String.valueOf(e.getKey()),e.getValue());
            o.put("deductOverrides",ov);

            JSONObject dq=new JSONObject();
            for(Map.Entry<Long,Integer> e:w.deductedQuantities.entrySet())
                dq.put(String.valueOf(e.getKey()),e.getValue());
            o.put("deductedQuantities",dq);

            ws.put(o);
        }
        root.put("chantiers",ws);

        String date=new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss",Locale.FRANCE).format(new Date());
        String filename="allocat-backup_"+date+".json";

        DocumentFile file=dir.createFile("application/json",filename);
        if(file==null) throw new IOException("Impossible de créer le fichier de sauvegarde");

        OutputStream out=c.getContentResolver().openOutputStream(file.getUri(),"w");
        if(out==null) throw new IOException("Impossible d'écrire la sauvegarde");

        out.write(root.toString(2).getBytes(StandardCharsets.UTF_8));
        out.flush();
        out.close();

        return file.getName()==null ? filename : file.getName();
    }
}
