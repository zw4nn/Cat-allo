package fr.catallo.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.*;

public class MainActivity extends Activity {

    private final int PINK = Color.rgb(255,79,163);
    private final int BG = Color.rgb(11,14,19);
    private final int CARD = Color.rgb(22,26,35);
    private final int SOFT = Color.rgb(185,191,202);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(24));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout titleBox = new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);

        TextView title = text("CAT’Allo", 30, Color.WHITE, true);
        TextView subtitle = text("Catalogue • Matériel • Chantiers", 13, SOFT, false);

        titleBox.addView(title);
        titleBox.addView(subtitle);

        header.addView(titleBox, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));

        TextView version = text("v0.1.0", 13, PINK, true);
        version.setGravity(Gravity.CENTER);
        version.setPadding(dp(12), dp(8), dp(12), dp(8));
        version.setBackground(round(Color.rgb(44,27,40), 14));
        header.addView(version);

        root.addView(header);

        ImageView logo = new ImageView(this);
        logo.setImageResource(fr.catallo.app.R.drawable.catallo_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        LinearLayout.LayoutParams lpLogo = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(175));
        lpLogo.topMargin = dp(18);
        root.addView(logo, lpLogo);

        TextView prompt = text("Que cherches-tu ?", 19, Color.WHITE, true);
        LinearLayout.LayoutParams lpPrompt = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lpPrompt.topMargin = dp(20);
        root.addView(prompt, lpPrompt);

        EditText search = new EditText(this);
        search.setHint("BP Plexo, ventouse, relais, câble…");
        search.setHintTextColor(Color.rgb(130,136,146));
        search.setTextColor(Color.WHITE);
        search.setSingleLine(true);
        search.setPadding(dp(16), dp(14), dp(16), dp(14));
        search.setBackground(round(Color.rgb(27,31,41), 18));
        LinearLayout.LayoutParams lpSearch = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lpSearch.topMargin = dp(10);
        root.addView(search, lpSearch);

        root.addView(card("📦", "Mon matériel", "Catalogue, références et stock"), cardParams());
        root.addView(card("🏗", "Mes chantiers", "Matériel utilisé par site"), cardParams());
        root.addView(card("📝", "Compte rendu", "Préparer et retrouver les comptes rendus chantier"), cardParams());

        TextView footer = text("CAT’Allo • v0.1.0", 12, Color.GRAY, false);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lpFooter = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lpFooter.topMargin = dp(24);
        root.addView(footer, lpFooter);

        scroll.addView(root);
        setContentView(scroll);
    }

    private LinearLayout card(String icon, String title, String subtitle) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(18), dp(18), dp(18));
        box.setBackground(round(CARD, 22));

        TextView iconView = text(icon, 28, Color.WHITE, false);
        TextView titleView = text(title, 19, Color.WHITE, true);
        TextView subtitleView = text(subtitle, 13, SOFT, false);

        box.addView(iconView);

        LinearLayout.LayoutParams t = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        t.topMargin = dp(8);
        box.addView(titleView, t);

        LinearLayout.LayoutParams s = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        s.topMargin = dp(5);
        box.addView(subtitleView, s);

        Button button = new Button(this);
        button.setText("Ouvrir");
        button.setTextColor(Color.WHITE);
        button.setAllCaps(false);
        button.setTextSize(14);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setBackground(round(PINK, 14));

        LinearLayout.LayoutParams b = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(48));
        b.topMargin = dp(14);
        box.addView(button, b);

        return box;
    }

    private LinearLayout.LayoutParams cardParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(14);
        return p;
    }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView tv = new TextView(this);
        tv.setText(value);
        tv.setTextSize(sp);
        tv.setTextColor(color);
        if (bold) tv.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return tv;
    }

    private GradientDrawable round(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
