package fr.catallo.app;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.*;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {

    private final int NAVY = Color.rgb(27,36,48);
    private final int NAVY2 = Color.rgb(39,51,66);
    private final int BG = Color.rgb(238,242,245);
    private final int CARD = Color.WHITE;
    private final int BORDER = Color.rgb(214,222,229);
    private final int TEXT = Color.rgb(31,42,54);
    private final int MUTED = Color.rgb(105,117,129);
    private final int ACCENT = Color.rgb(54,112,130);

    private LinearLayout root, content;
    private TextView title, badge;
    private Button tabCatalogue, tabSelection, tabReport;
    private EditText search;
    private ArrayList<MaterialItem> materials;
    private LinkedHashMap<Long,Integer> selection = new LinkedHashMap<>();

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        materials = LocalStore.load(this);
        buildShell();
        showCatalogue();
    }

    private void buildShell() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setBackgroundColor(BG);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(18), dp(14), dp(14), dp(14));
        header.setBackgroundColor(NAVY);

        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.VERTICAL);
        title = text("CAT’Allo", 27, Color.WHITE, true);
        TextView sub = text("Catalogue matériel • chantier", 12, Color.rgb(196,205,214), false);
        brand.addView(title); brand.addView(sub);
        header.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));

        badge = text("v0.1.1", 12, Color.WHITE, true);
        badge.setPadding(dp(10),dp(7),dp(10),dp(7));
        badge.setBackground(round(NAVY2, 12));
        header.addView(badge);
        page.addView(header);

        LinearLayout tabs = new LinearLayout(this);
        tabs.setPadding(dp(10),dp(8),dp(10),dp(8));
        tabs.setBackgroundColor(Color.WHITE);
        tabCatalogue = navButton("Catalogue");
        tabSelection = navButton("Sélection");
        tabReport = navButton("Compte rendu");
        tabs.addView(tabCatalogue, new LinearLayout.LayoutParams(0, dp(44),1));
        tabs.addView(tabSelection, new LinearLayout.LayoutParams(0, dp(44),1));
        tabs.addView(tabReport, new LinearLayout.LayoutParams(0, dp(44),1));
        page.addView(tabs);

        tabCatalogue.setOnClickListener(v -> showCatalogue());
        tabSelection.setOnClickListener(v -> showSelection());
        tabReport.setOnClickListener(v -> showReport());

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(14),dp(14),dp(14),dp(30));
        scroll.addView(content);
        page.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));

        setContentView(page);
    }

    private void clearContent() { content.removeAllViews(); updateTabs(); }

    private void updateTabs() {
        tabSelection.setText("Sélection (" + selection.size() + ")");
        tabCatalogue.setBackgroundColor(Color.TRANSPARENT);
        tabSelection.setBackgroundColor(Color.TRANSPARENT);
        tabReport.setBackgroundColor(Color.TRANSPARENT);
    }

    private void showCatalogue() {
        clearContent();
        tabCatalogue.setBackground(round(Color.rgb(228,236,240), 12));

        LinearLayout heading = new LinearLayout(this);
        heading.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.addView(text("Catalogue",22,TEXT,true));
        texts.addView(text(materials.size()+" référence(s) enregistrée(s)",12,MUTED,false));
        heading.addView(texts,new LinearLayout.LayoutParams(0,-2,1));
        Button add = compactButton("+ Ajouter");
        add.setOnClickListener(v -> editMaterial(null));
        heading.addView(add);
        content.addView(heading);

        search = new EditText(this);
        search.setHint("Rechercher : réf, marque, catégorie, alias…");
        search.setSingleLine(true);
        search.setTextColor(TEXT);
        search.setHintTextColor(Color.rgb(145,154,164));
        search.setPadding(dp(14),dp(12),dp(14),dp(12));
        search.setBackground(roundStroke(Color.WHITE,BORDER,16,1));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1,-2);
        sp.topMargin=dp(14); content.addView(search,sp);

        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,-2);
        lp.topMargin=dp(12); content.addView(list,lp);

        Runnable refresh = () -> renderCatalogueList(list, search.getText().toString());
        search.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int b,int c){ refresh.run(); }
            public void afterTextChanged(Editable e){}
        });
        refresh.run();
    }

    private void renderCatalogueList(LinearLayout list, String q) {
        list.removeAllViews();
        int count=0;
        for(MaterialItem m: materials) {
            if(!m.matches(q)) continue;
            count++;
            LinearLayout card = card();

            TextView name = text(m.name,17,TEXT,true);
            card.addView(name);
            String sub = m.subtitle();
            if(!sub.isEmpty()) {
                TextView st = text(sub,12,MUTED,false);
                LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2); p.topMargin=dp(4);
                card.addView(st,p);
            }

            LinearLayout actions = new LinearLayout(this);
            actions.setGravity(Gravity.CENTER_VERTICAL);
            actions.setPadding(0,dp(12),0,0);

            Button minus = tinyButton("−");
            TextView qty = text(String.valueOf(selection.getOrDefault(m.id,0)),16,TEXT,true);
            qty.setGravity(Gravity.CENTER);
            Button plus = tinyButton("+");
            Button edit = tinyButton("Modifier");

            minus.setOnClickListener(v -> {
                int n=selection.getOrDefault(m.id,0);
                if(n<=1) selection.remove(m.id); else selection.put(m.id,n-1);
                qty.setText(String.valueOf(selection.getOrDefault(m.id,0)));
                updateTabs();
            });
            plus.setOnClickListener(v -> {
                int n=selection.getOrDefault(m.id,0)+1;
                selection.put(m.id,n); qty.setText(String.valueOf(n)); updateTabs();
            });
            edit.setOnClickListener(v -> editMaterial(m));

            actions.addView(minus,new LinearLayout.LayoutParams(dp(48),dp(42)));
            actions.addView(qty,new LinearLayout.LayoutParams(dp(54),dp(42)));
            actions.addView(plus,new LinearLayout.LayoutParams(dp(48),dp(42)));
            LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(0,dp(42),1); ep.leftMargin=dp(10);
            actions.addView(edit,ep);
            card.addView(actions);

            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1,-2); cp.bottomMargin=dp(10);
            list.addView(card,cp);
        }
        if(count==0) {
            TextView empty=text("Aucun matériel trouvé.",15,MUTED,false);
            empty.setGravity(Gravity.CENTER); empty.setPadding(0,dp(30),0,0); list.addView(empty);
        }
    }

    private void showSelection() {
        clearContent();
        tabSelection.setBackground(round(Color.rgb(228,236,240), 12));
        content.addView(text("Sélection chantier",22,TEXT,true));

        if(selection.isEmpty()) {
            TextView empty=text("Aucun matériel sélectionné.\nAjoute des éléments depuis le catalogue.",15,MUTED,false);
            empty.setGravity(Gravity.CENTER); empty.setPadding(0,dp(45),0,0); content.addView(empty);
            return;
        }

        for(Map.Entry<Long,Integer> e: new ArrayList<>(selection.entrySet())) {
            MaterialItem m=find(e.getKey()); if(m==null) continue;
            LinearLayout card=card();
            LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
            LinearLayout info=new LinearLayout(this); info.setOrientation(LinearLayout.VERTICAL);
            info.addView(text(m.alias.isEmpty()?m.name:m.alias,16,TEXT,true));
            info.addView(text((m.reference.isEmpty()?"Sans référence":m.reference)+" • "+e.getValue()+" "+m.unit,12,MUTED,false));
            row.addView(info,new LinearLayout.LayoutParams(0,-2,1));

            Button minus=tinyButton("−"), plus=tinyButton("+"), del=tinyButton("×");
            TextView qty=text(String.valueOf(e.getValue()),15,TEXT,true); qty.setGravity(Gravity.CENTER);
            minus.setOnClickListener(v->{int n=selection.getOrDefault(m.id,0); if(n<=1)selection.remove(m.id);else selection.put(m.id,n-1);showSelection();});
            plus.setOnClickListener(v->{selection.put(m.id,selection.getOrDefault(m.id,0)+1);showSelection();});
            del.setOnClickListener(v->{selection.remove(m.id);showSelection();});
            row.addView(minus,new LinearLayout.LayoutParams(dp(42),dp(40)));
            row.addView(qty,new LinearLayout.LayoutParams(dp(42),dp(40)));
            row.addView(plus,new LinearLayout.LayoutParams(dp(42),dp(40)));
            LinearLayout.LayoutParams dlp=new LinearLayout.LayoutParams(dp(42),dp(40)); dlp.leftMargin=dp(8); row.addView(del,dlp);
            card.addView(row);
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.topMargin=dp(10);content.addView(card,cp);
        }

        Button next=primaryButton("Générer le compte rendu");
        next.setOnClickListener(v->showReport());
        LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,dp(50));np.topMargin=dp(16);content.addView(next,np);
    }

    private void showReport() {
        clearContent();
        tabReport.setBackground(round(Color.rgb(228,236,240), 12));
        content.addView(text("Compte rendu",22,TEXT,true));

        EditText chantier = field("Nom / site du chantier");
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1,-2); fp.topMargin=dp(14);
        content.addView(chantier,fp);

        EditText notes = field("Notes complémentaires");
        notes.setMinLines(3); notes.setSingleLine(false);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1,-2); np.topMargin=dp(10);
        content.addView(notes,np);

        EditText output = field("");
        output.setMinLines(10); output.setSingleLine(false); output.setTextIsSelectable(true);
        LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(-1,-2); op.topMargin=dp(12);
        content.addView(output,op);

        Button generate=primaryButton("Générer");
        generate.setOnClickListener(v -> output.setText(buildReport(chantier.getText().toString(),notes.getText().toString())));
        LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(-1,dp(50));gp.topMargin=dp(12);content.addView(generate,gp);

        Button copy=secondaryButton("Copier le texte");
        copy.setOnClickListener(v -> {
            String t=output.getText().toString();
            if(t.trim().isEmpty()) t=buildReport(chantier.getText().toString(),notes.getText().toString());
            output.setText(t);
            ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("CAT'Allo compte rendu",t));
            Toast.makeText(this,"Compte rendu copié",Toast.LENGTH_SHORT).show();
        });
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(50));cp.topMargin=dp(8);content.addView(copy,cp);
    }

    private String buildReport(String chantier,String notes) {
        StringBuilder b=new StringBuilder();
        if(!chantier.trim().isEmpty()) b.append("Chantier : ").append(chantier.trim()).append("\n\n");
        b.append("Matériel :\n");
        if(selection.isEmpty()) b.append("- Aucun matériel sélectionné\n");
        for(Map.Entry<Long,Integer> e:selection.entrySet()){
            MaterialItem m=find(e.getKey()); if(m==null)continue;
            b.append("- ").append(e.getValue()).append(" ").append(m.unit).append(" × ")
             .append(m.alias.isEmpty()?m.name:m.alias);
            if(!m.reference.isEmpty()) b.append(" (").append(m.reference).append(")");
            b.append("\n");
        }
        if(!notes.trim().isEmpty()) b.append("\nNotes :\n").append(notes.trim()).append("\n");
        return b.toString();
    }

    private void editMaterial(MaterialItem original) {
        LinearLayout form=new LinearLayout(this); form.setOrientation(LinearLayout.VERTICAL); form.setPadding(dp(20),dp(6),dp(20),0);
        EditText name=dialogField("Désignation", original==null?"":original.name);
        EditText ref=dialogField("Référence", original==null?"":original.reference);
        EditText brand=dialogField("Marque", original==null?"":original.brand);
        EditText cat=dialogField("Catégorie", original==null?"":original.category);
        EditText alias=dialogField("Nom court / alias", original==null?"":original.alias);
        EditText keys=dialogField("Mots-clés", original==null?"":original.keywords);
        EditText unit=dialogField("Unité (u, m, ml…)", original==null?"u":original.unit);
        for(EditText e:new EditText[]{name,ref,brand,cat,alias,keys,unit}) form.addView(e);

        AlertDialog dlg=new AlertDialog.Builder(this)
            .setTitle(original==null?"Ajouter du matériel":"Modifier le matériel")
            .setView(form)
            .setNegativeButton("Annuler",null)
            .setPositiveButton("Enregistrer",null)
            .create();

        if(original!=null) dlg.setButton(AlertDialog.BUTTON_NEUTRAL,"Supprimer",(d,w)->{});
        dlg.setOnShowListener(x -> {
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                if(name.getText().toString().trim().isEmpty()) {
                    name.setError("Désignation obligatoire"); return;
                }
                if(original==null) {
                    long id=System.currentTimeMillis();
                    materials.add(new MaterialItem(id,name.getText().toString().trim(),ref.getText().toString().trim(),
                      brand.getText().toString().trim(),cat.getText().toString().trim(),alias.getText().toString().trim(),
                      keys.getText().toString().trim(),unit.getText().toString().trim()));
                } else {
                    original.name=name.getText().toString().trim();
                    original.reference=ref.getText().toString().trim();
                    original.brand=brand.getText().toString().trim();
                    original.category=cat.getText().toString().trim();
                    original.alias=alias.getText().toString().trim();
                    original.keywords=keys.getText().toString().trim();
                    original.unit=unit.getText().toString().trim().isEmpty()?"u":unit.getText().toString().trim();
                }
                LocalStore.save(this,materials); dlg.dismiss(); showCatalogue();
            });
            if(original!=null) {
                dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setTextColor(Color.rgb(170,55,55));
                dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> {
                    new AlertDialog.Builder(this).setTitle("Supprimer ?")
                      .setMessage(original.name)
                      .setNegativeButton("Annuler",null)
                      .setPositiveButton("Supprimer",(d,w)->{
                          selection.remove(original.id); materials.remove(original); LocalStore.save(this,materials);
                          dlg.dismiss(); showCatalogue();
                      }).show();
                });
            }
        });
        dlg.show();
    }

    private MaterialItem find(long id){for(MaterialItem m:materials)if(m.id==id)return m;return null;}

    private LinearLayout card(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.VERTICAL);v.setPadding(dp(16),dp(14),dp(16),dp(14));v.setBackground(roundStroke(CARD,BORDER,18,1));return v;}
    private Button navButton(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(TEXT);b.setTextSize(12);b.setBackgroundColor(Color.TRANSPARENT);return b;}
    private Button compactButton(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setTextSize(13);b.setBackground(round(ACCENT,12));return b;}
    private Button tinyButton(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(TEXT);b.setTextSize(13);b.setPadding(2,2,2,2);b.setBackground(round(Color.rgb(231,236,240),10));return b;}
    private Button primaryButton(String s){Button b=compactButton(s);b.setTextSize(14);return b;}
    private Button secondaryButton(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(TEXT);b.setBackground(roundStroke(Color.WHITE,BORDER,14,1));return b;}
    private EditText field(String hint){EditText e=new EditText(this);e.setHint(hint);e.setTextColor(TEXT);e.setHintTextColor(Color.rgb(140,150,160));e.setPadding(dp(14),dp(12),dp(14),dp(12));e.setBackground(roundStroke(Color.WHITE,BORDER,14,1));return e;}
    private EditText dialogField(String hint,String value){EditText e=field(hint);e.setText(value);e.setSingleLine(true);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(8);e.setLayoutParams(p);return e;}
    private TextView text(String s,int sp,int color,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextSize(sp);v.setTextColor(color);if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;}
    private GradientDrawable round(int c,int r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(r));return d;}
    private GradientDrawable roundStroke(int c,int sc,int r,int sw){GradientDrawable d=round(c,r);d.setStroke(dp(sw),sc);return d;}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
}
