package fr.catallo.app;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.net.Uri;
import android.text.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private final int BG=Color.rgb(246,248,252),WHITE=Color.WHITE,TEXT=Color.rgb(25,39,64),MUTED=Color.rgb(96,111,135),BLUE=Color.rgb(52,96,181),BLUE_SOFT=Color.rgb(228,235,249),BORDER=Color.rgb(222,228,237),GREEN=Color.rgb(37,132,101),ORANGE=Color.rgb(190,111,45);
    private LinearLayout topBar,content,bottomBar;
    private ArrayList<MaterialItem> materials;
    private ArrayList<Worksite> worksites;
    private Worksite current;
    private long lastTouchedMaterialId=-1L;
    private enum Page{HOME,CATALOGUE,EDIT,WORKSITES,CART,STOCK,SETTINGS}
    private Page page=Page.HOME;
    private static final int REQ_IMPORT=501,REQ_EXPORT=502,REQ_BACKUP_FOLDER=601;
    private boolean exitAfterFolderSelection=false;
    private String pendingFormat="json"; private boolean pendingTemplate=false;

    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(WHITE);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);materials=LocalStore.load(this);worksites=WorksiteStore.load(this);buildShell();showHome();}

    private void buildShell(){
        LinearLayout shell=new LinearLayout(this);shell.setOrientation(LinearLayout.VERTICAL);shell.setBackgroundColor(BG);
        topBar=new LinearLayout(this);topBar.setGravity(Gravity.CENTER_VERTICAL);topBar.setPadding(dp(16),dp(8),dp(14),dp(8));shell.addView(topBar,new LinearLayout.LayoutParams(-1,dp(72)));
        ScrollView sc=new ScrollView(this);sc.setFillViewport(true);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(16),dp(10),dp(16),dp(24));sc.addView(content);shell.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        bottomBar=new LinearLayout(this);bottomBar.setGravity(Gravity.CENTER);bottomBar.setBackgroundColor(WHITE);bottomBar.setPadding(dp(6),dp(4),dp(6),dp(4));shell.addView(bottomBar,new LinearLayout.LayoutParams(-1,dp(58)));
        shell.setOnApplyWindowInsetsListener((v,i)->{v.setPadding(0,i.getSystemWindowInsetTop(),0,i.getSystemWindowInsetBottom());return i;});setContentView(shell);renderBottom(0);
    }

    @Override public void onBackPressed(){
        if(page!=Page.HOME){
            if(page==Page.CART){
                showWorksites();
            }else{
                showHome();
            }
            return;
        }

        new AlertDialog.Builder(this)
            .setTitle("Quitter Allocat")
            .setMessage("Créer une sauvegarde JSON avant de quitter ?")
            .setNegativeButton("Annuler",null)
            .setNeutralButton("Quitter sans sauvegarder",(d,w)->finish())
            .setPositiveButton("Sauvegarder et quitter",(d,w)->saveAndExit())
            .show();
    }

    private void saveAndExit(){
        if(BackupManager.getFolder(this)==null){
            exitAfterFolderSelection=true;
            chooseBackupFolder();
            return;
        }

        try{
            String filename=BackupManager.save(this,materials,worksites);
            Toast.makeText(this,"Sauvegarde créée : "+filename,Toast.LENGTH_SHORT).show();
            finish();
        }catch(Exception e){
            new AlertDialog.Builder(this)
                .setTitle("Sauvegarde impossible")
                .setMessage(e.getMessage()==null?e.toString():e.getMessage())
                .setNegativeButton("Annuler",null)
                .setNeutralButton("Quitter sans sauvegarder",(d,w)->finish())
                .setPositiveButton("Changer de dossier",(d,w)->{
                    exitAfterFolderSelection=true;
                    chooseBackupFolder();
                })
                .show();
        }
    }

    private void chooseBackupFolder(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION |
            Intent.FLAG_GRANT_WRITE_URI_PERMISSION |
            Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION |
            Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
        );
        startActivityForResult(i,REQ_BACKUP_FOLDER);
    }


    private void setTopHome(){topBar.removeAllViews();ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.allocat_logo);logo.setScaleType(ImageView.ScaleType.CENTER_CROP);topBar.addView(logo,new LinearLayout.LayoutParams(dp(54),dp(54)));LinearLayout tx=new LinearLayout(this);tx.setOrientation(LinearLayout.VERTICAL);tx.setPadding(dp(10),0,0,0);tx.addView(t("Allocat",25,TEXT,true));tx.addView(t("Matériel & chantiers",11,MUTED,false));topBar.addView(tx,new LinearLayout.LayoutParams(0,-2,1));TextView v=t("0.1.9",11,BLUE,true);v.setPadding(dp(9),dp(6),dp(9),dp(6));v.setBackground(round(BLUE_SOFT,14));topBar.addView(v);}
    private void setTop(String title,String sub,Runnable back,String action,Runnable actionRun){topBar.removeAllViews();if(back!=null){TextView b=t("‹",34,TEXT,false);b.setGravity(Gravity.CENTER);b.setOnClickListener(v->back.run());topBar.addView(b,new LinearLayout.LayoutParams(dp(42),dp(50)));}LinearLayout tx=new LinearLayout(this);tx.setOrientation(LinearLayout.VERTICAL);tx.addView(t(title,20,TEXT,true));if(sub!=null&&!sub.isEmpty())tx.addView(t(sub,11,MUTED,false));topBar.addView(tx,new LinearLayout.LayoutParams(0,-2,1));if(action!=null){Button a=mini(action);a.setOnClickListener(v->actionRun.run());topBar.addView(a,new LinearLayout.LayoutParams(-2,dp(40)));}}
    private void renderBottom(int selected){bottomBar.removeAllViews();String[] names={"Accueil","Catalogue","Chantiers","Réglages"};String[] icons={"⌂","▣","♜","⚙"};for(int i=0;i<4;i++){int idx=i;LinearLayout item=new LinearLayout(this);item.setGravity(Gravity.CENTER);int c=i==selected?BLUE:MUTED;item.addView(t(icons[i],16,c,true));TextView l=t(names[i],10,c,i==selected);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,-2);lp.leftMargin=dp(4);item.addView(l,lp);if(i==selected)item.setBackground(round(BLUE_SOFT,14));item.setOnClickListener(v->{if(idx==0)showHome();else if(idx==1)showCatalogue();else if(idx==2)showWorksites();else showSettings();});bottomBar.addView(item,new LinearLayout.LayoutParams(0,dp(42),1));}}
    private void clear(){content.removeAllViews();}

    private void showHome(){page=Page.HOME;setTopHome();renderBottom(0);clear();content.addView(homeCard("♜","Mes chantiers","Créer un chantier puis composer la liste installée",this::showWorksites));content.addView(homeCard("▣","Catalogue","Références et stock camion",this::showCatalogue),gap(10));content.addView(homeCard("▥","Stock camion","Niveaux et alertes de réassort",this::showStock),gap(10));}
    private LinearLayout homeCard(String ic,String title,String sub,Runnable r){LinearLayout c=card();c.setPadding(dp(15),dp(14),dp(13),dp(14));LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);TextView i=t(ic,22,BLUE,true);i.setGravity(Gravity.CENTER);i.setBackground(round(BLUE_SOFT,15));row.addView(i,new LinearLayout.LayoutParams(dp(52),dp(52)));LinearLayout tx=new LinearLayout(this);tx.setOrientation(LinearLayout.VERTICAL);tx.setPadding(dp(13),0,0,0);tx.addView(t(title,17,TEXT,true));tx.addView(t(sub,11,MUTED,false));row.addView(tx,new LinearLayout.LayoutParams(0,-2,1));row.addView(t("›",28,MUTED,false));c.addView(row);c.setOnClickListener(v->r.run());return c;}

    private void showCatalogue(){
        page=Page.CATALOGUE;
        setTop("Catalogue","Mes références",this::showHome,"⋮",this::catalogueMenu);
        renderBottom(1);
        clear();

        EditText search=field("Rechercher une référence…");
        content.addView(search,new LinearLayout.LayoutParams(-1,dp(54)));

        LinearLayout filters=new LinearLayout(this);
        filters.setOrientation(LinearLayout.HORIZONTAL);
        filters.setGravity(Gravity.CENTER_VERTICAL);

        Spinner categoryFilter=new Spinner(this);
        Spinner brandFilter=new Spinner(this);

        ArrayList<String> categories=categoryChoices(true);
        ArrayList<String> brands=brandChoices(true);

        categoryFilter.setAdapter(new ArrayAdapter<String>(
            this,android.R.layout.simple_spinner_dropdown_item,categories
        ));
        brandFilter.setAdapter(new ArrayAdapter<String>(
            this,android.R.layout.simple_spinner_dropdown_item,brands
        ));

        LinearLayout.LayoutParams catLp=new LinearLayout.LayoutParams(0,dp(48),1);
        LinearLayout.LayoutParams brandLp=new LinearLayout.LayoutParams(0,dp(48),1);
        brandLp.leftMargin=dp(8);

        filters.addView(categoryFilter,catLp);
        filters.addView(brandFilter,brandLp);
        content.addView(filters,gap(8));

        Button add=primary("+ Ajouter une référence");
        add.setOnClickListener(v->showEdit(null));
        content.addView(add,gap(10));

        LinearLayout list=new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        content.addView(list,gap(10));

        Runnable render=()->{
            list.removeAllViews();
            String q=search.getText().toString();
            String selectedCategory=(String)categoryFilter.getSelectedItem();
            String selectedBrand=(String)brandFilter.getSelectedItem();

            int count=0;
            for(MaterialItem m:materials){
                if(!m.matches(q)) continue;

                if(selectedCategory!=null && !"Toutes les catégories".equals(selectedCategory)){
                    if(!selectedCategory.equalsIgnoreCase(m.category)) continue;
                }

                if(selectedBrand!=null && !"Toutes les marques".equals(selectedBrand)){
                    if(!selectedBrand.equalsIgnoreCase(m.brand)) continue;
                }

                count++;
                list.addView(catalogueRow(m),gap(7));
            }

            if(count==0){
                TextView e=t(
                    materials.isEmpty() ? "Catalogue vide" : "Aucun résultat avec ces filtres",
                    14,MUTED,false
                );
                e.setGravity(Gravity.CENTER);
                e.setPadding(0,dp(28),0,0);
                list.addView(e);
            }
        };

        search.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int a,int b,int c){}
            public void onTextChanged(CharSequence s,int a,int b,int c){render.run();}
            public void afterTextChanged(Editable e){}
        });

        categoryFilter.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            public void onItemSelected(AdapterView<?> parent,View view,int position,long id){render.run();}
            public void onNothingSelected(AdapterView<?> parent){}
        });

        brandFilter.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            public void onItemSelected(AdapterView<?> parent,View view,int position,long id){render.run();}
            public void onNothingSelected(AdapterView<?> parent){}
        });

        render.run();
    }

    private ArrayList<String> categoryChoices(boolean includeAll){
        TreeSet<String> set=new TreeSet<>(String.CASE_INSENSITIVE_ORDER);

        set.add("Appareillage");
        set.add("Modulaire");
        set.add("Interphone");
        set.add("Contrôle d'accès");

        for(MaterialItem m:materials){
            if(m.category!=null && !m.category.trim().isEmpty()){
                set.add(m.category.trim());
            }
        }

        ArrayList<String> out=new ArrayList<>();
        if(includeAll) out.add("Toutes les catégories");
        out.addAll(set);
        return out;
    }

    private ArrayList<String> brandChoices(boolean includeAll){
        TreeSet<String> set=new TreeSet<>(String.CASE_INSENSITIVE_ORDER);

        for(MaterialItem m:materials){
            if(m.brand!=null && !m.brand.trim().isEmpty()){
                set.add(m.brand.trim());
            }
        }

        ArrayList<String> out=new ArrayList<>();
        if(includeAll) out.add("Toutes les marques");
        out.addAll(set);
        return out;
    }

    private AutoCompleteTextView suggestField(
        LinearLayout parent,String label,String hint,String value,ArrayList<String> suggestions
    ){
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(13),dp(9),dp(13),dp(9));
        box.addView(t(label,11,TEXT,true));

        AutoCompleteTextView e=new AutoCompleteTextView(this);
        e.setHint(hint);
        e.setTextColor(TEXT);
        e.setHintTextColor(Color.rgb(145,155,171));
        e.setTextSize(14);
        e.setPadding(dp(13),dp(10),dp(13),dp(10));
        e.setBackground(roundStroke(WHITE,BORDER,14,1));
        e.setSingleLine(true);
        e.setThreshold(0);
        e.setText(value);

        e.setAdapter(new ArrayAdapter<String>(
            this,android.R.layout.simple_dropdown_item_1line,suggestions
        ));

        e.setOnClickListener(v->e.showDropDown());
        e.setOnFocusChangeListener((v,hasFocus)->{
            if(hasFocus) e.showDropDown();
        });

        box.addView(e,gap(4));
        parent.addView(box);
        return e;
    }


    private LinearLayout catalogueRow(MaterialItem m){LinearLayout c=card();c.setPadding(dp(13),dp(11),dp(12),dp(11));LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);LinearLayout tx=new LinearLayout(this);tx.setOrientation(LinearLayout.VERTICAL);tx.addView(t(m.name,15,TEXT,true));tx.addView(t(m.displayRef()+(m.brand.isEmpty()?"":" • "+m.brand),11,MUTED,false));row.addView(tx,new LinearLayout.LayoutParams(0,-2,1));LinearLayout st=new LinearLayout(this);st.setOrientation(LinearLayout.VERTICAL);st.setGravity(Gravity.RIGHT);st.addView(t("Camion",10,MUTED,false));st.addView(t(m.stockCamion+" "+m.unit,13,m.minStock>0&&m.stockCamion<=m.minStock?ORANGE:GREEN,true));row.addView(st);c.addView(row);c.setOnClickListener(v->showEdit(m));return c;}
    private void catalogueMenu(){String[] items={"Importer / Exporter","Exporter modèle CSV","Exporter modèle Excel"};new AlertDialog.Builder(this).setTitle("Catalogue").setItems(items,(d,w)->{if(w==0)transferMenu();else if(w==1)startExport("csv",true);else startExport("xlsx",true);}).show();}

    private void showEdit(MaterialItem m){
        page=Page.EDIT;
        setTop(
            m==null ? "Nouvelle référence" : "Modifier la référence",
            "Catalogue",
            this::showCatalogue,
            null,
            null
        );
        renderBottom(1);
        clear();

        LinearLayout id=card();

        EditText name=labeled(
            id,"Désignation *","Ex. Ventouse 300 kg",m==null ? "" : m.name
        );

        EditText ref=labeled(
            id,"Référence","Ex. EF3003",m==null ? "" : m.reference
        );

        AutoCompleteTextView brand=suggestField(
            id,
            "Marque",
            "Choisir ou saisir une marque",
            m==null ? "" : m.brand,
            brandChoices(false)
        );

        AutoCompleteTextView cat=suggestField(
            id,
            "Catégorie",
            "Choisir ou saisir une catégorie",
            m==null ? "" : m.category,
            categoryChoices(false)
        );

        content.addView(id);

        LinearLayout st=card();

        EditText stock=labeledNumber(
            st,"Stock camion",m==null ? 0 : m.stockCamion
        );

        EditText mini=labeledNumber(
            st,"Alerte si stock ≤",m==null ? 0 : m.minStock
        );

        EditText unit=labeled(
            st,"Unité","u, m, rouleau…",m==null ? "u" : m.unit
        );

        content.addView(st,gap(12));

        LinearLayout sr=card();

        EditText alias=labeled(
            sr,"Alias","Nom court",m==null ? "" : m.alias
        );

        EditText keys=labeled(
            sr,"Mots-clés","Pour la recherche",m==null ? "" : m.keywords
        );

        content.addView(sr,gap(12));

        Button save=primary(m==null ? "Créer la référence" : "Enregistrer");
        save.setOnClickListener(v->{
            String designation=val(name);

            if(designation.isEmpty()){
                name.setError("Obligatoire");
                return;
            }

            String marque=brand.getText().toString().trim();
            String categorie=cat.getText().toString().trim();

            if(m==null){
                materials.add(new MaterialItem(
                    System.currentTimeMillis(),
                    designation,
                    val(ref),
                    marque,
                    categorie,
                    val(alias),
                    val(keys),
                    val(unit).isEmpty() ? "u" : val(unit),
                    num(stock),
                    num(mini)
                ));
            }else{
                m.name=designation;
                m.reference=val(ref);
                m.brand=marque;
                m.category=categorie;
                m.alias=val(alias);
                m.keywords=val(keys);
                m.unit=val(unit).isEmpty() ? "u" : val(unit);
                m.stockCamion=num(stock);
                m.minStock=num(mini);
            }

            LocalStore.save(this,materials);
            showCatalogue();
        });

        content.addView(save,new LinearLayout.LayoutParams(-1,dp(52)));
    }

    private void showWorksites(){page=Page.WORKSITES;current=null;setTop("Mes chantiers","Listes matériel",this::showHome,"+ Nouveau",this::createWorksite);renderBottom(2);clear();if(worksites.isEmpty()){LinearLayout e=card();e.setPadding(dp(20),dp(26),dp(20),dp(26));TextView ti=t("Aucun chantier",18,TEXT,true);ti.setGravity(Gravity.CENTER);e.addView(ti);TextView su=t("Crée d'abord un chantier, puis ajoute le matériel installé comme dans un panier.",13,MUTED,false);su.setGravity(Gravity.CENTER);e.addView(su,gap(8));Button b=primary("Créer mon premier chantier");b.setOnClickListener(v->createWorksite());e.addView(b,gap(18));content.addView(e);return;}Collections.sort(worksites,(a,b)->Long.compare(b.createdAt,a.createdAt));for(Worksite w:worksites)content.addView(worksiteRow(w),gap(8));}
    private LinearLayout worksiteRow(Worksite w){LinearLayout c=card();c.setPadding(dp(14),dp(12),dp(12),dp(12));LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);LinearLayout tx=new LinearLayout(this);tx.setOrientation(LinearLayout.VERTICAL);tx.addView(t(w.name,16,TEXT,true));tx.addView(t(w.quantities.size()+" référence(s)"+(w.validated?" • validé":""),11,w.validated?GREEN:MUTED,false));r.addView(tx,new LinearLayout.LayoutParams(0,-2,1));r.addView(t("›",28,MUTED,false));c.addView(r);c.setOnClickListener(v->openWorksite(w));return c;}
    private void createWorksite(){
        LinearLayout form=new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(18),0,dp(18),0);

        EditText name=field("Nom du chantier");
        EditText note=field("Note / adresse (facultatif)");
        CheckBox deduct=new CheckBox(this);
        deduct.setText("Déduire par défaut le matériel du stock camion");
        deduct.setChecked(true);

        form.addView(name,new LinearLayout.LayoutParams(-1,dp(54)));
        form.addView(note,gap(8));
        form.addView(deduct,gap(10));

        AlertDialog d=new AlertDialog.Builder(this)
            .setTitle("Nouveau chantier")
            .setView(form)
            .setNegativeButton("Annuler",null)
            .setPositiveButton("Créer",null)
            .create();

        d.setOnShowListener(x->d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            String n=name.getText().toString().trim();
            if(n.isEmpty()){
                name.setError("Donne un nom au chantier");
                return;
            }

            Worksite w=new Worksite(
                System.currentTimeMillis(),
                n,
                note.getText().toString().trim(),
                System.currentTimeMillis()
            );
            w.deductFromTruck=deduct.isChecked();

            worksites.add(w);
            WorksiteStore.save(this,worksites);
            d.dismiss();
            openWorksite(w);
        }));

        d.show();
    }

    private void openWorksite(Worksite w){
        lastTouchedMaterialId=-1;current=w;page=Page.CART;setTop(w.name,w.validated?"Liste validée":"Composer la liste",this::showWorksites,"⋮",()->worksiteMenu(w));renderBottom(2);clear();EditText search=field("Rechercher du matériel…");content.addView(search,new LinearLayout.LayoutParams(-1,dp(56)));LinearLayout results=new LinearLayout(this);results.setOrientation(LinearLayout.VERTICAL);content.addView(results,gap(8));TextView cartTitle=t("Sélection • "+totalQty(w)+" article(s)",13,TEXT,true);content.addView(cartTitle,gap(16));LinearLayout cart=new LinearLayout(this);cart.setOrientation(LinearLayout.VERTICAL);content.addView(cart,gap(6));Runnable cartRefresh=()->renderCart(w,cart,cartTitle);Runnable resultRefresh=()->renderResults(w,val(search),results,cartRefresh);search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b,int c){}public void onTextChanged(CharSequence s,int a,int b,int c){resultRefresh.run();}public void afterTextChanged(Editable e){}});resultRefresh.run();cartRefresh.run();Button validate=primary(w.validated?"Liste validée • partager":"Valider la liste");validate.setOnClickListener(v->{validateWorksiteStock(w);});LinearLayout.LayoutParams vp=new LinearLayout.LayoutParams(-1,dp(52));vp.topMargin=dp(18);content.addView(validate,vp);}

    private void worksiteMenu(Worksite w){
        String[] options={"Modifier le chantier","Supprimer le chantier"};
        new AlertDialog.Builder(this).setTitle(w.name).setItems(options,(d,i)->{
            if(i==0)editWorksite(w); else deleteWorksite(w);
        }).show();
    }

    private void editWorksite(Worksite w){
        LinearLayout f=new LinearLayout(this);f.setOrientation(LinearLayout.VERTICAL);f.setPadding(dp(18),0,dp(18),0);
        EditText name=field("Nom du chantier");name.setText(w.name);
        EditText note=field("Note / adresse");note.setText(w.note);
        f.addView(name,new LinearLayout.LayoutParams(-1,dp(54)));f.addView(note,gap(8));

        AlertDialog d=new AlertDialog.Builder(this).setTitle("Modifier le chantier").setView(f)
            .setNegativeButton("Annuler",null).setPositiveButton("Enregistrer",null).create();

        d.setOnShowListener(x->d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            String n=val(name);if(n.isEmpty()){name.setError("Nom obligatoire");return;}
            w.name=n;w.note=val(note);WorksiteStore.save(this,worksites);
            d.dismiss();openWorksite(w);
        }));
        d.show();
    }

    private void deleteWorksite(Worksite w){
        new AlertDialog.Builder(this).setTitle("Supprimer ce chantier ?")
            .setMessage(w.name+"\n\nLa liste de matériel sera également supprimée.")
            .setNegativeButton("Annuler",null)
            .setPositiveButton("Supprimer",(d,x)->{
                worksites.remove(w);WorksiteStore.save(this,worksites);showWorksites();
            }).show();
    }

    private void renderResults(Worksite w,String q,LinearLayout results,Runnable cartRefresh){results.removeAllViews();if(q.trim().isEmpty()){results.addView(t("Tape quelques lettres : les résultats apparaissent immédiatement.",12,MUTED,false));return;}int n=0;for(MaterialItem m:materials){if(!m.matches(q))continue;n++;LinearLayout c=card();c.setPadding(dp(12),dp(10),dp(10),dp(10));LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);LinearLayout tx=new LinearLayout(this);tx.setOrientation(LinearLayout.VERTICAL);tx.addView(t(m.name,14,TEXT,true));tx.addView(t(m.displayRef()+" • stock "+m.stockCamion+" "+m.unit,10,MUTED,false));r.addView(tx,new LinearLayout.LayoutParams(0,-2,1));int qty=w.quantities.getOrDefault(m.id,0);TextView state=t(qty>0?"✓ "+qty:"+",16,qty>0?GREEN:BLUE,true);state.setGravity(Gravity.CENTER);r.addView(state,new LinearLayout.LayoutParams(dp(56),dp(38)));c.addView(r);c.setOnClickListener(v->{int x=w.quantities.getOrDefault(m.id,0);w.quantities.put(m.id,x==0?1:x);lastTouchedMaterialId=m.id;w.validated=false;WorksiteStore.save(this,worksites);cartRefresh.run();renderResults(w,q,results,cartRefresh);});results.addView(c,gap(6));if(n>=8)break;}if(n==0)results.addView(t("Aucun résultat",12,MUTED,false));}

    private void renderCart(Worksite w,LinearLayout cart,TextView title){
        cart.removeAllViews();
        title.setText("Sélection • "+totalQty(w)+" article(s)");

        if(w.quantities.isEmpty()){
            TextView e=t("Aucun produit sélectionné.",12,MUTED,false);
            cart.addView(e);
            return;
        }

        ArrayList<Map.Entry<Long,Integer>> entries=new ArrayList<>(w.quantities.entrySet());

        Collections.sort(entries,(a,b)->{
            boolean aLast=a.getKey().longValue()==lastTouchedMaterialId;
            boolean bLast=b.getKey().longValue()==lastTouchedMaterialId;
            if(aLast && !bLast)return -1;
            if(bLast && !aLast)return 1;
            return 0;
        });

        for(Map.Entry<Long,Integer> en:entries){
            MaterialItem m=find(en.getKey());
            if(m==null)continue;

            LinearLayout c=card();
            c.setPadding(dp(12),dp(10),dp(10),dp(10));

            LinearLayout r=new LinearLayout(this);
            r.setGravity(Gravity.CENTER_VERTICAL);

            LinearLayout tx=new LinearLayout(this);
            tx.setOrientation(LinearLayout.VERTICAL);
            tx.addView(t(m.alias.isEmpty()?m.name:m.alias,14,TEXT,true));
            tx.addView(t("Stock camion "+m.stockCamion+" "+m.unit,10,MUTED,false));
            r.addView(tx,new LinearLayout.LayoutParams(0,-2,1));

            Button minus=small("−");

            EditText qty=new EditText(this);
            qty.setInputType(InputType.TYPE_CLASS_NUMBER);
            qty.setGravity(Gravity.CENTER);
            qty.setText(String.valueOf(en.getValue()));
            qty.setTextSize(14);
            qty.setTextColor(TEXT);
            qty.setBackground(round(WHITE,8));

            Button plus=small("+");

            minus.setOnClickListener(v->{
                int q=w.quantities.getOrDefault(m.id,0)-1;
                if(q<=0)w.quantities.remove(m.id);
                else w.quantities.put(m.id,q);

                lastTouchedMaterialId=m.id;
                w.validated=false;
                WorksiteStore.save(this,worksites);
                
                renderCart(w,cart,title);
            });

            plus.setOnClickListener(v->{
                w.quantities.put(m.id,w.quantities.getOrDefault(m.id,0)+1);

                lastTouchedMaterialId=m.id;
                w.validated=false;
                WorksiteStore.save(this,worksites);
                
                renderCart(w,cart,title);
            });

            qty.setOnFocusChangeListener((v,hasFocus)->{
                if(!hasFocus){
                    int q=num(qty);
                    if(q<=0)w.quantities.remove(m.id);
                    else w.quantities.put(m.id,q);

                    lastTouchedMaterialId=m.id;
                    w.validated=false;
                    WorksiteStore.save(this,worksites);
                    
                    renderCart(w,cart,title);
                }
            });

            r.addView(minus,new LinearLayout.LayoutParams(dp(38),dp(38)));
            r.addView(qty,new LinearLayout.LayoutParams(dp(52),dp(38)));
            r.addView(plus,new LinearLayout.LayoutParams(dp(38),dp(38)));

            LinearLayout dedLine=new LinearLayout(this);dedLine.setGravity(Gravity.RIGHT);dedLine.addView(deductToggleFor(w,m));c.addView(r);c.addView(dedLine);
            cart.addView(c,gap(6));
        }
    }

    private int totalQty(Worksite w){int n=0;for(int q:w.quantities.values())n+=q;return n;}

    private void shareMenu(Worksite w){String[] options={"Copier la liste","Partager…","Copier demande de réassort","Retour au chantier"};new AlertDialog.Builder(this).setTitle("Liste validée").setItems(options,(d,i)->{if(i==0)copy(buildWorksiteText(w),"Liste copiée");else if(i==1){Intent sh=new Intent(Intent.ACTION_SEND);sh.setType("text/plain");sh.putExtra(Intent.EXTRA_TEXT,buildWorksiteText(w));startActivity(Intent.createChooser(sh,"Partager la liste"));}else if(i==2)copy(buildReorderText(),"Demande copiée");}).show();}
    private void copyText(String text,String message){
        android.content.ClipboardManager cm=
            (android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);

        cm.setPrimaryClip(
            ClipData.newPlainText("Allocat",text)
        );

        Toast.makeText(this,message,Toast.LENGTH_SHORT).show();
    }


    private void showShareDialog(Worksite w){
        String[] options={
            "Copier la liste",
            "Partager…",
            "Copier demande de réassort",
            "Retour au chantier"
        };

        new AlertDialog.Builder(this)
            .setTitle("Liste validée")
            .setItems(options,(d,i)->{
                if(i==0){
                    copyText(buildWorksiteText(w),"Liste copiée");
                }else if(i==1){
                    Intent share=new Intent(Intent.ACTION_SEND);
                    share.setType("text/plain");
                    share.putExtra(Intent.EXTRA_TEXT,buildWorksiteText(w));
                    startActivity(Intent.createChooser(share,"Partager la liste"));
                }else if(i==2){
                    copyText(buildReorderText(),"Demande de réassort copiée");
                }else{
                    openWorksite(w);
                }
            })
            .show();
    }


    private String buildWorksiteText(Worksite w){StringBuilder b=new StringBuilder("Chantier : "+w.name+"\n");if(!w.note.isEmpty())b.append(w.note).append("\n");b.append("\nMatériel installé :\n");for(Map.Entry<Long,Integer> e:w.quantities.entrySet()){MaterialItem m=find(e.getKey());if(m==null)continue;b.append("- ").append(e.getValue()).append(" ").append(m.unit).append(" × ").append(m.alias.isEmpty()?m.name:m.alias);if(!m.reference.isEmpty())b.append(" (").append(m.reference).append(")");b.append("\n");}return b.toString();}


    private void validateWorksiteStock(Worksite w){
        StringBuilder preview=new StringBuilder();
        int changed=0;

        for(Map.Entry<Long,Integer> e:w.quantities.entrySet()){
            long id=e.getKey();
            MaterialItem m=find(id);
            if(m==null) continue;

            int desired=w.shouldDeduct(id) ? Math.max(0,e.getValue()) : 0;
            int already=w.deductedQuantities.getOrDefault(id,0);
            int delta=desired-already;

            if(delta!=0){
                changed++;
                preview.append(m.name)
                    .append(" : ")
                    .append(already)
                    .append(" → ")
                    .append(desired)
                    .append(" déduit(s)")
                    .append("\n");
            }
        }

        // Also restore previously deducted items removed from cart.
        for(Map.Entry<Long,Integer> e:new ArrayList<>(w.deductedQuantities.entrySet())){
            if(w.quantities.containsKey(e.getKey())) continue;
            MaterialItem m=find(e.getKey());
            if(m!=null && e.getValue()!=0){
                changed++;
                preview.append(m.name)
                    .append(" : ")
                    .append(e.getValue())
                    .append(" → 0 déduit(s)\n");
            }
        }

        String msg=(changed==0)
            ? "Aucun mouvement de stock supplémentaire."
            : preview.toString();

        new AlertDialog.Builder(this)
            .setTitle("Valider le matériel installé")
            .setMessage(msg+"\nLes quantités déjà déduites ne seront jamais retirées une seconde fois.")
            .setNegativeButton("Annuler",null)
            .setPositiveButton("Valider",(d,which)->applyWorksiteStock(w))
            .show();
    }

    private void applyWorksiteStock(Worksite w){
        HashSet<Long> all=new HashSet<>();
        all.addAll(w.quantities.keySet());
        all.addAll(w.deductedQuantities.keySet());

        for(Long id:all){
            MaterialItem m=find(id);
            if(m==null) continue;

            int desired=(w.quantities.containsKey(id) && w.shouldDeduct(id))
                ? Math.max(0,w.quantities.getOrDefault(id,0))
                : 0;

            int already=w.deductedQuantities.getOrDefault(id,0);
            int delta=desired-already;

            if(delta>0){
                m.stockCamion=Math.max(0,m.stockCamion-delta);
            }else if(delta<0){
                m.stockCamion+=(-delta);
            }

            if(desired==0) w.deductedQuantities.remove(id);
            else w.deductedQuantities.put(id,desired);
        }

        w.validated=true;
        LocalStore.save(this,materials);
        WorksiteStore.save(this,worksites);

        Toast.makeText(this,"Chantier validé et stock mis à jour",Toast.LENGTH_SHORT).show();
        showShareDialog(w);
    }

    private CheckBox deductToggleFor(Worksite w,MaterialItem m){
        CheckBox cb=new CheckBox(this);
        cb.setText("Stock camion");
        cb.setChecked(w.shouldDeduct(m.id));
        cb.setTextSize(11);
        cb.setOnCheckedChangeListener((button,isChecked)->{
            w.deductOverrides.put(m.id,isChecked);
            w.validated=false;
            WorksiteStore.save(this,worksites);
        });
        return cb;
    }

    private void showStock(){page=Page.STOCK;setTop("Stock camion","Alertes",this::showHome,null,null);renderBottom(0);clear();ArrayList<MaterialItem> alerts=new ArrayList<>();for(MaterialItem m:materials)if(m.minStock>0&&m.stockCamion<=m.minStock)alerts.add(m);LinearLayout s=card();s.setPadding(dp(15),dp(13),dp(15),dp(13));s.addView(t(materials.size()+" référence(s)",12,MUTED,false));s.addView(t(alerts.size()+" alerte(s)",23,alerts.isEmpty()?GREEN:ORANGE,true),gap(4));content.addView(s);if(!alerts.isEmpty()){Button copy=primary("Copier la demande de réassort");copy.setOnClickListener(v->copy(buildReorderText(),"Demande copiée"));content.addView(copy,gap(10));}for(MaterialItem m:materials){LinearLayout c=card();c.setPadding(dp(12),dp(10),dp(12),dp(10));LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);LinearLayout tx=new LinearLayout(this);tx.setOrientation(LinearLayout.VERTICAL);tx.addView(t(m.name,14,TEXT,true));tx.addView(t(m.displayRef(),10,MUTED,false));r.addView(tx,new LinearLayout.LayoutParams(0,-2,1));r.addView(t(m.stockCamion+" "+m.unit,15,m.minStock>0&&m.stockCamion<=m.minStock?ORANGE:GREEN,true));c.addView(r);content.addView(c,gap(6));}}
    private String buildReorderText(){StringBuilder b=new StringBuilder("Demande de réassort camion :\n");boolean any=false;for(MaterialItem m:materials){if(m.minStock>0&&m.stockCamion<=m.minStock){any=true;int need=Math.max(1,m.minStock-m.stockCamion);b.append("- ").append(m.name);if(!m.reference.isEmpty())b.append(" (").append(m.reference).append(")");b.append(" : stock ").append(m.stockCamion).append(" ").append(m.unit).append(", mini ").append(m.minStock).append(", à commander au moins ").append(need).append(" ").append(m.unit).append("\n");}}if(!any)b.append("Aucune alerte stock.");return b.toString();}
    private void copy(String s,String toast){android.content.ClipboardManager cm=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);cm.setPrimaryClip(ClipData.newPlainText("Allocat",s));Toast.makeText(this,toast,Toast.LENGTH_SHORT).show();}

    private void transferMenu(){
        String[] options={
            "Importer JSON",
            "Importer CSV",
            "Importer Excel",
            "Exporter JSON",
            "Exporter CSV",
            "Exporter Excel",
            "Modèle CSV",
            "Modèle Excel"
        };

        new AlertDialog.Builder(this)
            .setTitle("Importer / Exporter")
            .setItems(options,(d,i)->{
                if(i==0) startImport("json");
                else if(i==1) startImport("csv");
                else if(i==2) startImport("xlsx");
                else if(i==3) startExport("json",false);
                else if(i==4) startExport("csv",false);
                else if(i==5) startExport("xlsx",false);
                else if(i==6) startExport("csv",true);
                else startExport("xlsx",true);
            })
            .show();
    }

    private void startImport(String format){
        pendingFormat=format;

        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);

        if("xlsx".equals(format)){
            i.setType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        }else if("json".equals(format)){
            i.setType("application/json");
        }else{
            i.setType("text/*");
        }

        startActivityForResult(i,REQ_IMPORT);
    }

    private void startExport(String format,boolean template){
        pendingFormat=format;
        pendingTemplate=template;

        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);

        if("xlsx".equals(format)){
            i.setType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        }else if("json".equals(format)){
            i.setType("application/json");
        }else{
            i.setType("text/csv");
        }

        i.putExtra(
            Intent.EXTRA_TITLE,
            (template ? "allocat-modele" : "allocat-catalogue")+"."+format
        );

        startActivityForResult(i,REQ_EXPORT);
    }

    @Override protected void onActivityResult(int req,int res,Intent data){
        super.onActivityResult(req,res,data);

        if(req==REQ_BACKUP_FOLDER){
            if(res==RESULT_OK && data!=null && data.getData()!=null){
                Uri uri=data.getData();

                try{
                    int flags=data.getFlags() & (
                        Intent.FLAG_GRANT_READ_URI_PERMISSION |
                        Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    );

                    getContentResolver().takePersistableUriPermission(uri,flags);
                }catch(Exception ignored){}

                BackupManager.setFolder(this,uri);

                if(exitAfterFolderSelection){
                    exitAfterFolderSelection=false;
                    saveAndExit();
                }else{
                    Toast.makeText(
                        this,
                        "Dossier de sauvegarde enregistré",
                        Toast.LENGTH_SHORT
                    ).show();

                    if(page==Page.SETTINGS) showSettings();
                }
            }
            return;
        }

        if(res!=RESULT_OK || data==null || data.getData()==null) return;

        Uri uri=data.getData();

        try{
            if(req==REQ_IMPORT){
                ArrayList<MaterialItem> imported;

                if("json".equals(pendingFormat)){
                    imported=CatalogueIO.importJson(this,uri);
                }else if("csv".equals(pendingFormat)){
                    imported=CatalogueIO.importCsv(this,uri);
                }else{
                    imported=CatalogueIO.importXlsx(this,uri);
                }

                final ArrayList<MaterialItem> values=imported;

                new AlertDialog.Builder(this)
                    .setTitle("Importer "+values.size()+" référence(s) ?")
                    .setNegativeButton("Annuler",null)
                    .setNeutralButton("Ajouter",(d,w)->{
                        materials.addAll(values);
                        LocalStore.save(this,materials);
                        showCatalogue();
                    })
                    .setPositiveButton("Remplacer",(d,w)->{
                        materials.clear();
                        materials.addAll(values);
                        LocalStore.save(this,materials);
                        showCatalogue();
                    })
                    .show();

            }else if(req==REQ_EXPORT){
                ArrayList<MaterialItem> source=
                    pendingTemplate ? new ArrayList<>() : materials;

                if("json".equals(pendingFormat)){
                    CatalogueIO.exportJson(this,uri,source);
                }else if("csv".equals(pendingFormat)){
                    CatalogueIO.exportCsv(this,uri,source);
                }else{
                    CatalogueIO.exportXlsx(this,uri,source);
                }

                Toast.makeText(
                    this,
                    pendingTemplate ? "Modèle exporté" : "Catalogue exporté",
                    Toast.LENGTH_SHORT
                ).show();
            }
        }catch(Exception e){
            new AlertDialog.Builder(this)
                .setTitle("Erreur")
                .setMessage(e.getMessage()==null?e.toString():e.getMessage())
                .setPositiveButton("OK",null)
                .show();
        }
    }

    private void showSettings(){
        page=Page.SETTINGS;
        setTop("Réglages","Allocat",this::showHome,null,null);
        renderBottom(3);
        clear();

        LinearLayout app=card();
        app.addView(info("Version","0.1.9"));
        app.addView(div());
        app.addView(info("Références",String.valueOf(materials.size())));
        app.addView(div());
        app.addView(info("Chantiers",String.valueOf(worksites.size())));
        content.addView(app);

        LinearLayout backup=card();
        backup.setPadding(dp(14),dp(12),dp(14),dp(12));
        backup.addView(t("Sauvegarde JSON",16,TEXT,true));
        backup.addView(
            t("Dossier : "+BackupManager.folderLabel(this),12,MUTED,false),
            gap(6)
        );

        Button choose=primary("Choisir le dossier");
        choose.setOnClickListener(v->{
            exitAfterFolderSelection=false;
            chooseBackupFolder();
        });
        backup.addView(choose,gap(12));

        Button now=primary("Sauvegarder maintenant");
        now.setOnClickListener(v->{
            if(BackupManager.getFolder(this)==null){
                exitAfterFolderSelection=false;
                chooseBackupFolder();
                return;
            }

            try{
                String filename=BackupManager.save(this,materials,worksites);
                Toast.makeText(
                    this,
                    "Sauvegarde créée : "+filename,
                    Toast.LENGTH_SHORT
                ).show();
            }catch(Exception e){
                new AlertDialog.Builder(this)
                    .setTitle("Sauvegarde impossible")
                    .setMessage(e.getMessage()==null?e.toString():e.getMessage())
                    .setPositiveButton("OK",null)
                    .show();
            }
        });
        backup.addView(now,gap(8));

        content.addView(backup,gap(14));
    }


    private MaterialItem find(long id){
        for(MaterialItem m:materials){
            if(m.id==id) return m;
        }
        return null;
    }


    private LinearLayout info(String k,String v){LinearLayout r=new LinearLayout(this);r.setPadding(dp(13),dp(12),dp(13),dp(12));r.addView(t(k,13,TEXT,false),new LinearLayout.LayoutParams(0,-2,1));r.addView(t(v,13,MUTED,false));return r;}
    private View div(){View v=new View(this);v.setBackgroundColor(BORDER);v.setLayoutParams(new LinearLayout.LayoutParams(-1,dp(1)));return v;}
    private LinearLayout card(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setBackground(roundStroke(WHITE,BORDER,17,1));return c;}
    private EditText field(String hint){EditText e=new EditText(this);e.setHint(hint);e.setTextColor(TEXT);e.setHintTextColor(Color.rgb(145,155,171));e.setTextSize(14);e.setPadding(dp(13),dp(10),dp(13),dp(10));e.setBackground(roundStroke(WHITE,BORDER,14,1));e.setSingleLine(true);return e;}
    private EditText labeled(LinearLayout p,String l,String h,String v){LinearLayout b=new LinearLayout(this);b.setOrientation(LinearLayout.VERTICAL);b.setPadding(dp(13),dp(9),dp(13),dp(9));b.addView(t(l,11,TEXT,true));EditText e=field(h);e.setText(v);b.addView(e,gap(4));p.addView(b);return e;}
    private EditText labeledNumber(LinearLayout p,String l,int v){EditText e=labeled(p,l,"0",String.valueOf(v));e.setInputType(InputType.TYPE_CLASS_NUMBER);return e;}
    private Button primary(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(WHITE);b.setTextSize(13);b.setBackground(round(BLUE,13));return b;}
    private Button mini(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(BLUE);b.setTextSize(16);b.setBackground(round(BLUE_SOFT,12));return b;}
    private Button small(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(BLUE);b.setTextSize(17);b.setPadding(0,0,0,0);b.setBackground(round(BLUE_SOFT,9));return b;}
    private TextView t(String s,int sp,int color,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextSize(sp);v.setTextColor(color);if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;}
    private LinearLayout.LayoutParams gap(int top){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(top);return p;}
    private GradientDrawable round(int c,int r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(r));return d;}
    private GradientDrawable roundStroke(int c,int s,int r,int w){GradientDrawable d=round(c,r);d.setStroke(dp(w),s);return d;}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
    private String val(EditText e){return e.getText().toString().trim();}
    private int num(EditText e){try{return Integer.parseInt(val(e));}catch(Exception x){return 0;}}
}
