package fr.catallo.app;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {

    private final int BG=Color.rgb(247,249,252);
    private final int WHITE=Color.WHITE;
    private final int TEXT=Color.rgb(28,42,69);
    private final int MUTED=Color.rgb(92,108,134);
    private final int BLUE=Color.rgb(47,93,181);
    private final int BLUE_SOFT=Color.rgb(228,235,249);
    private final int BORDER=Color.rgb(226,231,239);
    private final int GREEN=Color.rgb(47,132,102);
    private final int ORANGE=Color.rgb(191,111,44);

    private LinearLayout shell, content, bottom;
    private ArrayList<MaterialItem> materials;
    private LinkedHashMap<Long,Integer> chantierSelection=new LinkedHashMap<>();

    private enum Page { HOME, CATALOGUE, DETAIL, CHANTIERS, REPORT, STATS, SETTINGS }
    private Page currentPage = Page.HOME;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        materials=LocalStore.load(this);
        buildShell();
        showHome();
    }

    @Override public void onBackPressed(){
        if(currentPage != Page.HOME){
            showHome();
        }else{
            super.onBackPressed();
        }
    }

    private void buildShell(){
        shell=new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        shell.setBackgroundColor(BG);

        ScrollView scroll=new ScrollView(this);
        scroll.setFillViewport(true);

        content=new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(18),dp(12),dp(18),dp(24));
        scroll.addView(content);

        shell.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

        bottom=buildBottomNav();
        shell.addView(bottom,new LinearLayout.LayoutParams(-1,dp(76)));

        setContentView(shell);
    }

    private LinearLayout buildBottomNav(){
        LinearLayout bar=new LinearLayout(this);
        bar.setGravity(Gravity.CENTER);
        bar.setPadding(dp(6),dp(6),dp(6),dp(8));
        bar.setBackground(roundStroke(WHITE,BORDER,24,1));

        String[] names={"Accueil","Catalogue","Chantiers","Réglages"};
        String[] icons={"⌂","▣","♜","⚙"};

        for(int i=0;i<4;i++){
            int idx=i;
            LinearLayout item=new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setGravity(Gravity.CENTER);

            TextView ic=text(icons[i],22,MUTED,true);
            TextView tx=text(names[i],11,MUTED,false);
            item.addView(ic); item.addView(tx);

            item.setOnClickListener(v->{
                if(idx==0) showHome();
                else if(idx==1) showCatalogue();
                else if(idx==2) showChantiers();
                else showSettings();
            });

            bar.addView(item,new LinearLayout.LayoutParams(0,-1,1));
        }
        return bar;
    }

    private void clear(){ content.removeAllViews(); }

    private void showHome(){
        currentPage=Page.HOME;
        clear();

        LinearLayout head=new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(0,dp(4),0,dp(4));

        ImageView logo=new ImageView(this);
        logo.setImageResource(R.drawable.allocat_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        head.addView(logo,new LinearLayout.LayoutParams(dp(96),dp(96)));

        LinearLayout brand=new LinearLayout(this);
        brand.setOrientation(LinearLayout.VERTICAL);
        brand.setPadding(dp(8),0,0,0);
        brand.addView(text("Allocat",31,TEXT,true));
        brand.addView(text("Catalogue • Matériel • Chantiers",13,MUTED,false));
        head.addView(brand,new LinearLayout.LayoutParams(0,-2,1));

        TextView ver=text("v0.1.3",12,BLUE,true);
        ver.setPadding(dp(12),dp(8),dp(12),dp(8));
        ver.setBackground(round(BLUE_SOFT,16));
        head.addView(ver);

        content.addView(head);

        EditText q=field("Rechercher une référence…");
        LinearLayout.LayoutParams qlp=new LinearLayout.LayoutParams(-1,dp(60));
        qlp.topMargin=dp(14);
        content.addView(q,qlp);
        q.setOnEditorActionListener((v,a,e)->{
            showCatalogueWithQuery(q.getText().toString());
            return true;
        });

        content.addView(homeCard("▣","Mon matériel","Catalogue, références et stock",this::showCatalogue),gap(18));
        content.addView(homeCard("♜","Mes chantiers","Préparer le matériel à emporter",this::showChantiers),gap(12));
        content.addView(homeCard("☷","Compte rendu","Générer un relevé de chantier",this::showReport),gap(12));
        content.addView(homeCard("▥","Stocks","Camion, agence et alertes",this::showStats),gap(12));
    }

    private LinearLayout homeCard(String icon,String title,String sub,Runnable action){
        LinearLayout card=card();
        card.setPadding(dp(18),dp(18),dp(18),dp(18));

        LinearLayout row=new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);

        TextView ic=text(icon,28,BLUE,true);
        ic.setGravity(Gravity.CENTER);
        ic.setBackground(round(BLUE_SOFT,18));
        row.addView(ic,new LinearLayout.LayoutParams(dp(64),dp(64)));

        LinearLayout txt=new LinearLayout(this);
        txt.setOrientation(LinearLayout.VERTICAL);
        txt.setPadding(dp(16),0,0,0);
        txt.addView(text(title,19,TEXT,true));
        txt.addView(text(sub,13,MUTED,false));
        row.addView(txt,new LinearLayout.LayoutParams(0,-2,1));

        row.addView(text("›",34,MUTED,false));

        card.addView(row);
        card.setOnClickListener(v->action.run());
        return card;
    }

    private void showCatalogue(){ showCatalogueWithQuery(""); }

    private void showCatalogueWithQuery(String initial){
        currentPage=Page.CATALOGUE;
        clear();

        LinearLayout top=new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);

        TextView back=text("‹",38,TEXT,false);
        back.setGravity(Gravity.CENTER);
        back.setOnClickListener(v->showHome());
        top.addView(back,new LinearLayout.LayoutParams(dp(44),dp(50)));

        LinearLayout titles=new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.addView(text("Mon matériel",23,TEXT,true));
        titles.addView(text("Catalogue personnel",12,MUTED,false));
        top.addView(titles,new LinearLayout.LayoutParams(0,-2,1));

        Button plus=smallButton("+");
        plus.setOnClickListener(v->editMaterial(null));
        top.addView(plus,new LinearLayout.LayoutParams(dp(48),dp(44)));

        content.addView(top);

        if(materials.isEmpty()){
            LinearLayout empty=card();
            empty.setPadding(dp(24),dp(28),dp(24),dp(28));

            TextView icon=text("▣",40,BLUE,true);
            icon.setGravity(Gravity.CENTER);
            empty.addView(icon);

            TextView title=text("Ton catalogue est vide",20,TEXT,true);
            title.setGravity(Gravity.CENTER);
            empty.addView(title,gap(12));

            TextView sub=text("Ajoute ton premier matériel avec sa référence, sa marque et son stock camion / agence.",14,MUTED,false);
            sub.setGravity(Gravity.CENTER);
            empty.addView(sub,gap(8));

            Button add=primaryButton("+ Ajouter mon premier matériel");
            add.setOnClickListener(v->editMaterial(null));
            empty.addView(add,new LinearLayout.LayoutParams(-1,dp(52)));

            content.addView(empty,gap(26));
            return;
        }

        EditText search=field("Rechercher dans le catalogue…");
        search.setText(initial);
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,dp(58));
        sp.topMargin=dp(12);
        content.addView(search,sp);

        LinearLayout meta=new LinearLayout(this);
        meta.setGravity(Gravity.CENTER_VERTICAL);
        TextView count=text("",13,BLUE,true);
        meta.addView(count,new LinearLayout.LayoutParams(0,-2,1));
        meta.addView(text("Tri : Désignation ↕",13,MUTED,false));
        content.addView(meta,gap(12));

        LinearLayout list=new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        content.addView(list,gap(10));

        Runnable render=()->{
            list.removeAllViews();
            int n=0;
            for(MaterialItem m:materials){
                if(!m.matches(search.getText().toString())) continue;
                n++;
                list.addView(materialRow(m),gap(8));
            }
            count.setText(n+" référence"+(n>1?"s":""));
            if(n==0){
                TextView e=text("Aucun matériel trouvé",15,MUTED,false);
                e.setGravity(Gravity.CENTER);
                e.setPadding(0,dp(40),0,0);
                list.addView(e);
            }
        };

        search.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int b,int c){ render.run(); }
            public void afterTextChanged(Editable e){}
        });

        render.run();
    }

    private LinearLayout materialRow(MaterialItem m){
        LinearLayout card=card();
        card.setPadding(dp(12),dp(12),dp(12),dp(12));

        LinearLayout row=new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);

        TextView pic=text(categoryIcon(m.category),25,BLUE,true);
        pic.setGravity(Gravity.CENTER);
        pic.setBackground(round(Color.rgb(244,247,251),16));
        row.addView(pic,new LinearLayout.LayoutParams(dp(64),dp(64)));

        LinearLayout info=new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dp(14),0,0,0);
        info.addView(text(m.name,16,TEXT,true));
        info.addView(text(m.displayRef(),12,MUTED,false));
        if(!m.brand.isEmpty()) info.addView(text(m.brand,12,BLUE,false));
        row.addView(info,new LinearLayout.LayoutParams(0,-2,1));

        LinearLayout stock=new LinearLayout(this);
        stock.setOrientation(LinearLayout.VERTICAL);
        stock.setGravity(Gravity.CENTER_HORIZONTAL);
        stock.addView(text("Camion",10,MUTED,false));
        stock.addView(text(m.stockCamion+" "+m.unit,14,GREEN,true));
        stock.addView(text("Agence "+m.stockAgence,10,MUTED,false));
        row.addView(stock,new LinearLayout.LayoutParams(dp(78),-2));

        row.addView(text("›",30,MUTED,false));

        card.addView(row);
        card.setOnClickListener(v->showDetail(m));
        return card;
    }

    private String categoryIcon(String c){
        String x=c.toLowerCase();
        if(x.contains("câbl")||x.contains("cabl"))return "◉";
        if(x.contains("accès")||x.contains("acces"))return "⊟";
        if(x.contains("autom"))return "▦";
        if(x.contains("commande"))return "●";
        if(x.contains("coffret"))return "□";
        return "▣";
    }

    private void showDetail(MaterialItem m){
        currentPage=Page.DETAIL;
        clear();

        LinearLayout top=new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);

        TextView back=text("‹",38,TEXT,false);
        back.setGravity(Gravity.CENTER);
        back.setOnClickListener(v->showCatalogue());
        top.addView(back,new LinearLayout.LayoutParams(dp(44),dp(50)));

        top.addView(text("Fiche matériel",22,TEXT,true),new LinearLayout.LayoutParams(0,-2,1));

        TextView fav=text(m.favorite?"★":"☆",28,TEXT,false);
        fav.setGravity(Gravity.CENTER);
        fav.setOnClickListener(v->{
            m.favorite=!m.favorite;
            LocalStore.save(this,materials);
            showDetail(m);
        });
        top.addView(fav,new LinearLayout.LayoutParams(dp(48),dp(48)));

        content.addView(top);

        LinearLayout hero=card();
        hero.setPadding(dp(16),dp(16),dp(16),dp(16));

        LinearLayout row=new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);

        TextView pic=text(categoryIcon(m.category),42,BLUE,true);
        pic.setGravity(Gravity.CENTER);
        pic.setBackground(round(BLUE_SOFT,18));
        row.addView(pic,new LinearLayout.LayoutParams(dp(84),dp(84)));

        LinearLayout info=new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dp(16),0,0,0);
        info.addView(text(m.name,21,TEXT,true));
        info.addView(text(m.displayRef(),13,MUTED,false));
        if(!m.brand.isEmpty()) info.addView(text(m.brand,14,BLUE,false));
        row.addView(info,new LinearLayout.LayoutParams(0,-2,1));

        hero.addView(row);
        content.addView(hero,gap(12));

        // Stock section first and visually stronger
        content.addView(sectionTitle("Stock"),gap(18));

        LinearLayout stockRow=new LinearLayout(this);
        stockRow.setGravity(Gravity.CENTER);

        stockRow.addView(stockCard("Camion",m.stockCamion,m.unit,GREEN),new LinearLayout.LayoutParams(0,-2,1));

        LinearLayout.LayoutParams agp=new LinearLayout.LayoutParams(0,-2,1);
        agp.leftMargin=dp(10);
        stockRow.addView(stockCard("Agence",m.stockAgence,m.unit,BLUE),agp);

        content.addView(stockRow,gap(8));

        if(m.totalStock() <= m.minStock && m.minStock > 0){
            TextView alert=text("⚠ Stock total bas — mini : "+m.minStock+" "+m.unit,13,ORANGE,true);
            alert.setPadding(dp(14),dp(10),dp(14),dp(10));
            alert.setBackground(round(Color.rgb(255,243,230),14));
            content.addView(alert,gap(10));
        }

        content.addView(sectionTitle("Informations"),gap(20));
        content.addView(detailLine("Catégorie",m.category));
        content.addView(detailLine("Marque",m.brand));
        content.addView(detailLine("Référence",m.reference));
        content.addView(detailLine("Unité",m.unit));
        content.addView(detailLine("Stock mini",String.valueOf(m.minStock)));

        if(!m.keywords.isEmpty()){
            content.addView(sectionTitle("Mots-clés"),gap(18));
            TextView keys=text(m.keywords,13,MUTED,false);
            keys.setPadding(dp(12),dp(10),dp(12),dp(10));
            keys.setBackground(round(BLUE_SOFT,16));
            content.addView(keys,gap(6));
        }

        if(!m.alias.isEmpty()){
            content.addView(sectionTitle("Alias"),gap(16));
            content.addView(text(m.alias,14,MUTED,false),gap(4));
        }

        LinearLayout actions=new LinearLayout(this);

        Button edit=outlineButton("Modifier");
        edit.setOnClickListener(v->editMaterial(m));

        Button add=primaryButton("+ Ajouter au chantier");
        add.setOnClickListener(v->{
            chantierSelection.put(m.id,chantierSelection.getOrDefault(m.id,0)+1);
            Toast.makeText(this,"Ajouté au chantier",Toast.LENGTH_SHORT).show();
        });

        actions.addView(edit,new LinearLayout.LayoutParams(0,dp(50),1));
        LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(0,dp(50),1);
        ap.leftMargin=dp(8);
        actions.addView(add,ap);

        content.addView(actions,gap(20));
    }

    private LinearLayout stockCard(String label,int qty,String unit,int color){
        LinearLayout c=card();
        c.setPadding(dp(16),dp(16),dp(16),dp(16));
        c.setGravity(Gravity.CENTER);

        TextView l=text(label,13,MUTED,true);
        l.setGravity(Gravity.CENTER);
        c.addView(l);

        TextView q=text(qty+" "+unit,27,color,true);
        q.setGravity(Gravity.CENTER);
        c.addView(q,gap(6));

        return c;
    }

    private TextView sectionTitle(String s){
        return text(s,15,TEXT,true);
    }

    private LinearLayout detailLine(String k,String v){
        LinearLayout row=new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14),dp(13),dp(14),dp(13));
        row.setBackgroundColor(WHITE);

        row.addView(text(k,14,TEXT,false),new LinearLayout.LayoutParams(0,-2,1));
        row.addView(text(v==null||v.isEmpty()?"—":v,14,MUTED,false));

        return row;
    }

    private void showChantiers(){
        currentPage=Page.CHANTIERS;
        clear();

        content.addView(text("Mes chantiers",24,TEXT,true));
        content.addView(text("Matériel à préparer / emporter",13,MUTED,false),gap(4));

        if(chantierSelection.isEmpty()){
            TextView e=text("Aucun matériel sélectionné.\nAjoute des références depuis le catalogue.",15,MUTED,false);
            e.setGravity(Gravity.CENTER);
            e.setPadding(0,dp(50),0,dp(30));
            content.addView(e);

            Button go=primaryButton("Ouvrir le catalogue");
            go.setOnClickListener(v->showCatalogue());
            content.addView(go,new LinearLayout.LayoutParams(-1,dp(50)));
            return;
        }

        for(Map.Entry<Long,Integer> en:new ArrayList<>(chantierSelection.entrySet())){
            MaterialItem m=find(en.getKey());
            if(m==null) continue;

            LinearLayout card=card();
            card.setPadding(dp(14),dp(14),dp(14),dp(14));

            LinearLayout row=new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);

            LinearLayout info=new LinearLayout(this);
            info.setOrientation(LinearLayout.VERTICAL);
            info.addView(text(m.alias.isEmpty()?m.name:m.alias,16,TEXT,true));
            info.addView(text(m.reference+" • "+en.getValue()+" "+m.unit,12,MUTED,false));
            info.addView(text("Camion dispo : "+m.stockCamion+" "+m.unit,11,GREEN,false));
            row.addView(info,new LinearLayout.LayoutParams(0,-2,1));

            Button minus=smallButton("−");
            Button plus=smallButton("+");

            minus.setOnClickListener(v->{
                int q=chantierSelection.getOrDefault(m.id,0);
                if(q<=1) chantierSelection.remove(m.id);
                else chantierSelection.put(m.id,q-1);
                showChantiers();
            });

            plus.setOnClickListener(v->{
                chantierSelection.put(m.id,chantierSelection.getOrDefault(m.id,0)+1);
                showChantiers();
            });

            row.addView(minus,new LinearLayout.LayoutParams(dp(44),dp(42)));
            LinearLayout.LayoutParams pl=new LinearLayout.LayoutParams(dp(44),dp(42));
            pl.leftMargin=dp(6);
            row.addView(plus,pl);

            card.addView(row);
            content.addView(card,gap(10));
        }

        Button report=primaryButton("Créer le compte rendu");
        report.setOnClickListener(v->showReport());
        content.addView(report,new LinearLayout.LayoutParams(-1,dp(52)));
    }

    private void showReport(){
        currentPage=Page.REPORT;
        clear();

        content.addView(text("Compte rendu",24,TEXT,true));

        EditText chantier=field("Nom du chantier / site");
        content.addView(chantier,new LinearLayout.LayoutParams(-1,dp(56)));

        EditText notes=field("Notes complémentaires");
        notes.setMinLines(4);
        notes.setSingleLine(false);
        content.addView(notes,gap(10));

        EditText output=field("");
        output.setMinLines(10);
        output.setSingleLine(false);
        output.setTextIsSelectable(true);
        content.addView(output,gap(10));

        Button gen=primaryButton("Générer");
        gen.setOnClickListener(v->output.setText(buildReport(
            chantier.getText().toString(),
            notes.getText().toString()
        )));
        content.addView(gen,new LinearLayout.LayoutParams(-1,dp(50)));

        Button copy=outlineButton("Copier le texte");
        copy.setOnClickListener(v->{
            String t=output.getText().toString();
            if(t.trim().isEmpty())
                t=buildReport(chantier.getText().toString(),notes.getText().toString());

            output.setText(t);

            android.content.ClipboardManager cm=
                (android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("Allocat",t));

            Toast.makeText(this,"Compte rendu copié",Toast.LENGTH_SHORT).show();
        });
        content.addView(copy,gap(8));
    }

    private String buildReport(String chantier,String notes){
        StringBuilder b=new StringBuilder();

        if(!chantier.trim().isEmpty())
            b.append("Chantier : ").append(chantier.trim()).append("\n\n");

        b.append("Matériel :\n");

        if(chantierSelection.isEmpty())
            b.append("- Aucun matériel sélectionné\n");

        for(Map.Entry<Long,Integer> e:chantierSelection.entrySet()){
            MaterialItem m=find(e.getKey());
            if(m==null) continue;

            b.append("- ")
             .append(e.getValue()).append(" ").append(m.unit)
             .append(" × ")
             .append(m.alias.isEmpty()?m.name:m.alias);

            if(!m.reference.isEmpty())
                b.append(" (").append(m.reference).append(")");

            b.append(" — Camion dispo : ")
             .append(m.stockCamion).append(" ").append(m.unit)
             .append("\n");
        }

        if(!notes.trim().isEmpty())
            b.append("\nNotes :\n").append(notes.trim());

        return b.toString();
    }

    private void showStats(){
        currentPage=Page.STATS;
        clear();

        content.addView(text("Stocks",24,TEXT,true));
        content.addView(text("Vue rapide de ton matériel",13,MUTED,false),gap(4));

        int camion=0,agence=0,low=0;
        for(MaterialItem m:materials){
            camion+=m.stockCamion;
            agence+=m.stockAgence;
            if(m.totalStock()<=m.minStock && m.minStock>0) low++;
        }

        content.addView(statCard("Références",String.valueOf(materials.size()),BLUE),gap(14));
        content.addView(statCard("Stock camion",String.valueOf(camion),GREEN),gap(10));
        content.addView(statCard("Stock agence",String.valueOf(agence),BLUE),gap(10));
        content.addView(statCard("Alertes stock",String.valueOf(low),ORANGE),gap(10));
    }

    private LinearLayout statCard(String label,String value,int color){
        LinearLayout c=card();
        c.setGravity(Gravity.CENTER_VERTICAL);
        c.setPadding(dp(18),dp(18),dp(18),dp(18));

        c.addView(text(label,16,TEXT,true),new LinearLayout.LayoutParams(0,-2,1));
        c.addView(text(value,26,color,true));

        return c;
    }

    private void showSettings(){
        currentPage=Page.SETTINGS;
        clear();

        content.addView(text("Réglages",24,TEXT,true));
        content.addView(detailLine("Application","Allocat"));
        content.addView(detailLine("Version","0.1.3"));
        content.addView(detailLine("Données","100% locales"));

        Button clear=outlineButton("Vider complètement le catalogue");
        clear.setOnClickListener(v->new AlertDialog.Builder(this)
            .setTitle("Vider le catalogue ?")
            .setMessage("Toutes les références enregistrées seront supprimées.")
            .setNegativeButton("Annuler",null)
            .setPositiveButton("Vider",(d,w)->{
                LocalStore.clear(this);
                materials.clear();
                chantierSelection.clear();
                Toast.makeText(this,"Catalogue vidé",Toast.LENGTH_SHORT).show();
                showHome();
            }).show());

        content.addView(clear,gap(16));
    }

    private void editMaterial(MaterialItem original){
        LinearLayout f=new LinearLayout(this);
        f.setOrientation(LinearLayout.VERTICAL);
        f.setPadding(dp(18),0,dp(18),0);

        EditText name=dialogField("Désignation",original==null?"":original.name);
        EditText ref=dialogField("Référence",original==null?"":original.reference);
        EditText brand=dialogField("Marque",original==null?"":original.brand);
        EditText cat=dialogField("Catégorie",original==null?"":original.category);
        EditText alias=dialogField("Alias",original==null?"":original.alias);
        EditText keys=dialogField("Mots-clés",original==null?"":original.keywords);
        EditText unit=dialogField("Unité (u, m…)",original==null?"u":original.unit);
        EditText camion=dialogField("Stock camion",original==null?"0":String.valueOf(original.stockCamion));
        EditText agence=dialogField("Stock agence",original==null?"0":String.valueOf(original.stockAgence));
        EditText min=dialogField("Stock mini total",original==null?"0":String.valueOf(original.minStock));

        for(EditText e:new EditText[]{name,ref,brand,cat,alias,keys,unit,camion,agence,min})
            f.addView(e);

        AlertDialog d=new AlertDialog.Builder(this)
            .setTitle(original==null?"Ajouter du matériel":"Modifier le matériel")
            .setView(f)
            .setNegativeButton("Annuler",null)
            .setPositiveButton("Enregistrer",null)
            .create();

        d.setOnShowListener(x->d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            if(name.getText().toString().trim().isEmpty()){
                name.setError("Obligatoire");
                return;
            }

            int sc=parseInt(camion.getText().toString());
            int sa=parseInt(agence.getText().toString());
            int mi=parseInt(min.getText().toString());

            if(original==null){
                materials.add(new MaterialItem(
                    System.currentTimeMillis(),
                    name.getText().toString().trim(),
                    ref.getText().toString().trim(),
                    brand.getText().toString().trim(),
                    cat.getText().toString().trim(),
                    alias.getText().toString().trim(),
                    keys.getText().toString().trim(),
                    unit.getText().toString().trim(),
                    sc,sa,mi
                ));
            }else{
                original.name=name.getText().toString().trim();
                original.reference=ref.getText().toString().trim();
                original.brand=brand.getText().toString().trim();
                original.category=cat.getText().toString().trim();
                original.alias=alias.getText().toString().trim();
                original.keywords=keys.getText().toString().trim();
                original.unit=unit.getText().toString().trim().isEmpty()?"u":unit.getText().toString().trim();
                original.stockCamion=sc;
                original.stockAgence=sa;
                original.minStock=mi;
            }

            LocalStore.save(this,materials);
            d.dismiss();
            showCatalogue();
        }));

        d.show();
    }

    private int parseInt(String s){
        try{ return Integer.parseInt(s.trim()); }
        catch(Exception e){ return 0; }
    }

    private MaterialItem find(long id){
        for(MaterialItem m:materials) if(m.id==id) return m;
        return null;
    }

    private LinearLayout card(){
        LinearLayout c=new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(roundStroke(WHITE,BORDER,20,1));
        return c;
    }

    private EditText field(String hint){
        EditText e=new EditText(this);
        e.setHint(hint);
        e.setTextColor(TEXT);
        e.setHintTextColor(Color.rgb(142,153,171));
        e.setTextSize(15);
        e.setPadding(dp(16),dp(12),dp(16),dp(12));
        e.setBackground(roundStroke(WHITE,BORDER,18,1));
        e.setSingleLine(true);
        return e;
    }

    private EditText dialogField(String h,String v){
        EditText e=field(h);
        e.setText(v);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(54));
        p.bottomMargin=dp(8);
        e.setLayoutParams(p);
        return e;
    }

    private Button primaryButton(String s){
        Button b=new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextColor(WHITE);
        b.setTextSize(14);
        b.setBackground(round(BLUE,14));
        return b;
    }

    private Button outlineButton(String s){
        Button b=new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextColor(BLUE);
        b.setTextSize(14);
        b.setBackground(roundStroke(WHITE,BLUE,14,1));
        return b;
    }

    private Button smallButton(String s){
        Button b=new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextColor(BLUE);
        b.setTextSize(20);
        b.setPadding(0,0,0,0);
        b.setBackground(round(BLUE_SOFT,12));
        return b;
    }

    private TextView text(String s,int sp,int color,boolean bold){
        TextView t=new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if(bold) t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        return t;
    }

    private LinearLayout.LayoutParams gap(int top){
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);
        p.topMargin=dp(top);
        return p;
    }

    private GradientDrawable round(int c,int r){
        GradientDrawable d=new GradientDrawable();
        d.setColor(c);
        d.setCornerRadius(dp(r));
        return d;
    }

    private GradientDrawable roundStroke(int c,int s,int r,int w){
        GradientDrawable d=round(c,r);
        d.setStroke(dp(w),s);
        return d;
    }

    private int dp(int v){
        return Math.round(v*getResources().getDisplayMetrics().density);
    }
}
