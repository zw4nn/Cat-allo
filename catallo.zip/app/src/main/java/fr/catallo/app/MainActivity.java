package fr.catallo.app;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.net.Uri;
import android.graphics.*;
import android.graphics.drawable.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {

    private final int BG=Color.rgb(246,248,252);
    private final int WHITE=Color.WHITE;
    private final int TEXT=Color.rgb(25,39,64);
    private final int MUTED=Color.rgb(96,111,135);
    private final int BLUE=Color.rgb(52,96,181);
    private final int BLUE_SOFT=Color.rgb(228,235,249);
    private final int BORDER=Color.rgb(222,228,237);
    private final int GREEN=Color.rgb(37,132,101);
    private final int ORANGE=Color.rgb(190,111,45);
    private final int RED=Color.rgb(174,55,65);

    private LinearLayout shell, topBar, content, bottomBar;
    private ArrayList<MaterialItem> materials;
    private LinkedHashMap<Long,Integer> chantierSelection=new LinkedHashMap<>();
    private MaterialItem currentDetail;
    private static final int REQ_IMPORT=501, REQ_EXPORT=502;
    private String pendingFormat="json";
    private boolean pendingTemplate=false;

    private enum Page { HOME, CATALOGUE, DETAIL, EDIT, CHANTIERS, REPORT, STOCKS, SETTINGS, TRANSFER }
    private Page page=Page.HOME;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);

        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(WHITE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        materials=LocalStore.load(this);
        buildShell();
        showHome();
    }

    private void buildShell(){
        shell=new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        shell.setBackgroundColor(BG);

        topBar=new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setPadding(dp(18),dp(8),dp(16),dp(8));
        topBar.setBackgroundColor(BG);
        shell.addView(topBar,new LinearLayout.LayoutParams(-1,dp(78)));

        ScrollView scroll=new ScrollView(this);
        scroll.setFillViewport(true);
        content=new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(18),dp(12),dp(18),dp(24));
        scroll.addView(content);
        shell.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

        bottomBar=new LinearLayout(this);
        bottomBar.setGravity(Gravity.CENTER);
        bottomBar.setPadding(dp(8),dp(4),dp(8),dp(4));
        bottomBar.setBackgroundColor(WHITE);
        shell.addView(bottomBar,new LinearLayout.LayoutParams(-1,dp(62)));

        // Android 15 edge-to-edge: keep our fixed bars outside system bars.
        shell.setOnApplyWindowInsetsListener((v,insets)->{
            int top=insets.getSystemWindowInsetTop();
            int bottom=insets.getSystemWindowInsetBottom();
            v.setPadding(0,top,0,bottom);
            return insets;
        });

        setContentView(shell);
        renderBottomNav(0);
    }

    @Override public void onBackPressed(){
        if(page==Page.HOME){
            super.onBackPressed();
            return;
        }
        if(page==Page.DETAIL || page==Page.EDIT){
            showCatalogue();
            return;
        }
        showHome();
    }

    private void clearContent(){ content.removeAllViews(); }

    private void setTopHome(){
        topBar.removeAllViews();

        ImageView logo=new ImageView(this);
        logo.setImageResource(R.drawable.allocat_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        topBar.addView(logo,new LinearLayout.LayoutParams(dp(58),dp(58)));

        LinearLayout brand=new LinearLayout(this);
        brand.setOrientation(LinearLayout.VERTICAL);
        brand.setPadding(dp(12),0,0,0);
        brand.addView(text("Allocat",26,TEXT,true));
        brand.addView(text("Matériel & chantiers",12,MUTED,false));
        topBar.addView(brand,new LinearLayout.LayoutParams(0,-2,1));

        TextView ver=text("0.1.5",11,BLUE,true);
        ver.setPadding(dp(10),dp(7),dp(10),dp(7));
        ver.setBackground(round(BLUE_SOFT,14));
        topBar.addView(ver);
    }

    private void setTop(String title,String subtitle,Runnable back,Runnable action,String actionLabel){
        topBar.removeAllViews();

        if(back!=null){
            TextView b=text("‹",36,TEXT,false);
            b.setGravity(Gravity.CENTER);
            b.setOnClickListener(v->back.run());
            topBar.addView(b,new LinearLayout.LayoutParams(dp(46),dp(54)));
        }

        LinearLayout t=new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.addView(text(title,21,TEXT,true));
        if(subtitle!=null && !subtitle.isEmpty()) t.addView(text(subtitle,11,MUTED,false));
        topBar.addView(t,new LinearLayout.LayoutParams(0,-2,1));

        if(action!=null){
            Button a=miniAction(actionLabel);
            a.setOnClickListener(v->action.run());
            topBar.addView(a,new LinearLayout.LayoutParams(-2,dp(42)));
        }
    }

    private void renderBottomNav(int selected){
        bottomBar.removeAllViews();
        String[] labels={"Accueil","Catalogue","Chantiers","Réglages"};
        String[] icons={"⌂","▣","♜","⚙"};

        for(int i=0;i<4;i++){
            int idx=i;
            LinearLayout item=new LinearLayout(this);
            item.setOrientation(LinearLayout.HORIZONTAL);
            item.setGravity(Gravity.CENTER);
            item.setPadding(dp(8),0,dp(8),0);

            int color=i==selected?BLUE:MUTED;
            TextView ic=text(icons[i],18,color,true);
            item.addView(ic);

            TextView label=text(labels[i],11,color,i==selected);
            LinearLayout.LayoutParams llp=new LinearLayout.LayoutParams(-2,-2);
            llp.leftMargin=dp(5);
            item.addView(label,llp);

            if(i==selected) item.setBackground(round(BLUE_SOFT,16));

            item.setOnClickListener(v->{
                if(idx==0) showHome();
                else if(idx==1) showCatalogue();
                else if(idx==2) showChantiers();
                else showSettings();
            });
            bottomBar.addView(item,new LinearLayout.LayoutParams(0,dp(46),1));
        }
    }

    private void showHome(){
        page=Page.HOME; currentDetail=null;
        setTopHome(); renderBottomNav(0); clearContent();

        EditText q=field("Rechercher une référence, une marque…");
        q.setSingleLine(true);
        content.addView(q,new LinearLayout.LayoutParams(-1,dp(58)));
        q.setOnEditorActionListener((v,a,e)->{
            showCatalogue(q.getText().toString());
            return true;
        });

        content.addView(homeCard("▣","Mon matériel","Créer et retrouver mes références",this::showCatalogue),gap(16));
        content.addView(homeCard("♜","Mes chantiers","Préparer ce que j'emporte",this::showChantiers),gap(10));
        content.addView(homeCard("▥","Mes stocks","Camion, agence et alertes",this::showStocks),gap(10));
        content.addView(homeCard("⇅","Importer / Exporter","JSON, CSV et Excel",this::showTransfer),gap(10));
        content.addView(homeCard("☷","Compte rendu","Générer un relevé de chantier",this::showReport),gap(10));
    }

    private LinearLayout homeCard(String icon,String title,String sub,Runnable run){
        LinearLayout c=card();
        c.setPadding(dp(16),dp(15),dp(14),dp(15));

        LinearLayout row=new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);

        TextView ic=text(icon,24,BLUE,true);
        ic.setGravity(Gravity.CENTER);
        ic.setBackground(round(BLUE_SOFT,16));
        row.addView(ic,new LinearLayout.LayoutParams(dp(56),dp(56)));

        LinearLayout tx=new LinearLayout(this);
        tx.setOrientation(LinearLayout.VERTICAL);
        tx.setPadding(dp(14),0,0,0);
        tx.addView(text(title,18,TEXT,true));
        tx.addView(text(sub,12,MUTED,false));
        row.addView(tx,new LinearLayout.LayoutParams(0,-2,1));

        row.addView(text("›",30,MUTED,false));
        c.addView(row);
        c.setOnClickListener(v->run.run());
        return c;
    }

    private void showCatalogue(){ showCatalogue(""); }

    private void showCatalogue(String initial){
        page=Page.CATALOGUE; currentDetail=null;
        setTop("Catalogue","Mes références",this::showHome,()->showEdit(null),"+ Ajouter");
        renderBottomNav(1); clearContent();

        if(materials.isEmpty()){
            LinearLayout empty=card();
            empty.setPadding(dp(24),dp(28),dp(24),dp(28));

            TextView ico=text("▣",40,BLUE,true); ico.setGravity(Gravity.CENTER);
            empty.addView(ico);

            TextView ti=text("Catalogue vide",20,TEXT,true); ti.setGravity(Gravity.CENTER);
            empty.addView(ti,gap(12));

            TextView su=text("Crée ta première référence. Tu pourras ensuite suivre séparément ce qui est dans ton camion et ce qui reste à l'agence.",14,MUTED,false);
            su.setGravity(Gravity.CENTER);
            empty.addView(su,gap(8));

            Button add=primaryButton("Créer ma première référence");
            add.setOnClickListener(v->showEdit(null));
            LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,dp(52)); ap.topMargin=dp(22);
            empty.addView(add,ap);

            content.addView(empty,gap(18));
            return;
        }

        EditText search=field("Rechercher dans le catalogue");
        search.setText(initial);
        content.addView(search,new LinearLayout.LayoutParams(-1,dp(56)));

        LinearLayout info=new LinearLayout(this);
        info.setGravity(Gravity.CENTER_VERTICAL);
        TextView count=text("",12,BLUE,true);
        info.addView(count,new LinearLayout.LayoutParams(0,-2,1));
        info.addView(text("A → Z",12,MUTED,true));
        content.addView(info,gap(10));

        LinearLayout list=new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        content.addView(list,gap(8));

        Runnable render=()->{
            list.removeAllViews();
            int n=0;
            for(MaterialItem m:materials){
                if(!m.matches(search.getText().toString())) continue;
                n++;
                list.addView(materialRow(m),gap(8));
            }
            count.setText(n+" référence"+(n>1?"s":""));
            if(n==0){
                TextView e=text("Aucun résultat",14,MUTED,false);
                e.setGravity(Gravity.CENTER); e.setPadding(0,dp(36),0,0);
                list.addView(e);
            }
        };

        search.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int a,int b,int c){}
            public void onTextChanged(CharSequence s,int a,int b,int c){ render.run(); }
            public void afterTextChanged(Editable e){}
        });
        render.run();
    }

    private LinearLayout materialRow(MaterialItem m){
        LinearLayout c=card();
        c.setPadding(dp(13),dp(12),dp(12),dp(12));

        LinearLayout row=new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);

        TextView ico=text("▣",22,BLUE,true);
        ico.setGravity(Gravity.CENTER);
        ico.setBackground(round(BLUE_SOFT,14));
        row.addView(ico,new LinearLayout.LayoutParams(dp(54),dp(54)));

        LinearLayout tx=new LinearLayout(this);
        tx.setOrientation(LinearLayout.VERTICAL);
        tx.setPadding(dp(12),0,0,0);
        tx.addView(text(m.name,15,TEXT,true));
        tx.addView(text(m.displayRef()+(m.brand.isEmpty()?"":" • "+m.brand),11,MUTED,false));
        row.addView(tx,new LinearLayout.LayoutParams(0,-2,1));

        LinearLayout stock=new LinearLayout(this);
        stock.setOrientation(LinearLayout.VERTICAL);
        stock.setGravity(Gravity.RIGHT);
        stock.addView(text("Camion "+m.stockCamion+" "+m.unit,11,GREEN,true));
        stock.addView(text("Agence "+m.stockAgence+" "+m.unit,10,MUTED,false));
        row.addView(stock);

        TextView arrow=text("›",27,MUTED,false);
        LinearLayout.LayoutParams ar=new LinearLayout.LayoutParams(-2,-2); ar.leftMargin=dp(8);
        row.addView(arrow,ar);

        c.addView(row);
        c.setOnClickListener(v->showDetail(m));
        return c;
    }

    private void showDetail(MaterialItem m){
        page=Page.DETAIL; currentDetail=m;
        setTop("Fiche matériel",m.reference.isEmpty()?"":m.reference,this::showCatalogue,()->showEdit(m),"Modifier");
        renderBottomNav(1); clearContent();

        LinearLayout hero=card();
        hero.setPadding(dp(16),dp(16),dp(16),dp(16));

        TextView name=text(m.name,22,TEXT,true);
        hero.addView(name);
        if(!m.alias.isEmpty()) hero.addView(text(m.alias,13,BLUE,true),gap(4));
        hero.addView(text(m.displayRef()+(m.brand.isEmpty()?"":" • "+m.brand),12,MUTED,false),gap(5));
        content.addView(hero);

        content.addView(sectionTitle("Stocks"),gap(18));
        LinearLayout sr=new LinearLayout(this);
        sr.addView(stockTile("Camion",m.stockCamion,m.unit,GREEN),new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout.LayoutParams sa=new LinearLayout.LayoutParams(0,-2,1); sa.leftMargin=dp(10);
        sr.addView(stockTile("Agence",m.stockAgence,m.unit,BLUE),sa);
        content.addView(sr,gap(8));

        if(m.minStock>0 && m.totalStock()<=m.minStock){
            TextView alert=text("Stock total bas • mini "+m.minStock+" "+m.unit,12,ORANGE,true);
            alert.setPadding(dp(12),dp(10),dp(12),dp(10));
            alert.setBackground(round(Color.rgb(255,244,232),14));
            content.addView(alert,gap(10));
        }

        content.addView(sectionTitle("Informations"),gap(18));
        LinearLayout infos=card();
        infos.addView(detailLine("Catégorie",m.category));
        infos.addView(divider());
        infos.addView(detailLine("Marque",m.brand));
        infos.addView(divider());
        infos.addView(detailLine("Référence",m.reference));
        infos.addView(divider());
        infos.addView(detailLine("Unité",m.unit));
        infos.addView(divider());
        infos.addView(detailLine("Stock mini",String.valueOf(m.minStock)));
        content.addView(infos,gap(8));

        if(!m.keywords.isEmpty()){
            content.addView(sectionTitle("Mots-clés"),gap(18));
            TextView k=text(m.keywords,12,MUTED,false);
            k.setPadding(dp(12),dp(10),dp(12),dp(10));
            k.setBackground(round(BLUE_SOFT,14));
            content.addView(k,gap(6));
        }

        Button add=primaryButton("Ajouter au chantier");
        add.setOnClickListener(v->{
            chantierSelection.put(m.id,chantierSelection.getOrDefault(m.id,0)+1);
            Toast.makeText(this,"Ajouté au chantier",Toast.LENGTH_SHORT).show();
        });
        content.addView(add,new LinearLayout.LayoutParams(-1,dp(52)));
    }

    private LinearLayout stockTile(String label,int qty,String unit,int color){
        LinearLayout c=card();
        c.setPadding(dp(15),dp(14),dp(15),dp(14));
        c.setGravity(Gravity.CENTER);
        TextView l=text(label,12,MUTED,true); l.setGravity(Gravity.CENTER); c.addView(l);
        TextView q=text(qty+" "+unit,24,color,true); q.setGravity(Gravity.CENTER); c.addView(q,gap(4));
        return c;
    }

    private void showEdit(MaterialItem original){
        page=Page.EDIT;
        setTop(original==null?"Nouveau matériel":"Modifier","Saisie de la fiche",()->{
            if(original==null) showCatalogue(); else showDetail(original);
        },null,null);
        renderBottomNav(1); clearContent();

        content.addView(sectionTitle("Identification"));
        LinearLayout idCard=card();
        EditText name=labeledField(idCard,"Désignation *","Ex. Ventouse 300 kg",original==null?"":original.name);
        EditText ref=labeledField(idCard,"Référence","Ex. EF3003",original==null?"":original.reference);
        EditText brand=labeledField(idCard,"Marque","Ex. CDVI",original==null?"":original.brand);
        EditText cat=labeledField(idCard,"Catégorie","Ex. Contrôle d'accès",original==null?"":original.category);
        content.addView(idCard,gap(8));

        content.addView(sectionTitle("Stock"),gap(18));
        LinearLayout stockCard=card();
        TextView hint=text("Indique où se trouve réellement ton matériel.",12,MUTED,false);
        hint.setPadding(dp(14),dp(12),dp(14),0);
        stockCard.addView(hint);

        EditText camion=labeledNumber(stockCard,"Dans le camion",original==null?0:original.stockCamion);
        EditText agence=labeledNumber(stockCard,"À l'agence",original==null?0:original.stockAgence);
        EditText mini=labeledNumber(stockCard,"Alerte stock mini total",original==null?0:original.minStock);
        EditText unit=labeledField(stockCard,"Unité","u, m, rouleau…",original==null?"u":original.unit);
        content.addView(stockCard,gap(8));

        content.addView(sectionTitle("Recherche"),gap(18));
        LinearLayout searchCard=card();
        EditText alias=labeledField(searchCard,"Alias / nom court","Ex. Ventouse porte",original==null?"":original.alias);
        EditText keys=labeledField(searchCard,"Mots-clés","Ex. accès porte magnétique",original==null?"":original.keywords);
        content.addView(searchCard,gap(8));

        Button save=primaryButton(original==null?"Créer la référence":"Enregistrer les modifications");
        save.setOnClickListener(v->{
            String n=name.getText().toString().trim();
            if(n.isEmpty()){ name.setError("La désignation est obligatoire"); return; }

            if(original==null){
                materials.add(new MaterialItem(
                    System.currentTimeMillis(),n,ref.getText().toString().trim(),
                    brand.getText().toString().trim(),cat.getText().toString().trim(),
                    alias.getText().toString().trim(),keys.getText().toString().trim(),
                    unit.getText().toString().trim(),
                    parseInt(camion),parseInt(agence),parseInt(mini)
                ));
            }else{
                original.name=n; original.reference=ref.getText().toString().trim();
                original.brand=brand.getText().toString().trim();
                original.category=cat.getText().toString().trim();
                original.alias=alias.getText().toString().trim();
                original.keywords=keys.getText().toString().trim();
                original.unit=unit.getText().toString().trim().isEmpty()?"u":unit.getText().toString().trim();
                original.stockCamion=parseInt(camion);
                original.stockAgence=parseInt(agence);
                original.minStock=parseInt(mini);
            }

            LocalStore.save(this,materials);
            Toast.makeText(this,"Matériel enregistré",Toast.LENGTH_SHORT).show();
            showCatalogue();
        });
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,dp(54)); sp.topMargin=dp(20);
        content.addView(save,sp);

        if(original!=null){
            Button del=outlineDanger("Supprimer cette référence");
            del.setOnClickListener(v->new AlertDialog.Builder(this)
                .setTitle("Supprimer ?")
                .setMessage(original.name)
                .setNegativeButton("Annuler",null)
                .setPositiveButton("Supprimer",(d,w)->{
                    chantierSelection.remove(original.id);
                    materials.remove(original);
                    LocalStore.save(this,materials);
                    showCatalogue();
                }).show());
            content.addView(del,gap(10));
        }
    }

    private EditText labeledField(LinearLayout parent,String label,String hint,String value){
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14),dp(10),dp(14),dp(10));
        box.addView(text(label,12,TEXT,true));
        EditText e=field(hint);
        e.setText(value);
        LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(-1,dp(50)); ep.topMargin=dp(5);
        box.addView(e,ep);
        parent.addView(box);
        return e;
    }

    private EditText labeledNumber(LinearLayout parent,String label,int value){
        EditText e=labeledField(parent,label,"0",String.valueOf(value));
        e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        return e;
    }

    private void showChantiers(){
        page=Page.CHANTIERS;
        setTop("Chantiers","Matériel à préparer",this::showHome,null,null);
        renderBottomNav(2); clearContent();

        if(chantierSelection.isEmpty()){
            LinearLayout empty=card();
            empty.setPadding(dp(22),dp(28),dp(22),dp(28));
            TextView t=text("Aucun matériel sélectionné",18,TEXT,true); t.setGravity(Gravity.CENTER); empty.addView(t);
            TextView s=text("Ajoute des références depuis le catalogue pour préparer ton chantier.",13,MUTED,false); s.setGravity(Gravity.CENTER); empty.addView(s,gap(8));
            Button go=primaryButton("Ouvrir le catalogue"); go.setOnClickListener(v->showCatalogue());
            LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(-1,dp(50)); gp.topMargin=dp(20); empty.addView(go,gp);
            content.addView(empty,gap(18));
            return;
        }

        for(Map.Entry<Long,Integer> en:new ArrayList<>(chantierSelection.entrySet())){
            MaterialItem m=find(en.getKey()); if(m==null) continue;
            LinearLayout c=card(); c.setPadding(dp(14),dp(13),dp(14),dp(13));

            LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
            LinearLayout tx=new LinearLayout(this); tx.setOrientation(LinearLayout.VERTICAL);
            tx.addView(text(m.alias.isEmpty()?m.name:m.alias,15,TEXT,true));
            tx.addView(text(en.getValue()+" "+m.unit+" • camion "+m.stockCamion+" "+m.unit,11,MUTED,false));
            row.addView(tx,new LinearLayout.LayoutParams(0,-2,1));

            Button minus=smallButton("−"); Button plus=smallButton("+");
            minus.setOnClickListener(v->{ int q=chantierSelection.getOrDefault(m.id,0); if(q<=1)chantierSelection.remove(m.id); else chantierSelection.put(m.id,q-1); showChantiers(); });
            plus.setOnClickListener(v->{ chantierSelection.put(m.id,chantierSelection.getOrDefault(m.id,0)+1); showChantiers(); });
            row.addView(minus,new LinearLayout.LayoutParams(dp(42),dp(40)));
            LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(dp(42),dp(40)); pp.leftMargin=dp(6); row.addView(plus,pp);
            c.addView(row);
            content.addView(c,gap(8));
        }

        Button report=primaryButton("Créer le compte rendu");
        report.setOnClickListener(v->showReport());
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(52)); rp.topMargin=dp(18); content.addView(report,rp);
    }

    private void showStocks(){
        page=Page.STOCKS;
        setTop("Mes stocks","Camion & agence",this::showHome,null,null);
        renderBottomNav(0); clearContent();

        int camion=0,agence=0,alertes=0;
        for(MaterialItem m:materials){
            camion+=m.stockCamion; agence+=m.stockAgence;
            if(m.minStock>0 && m.totalStock()<=m.minStock) alertes++;
        }

        LinearLayout grid=new LinearLayout(this);
        grid.addView(stockTile("Camion",camion,"",GREEN),new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(0,-2,1); ap.leftMargin=dp(10);
        grid.addView(stockTile("Agence",agence,"",BLUE),ap);
        content.addView(grid);

        LinearLayout alert=card(); alert.setPadding(dp(16),dp(14),dp(16),dp(14));
        alert.addView(text("Alertes stock",13,MUTED,true));
        alert.addView(text(String.valueOf(alertes),28,alertes>0?ORANGE:GREEN,true),gap(4));
        content.addView(alert,gap(10));

        if(materials.isEmpty()){
            TextView e=text("Ajoute du matériel pour commencer à suivre tes stocks.",13,MUTED,false); e.setGravity(Gravity.CENTER); content.addView(e,gap(28));
        }
    }

    private void showReport(){
        page=Page.REPORT;
        setTop("Compte rendu","Chantier",this::showHome,null,null);
        renderBottomNav(2); clearContent();

        EditText chantier=field("Nom du chantier / site");
        content.addView(chantier,new LinearLayout.LayoutParams(-1,dp(54)));

        EditText notes=field("Notes complémentaires");
        notes.setSingleLine(false); notes.setMinLines(4);
        content.addView(notes,gap(10));

        EditText output=field("");
        output.setSingleLine(false); output.setMinLines(10); output.setTextIsSelectable(true);
        content.addView(output,gap(10));

        Button gen=primaryButton("Générer");
        gen.setOnClickListener(v->output.setText(buildReport(chantier.getText().toString(),notes.getText().toString())));
        content.addView(gen,new LinearLayout.LayoutParams(-1,dp(50)));

        Button copy=outlineButton("Copier le texte");
        copy.setOnClickListener(v->{
            String x=output.getText().toString();
            if(x.trim().isEmpty()) x=buildReport(chantier.getText().toString(),notes.getText().toString());
            output.setText(x);
            android.content.ClipboardManager cm=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("Allocat",x));
            Toast.makeText(this,"Compte rendu copié",Toast.LENGTH_SHORT).show();
        });
        content.addView(copy,gap(8));
    }

    private String buildReport(String chantier,String notes){
        StringBuilder b=new StringBuilder();
        if(!chantier.trim().isEmpty()) b.append("Chantier : ").append(chantier.trim()).append("\n\n");
        b.append("Matériel :\n");
        if(chantierSelection.isEmpty()) b.append("- Aucun matériel sélectionné\n");

        for(Map.Entry<Long,Integer> e:chantierSelection.entrySet()){
            MaterialItem m=find(e.getKey()); if(m==null) continue;
            b.append("- ").append(e.getValue()).append(" ").append(m.unit).append(" × ")
             .append(m.alias.isEmpty()?m.name:m.alias);
            if(!m.reference.isEmpty()) b.append(" (").append(m.reference).append(")");
            b.append("\n");
        }
        if(!notes.trim().isEmpty()) b.append("\nNotes :\n").append(notes.trim());
        return b.toString();
    }


    private void showTransfer(){
        page=Page.TRANSFER;
        setTop("Importer / Exporter","Catalogue",this::showHome,null,null);
        renderBottomNav(3);clearContent();

        LinearLayout intro=card();intro.setPadding(dp(16),dp(14),dp(16),dp(14));
        intro.addView(text("Formats compatibles",17,TEXT,true));
        intro.addView(text("JSON • CSV • Excel (.xlsx)",12,MUTED,false),gap(5));
        content.addView(intro);

        content.addView(sectionTitle("Importer"),gap(18));
        LinearLayout imp=card();imp.setPadding(dp(14),dp(14),dp(14),dp(14));
        Button a=outlineButton("Importer JSON"),b=outlineButton("Importer CSV"),x=outlineButton("Importer Excel (.xlsx)");
        a.setOnClickListener(v->startImport("json"));b.setOnClickListener(v->startImport("csv"));x.setOnClickListener(v->startImport("xlsx"));
        imp.addView(a,new LinearLayout.LayoutParams(-1,dp(48)));imp.addView(b,gap(8));imp.addView(x,gap(8));content.addView(imp,gap(8));

        content.addView(sectionTitle("Exporter"),gap(18));
        LinearLayout exp=card();exp.setPadding(dp(14),dp(14),dp(14),dp(14));
        exp.addView(text(materials.isEmpty()?"Catalogue vide : le fichier contiendra quand même les colonnes du modèle.":materials.size()+" référence(s) à exporter.",12,MUTED,false));
        Button ej=primaryButton("Exporter JSON"),ec=primaryButton("Exporter CSV"),ex=primaryButton("Exporter Excel (.xlsx)");
        ej.setOnClickListener(v->startExport("json",false));ec.setOnClickListener(v->startExport("csv",false));ex.setOnClickListener(v->startExport("xlsx",false));
        exp.addView(ej,gap(12));exp.addView(ec,gap(8));exp.addView(ex,gap(8));content.addView(exp,gap(8));

        content.addView(sectionTitle("Modèle vierge"),gap(18));
        LinearLayout mod=card();mod.setPadding(dp(14),dp(14),dp(14),dp(14));
        mod.addView(text("À remplir sur ordinateur ou téléphone puis à réimporter.",12,MUTED,false));
        Button mc=outlineButton("Télécharger modèle CSV"),mx=outlineButton("Télécharger modèle Excel");
        mc.setOnClickListener(v->startExport("csv",true));mx.setOnClickListener(v->startExport("xlsx",true));
        mod.addView(mc,gap(12));mod.addView(mx,gap(8));content.addView(mod,gap(8));
    }

    private void startImport(String f){
        pendingFormat=f;Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);
        if("json".equals(f))i.setType("application/json");
        else if("csv".equals(f))i.setType("text/*");
        else i.setType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        startActivityForResult(i,REQ_IMPORT);
    }

    private void startExport(String f,boolean model){
        pendingFormat=f;pendingTemplate=model;Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);
        if("json".equals(f))i.setType("application/json");
        else if("csv".equals(f))i.setType("text/csv");
        else i.setType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        i.putExtra(Intent.EXTRA_TITLE,(model?"allocat-modele":"allocat-catalogue")+"."+f);
        startActivityForResult(i,REQ_EXPORT);
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(resultCode!=RESULT_OK||data==null||data.getData()==null)return;
        Uri uri=data.getData();
        try{
            if(requestCode==REQ_IMPORT){
                ArrayList<MaterialItem> imported="json".equals(pendingFormat)?CatalogueIO.importJson(this,uri):("csv".equals(pendingFormat)?CatalogueIO.importCsv(this,uri):CatalogueIO.importXlsx(this,uri));
                final ArrayList<MaterialItem> imp=imported;
                new AlertDialog.Builder(this).setTitle("Importer "+imp.size()+" référence(s) ?")
                    .setMessage(materials.isEmpty()?"Le catalogue sera créé.":"Ajouter au catalogue actuel ou le remplacer complètement ?")
                    .setNegativeButton("Annuler",null)
                    .setNeutralButton("Ajouter",(d,w)->{materials.addAll(imp);LocalStore.save(this,materials);Toast.makeText(this,"Import terminé",Toast.LENGTH_SHORT).show();showCatalogue();})
                    .setPositiveButton("Remplacer",(d,w)->{materials.clear();materials.addAll(imp);LocalStore.save(this,materials);chantierSelection.clear();Toast.makeText(this,"Catalogue remplacé",Toast.LENGTH_SHORT).show();showCatalogue();}).show();
            }else if(requestCode==REQ_EXPORT){
                ArrayList<MaterialItem> src=pendingTemplate?new ArrayList<>():materials;
                if("json".equals(pendingFormat))CatalogueIO.exportJson(this,uri,src);
                else if("csv".equals(pendingFormat))CatalogueIO.exportCsv(this,uri,src);
                else CatalogueIO.exportXlsx(this,uri,src);
                Toast.makeText(this,pendingTemplate?"Modèle exporté":"Catalogue exporté",Toast.LENGTH_SHORT).show();
            }
        }catch(Exception e){
            new AlertDialog.Builder(this).setTitle("Erreur de fichier").setMessage(e.getMessage()==null?e.toString():e.getMessage()).setPositiveButton("OK",null).show();
        }
    }

    private void showSettings(){
        page=Page.SETTINGS;
        setTop("Réglages","Allocat",this::showHome,null,null);
        renderBottomNav(3); clearContent();

        LinearLayout c=card();
        c.addView(detailLine("Version","0.1.5"));
        c.addView(divider());
        c.addView(detailLine("Données","100% locales"));
        c.addView(divider());
        c.addView(detailLine("Références",String.valueOf(materials.size())));
        content.addView(c);

        Button transfer=primaryButton("Importer / Exporter");
        transfer.setOnClickListener(v->showTransfer());
        content.addView(transfer,new LinearLayout.LayoutParams(-1,dp(50)));

        Button clear=outlineDanger("Vider le catalogue");
        clear.setOnClickListener(v->new AlertDialog.Builder(this)
            .setTitle("Vider le catalogue ?")
            .setMessage("Toutes tes références seront supprimées.")
            .setNegativeButton("Annuler",null)
            .setPositiveButton("Vider",(d,w)->{
                LocalStore.clear(this); materials.clear(); chantierSelection.clear();
                Toast.makeText(this,"Catalogue vidé",Toast.LENGTH_SHORT).show();
                showHome();
            }).show());
        content.addView(clear,gap(16));
    }

    private LinearLayout detailLine(String k,String v){
        LinearLayout r=new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(14),dp(13),dp(14),dp(13));
        r.addView(text(k,13,TEXT,false),new LinearLayout.LayoutParams(0,-2,1));
        r.addView(text(v==null||v.isEmpty()?"—":v,13,MUTED,false));
        return r;
    }

    private View divider(){
        View v=new View(this);
        v.setBackgroundColor(BORDER);
        v.setLayoutParams(new LinearLayout.LayoutParams(-1,dp(1)));
        return v;
    }

    private TextView sectionTitle(String s){ return text(s,14,TEXT,true); }

    private MaterialItem find(long id){
        for(MaterialItem m:materials) if(m.id==id) return m;
        return null;
    }

    private int parseInt(EditText e){
        try{return Integer.parseInt(e.getText().toString().trim());}
        catch(Exception ex){return 0;}
    }

    private LinearLayout card(){
        LinearLayout c=new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(roundStroke(WHITE,BORDER,18,1));
        return c;
    }

    private EditText field(String hint){
        EditText e=new EditText(this);
        e.setHint(hint);
        e.setTextColor(TEXT);
        e.setHintTextColor(Color.rgb(145,155,171));
        e.setTextSize(14);
        e.setPadding(dp(14),dp(10),dp(14),dp(10));
        e.setBackground(roundStroke(WHITE,BORDER,14,1));
        return e;
    }

    private Button primaryButton(String s){
        Button b=new Button(this);
        b.setText(s); b.setAllCaps(false); b.setTextColor(WHITE); b.setTextSize(14);
        b.setBackground(round(BLUE,14));
        return b;
    }

    private Button outlineButton(String s){
        Button b=new Button(this);
        b.setText(s); b.setAllCaps(false); b.setTextColor(BLUE); b.setTextSize(14);
        b.setBackground(roundStroke(WHITE,BLUE,14,1));
        return b;
    }

    private Button outlineDanger(String s){
        Button b=new Button(this);
        b.setText(s); b.setAllCaps(false); b.setTextColor(RED); b.setTextSize(14);
        b.setBackground(roundStroke(WHITE,Color.rgb(220,174,179),14,1));
        return b;
    }

    private Button miniAction(String s){
        Button b=new Button(this);
        b.setText(s); b.setAllCaps(false); b.setTextColor(BLUE); b.setTextSize(12);
        b.setPadding(dp(10),0,dp(10),0); b.setBackground(round(BLUE_SOFT,12));
        return b;
    }

    private Button smallButton(String s){
        Button b=new Button(this);
        b.setText(s); b.setAllCaps(false); b.setTextColor(BLUE); b.setTextSize(18);
        b.setPadding(0,0,0,0); b.setBackground(round(BLUE_SOFT,10));
        return b;
    }

    private TextView text(String s,int sp,int color,boolean bold){
        TextView t=new TextView(this);
        t.setText(s); t.setTextSize(sp); t.setTextColor(color);
        if(bold) t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        return t;
    }

    private LinearLayout.LayoutParams gap(int top){
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);
        p.topMargin=dp(top);
        return p;
    }

    private GradientDrawable round(int c,int r){
        GradientDrawable d=new GradientDrawable();
        d.setColor(c); d.setCornerRadius(dp(r));
        return d;
    }

    private GradientDrawable roundStroke(int c,int s,int r,int w){
        GradientDrawable d=round(c,r);
        d.setStroke(dp(w),s);
        return d;
    }

    private int dp(int v){ return Math.round(v*getResources().getDisplayMetrics().density); }
}
