package fr.catallo.app;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.*;

public class LocalStore {
    private static final String PREF = "catallo_store";
    private static final String KEY = "materials";

    public static ArrayList<MaterialItem> load(Context c) {
        ArrayList<MaterialItem> out = new ArrayList<>();
        SharedPreferences sp = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        String raw = sp.getString(KEY, "");
        if (raw == null || raw.isEmpty()) {
            seed(out);
            save(c, out);
            return out;
        }
        try {
            JSONArray a = new JSONArray(raw);
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                out.add(new MaterialItem(
                    o.optLong("id"),
                    o.optString("name"),
                    o.optString("reference"),
                    o.optString("brand"),
                    o.optString("category"),
                    o.optString("alias"),
                    o.optString("keywords"),
                    o.optString("unit", "u")
                ));
            }
        } catch (Exception e) {
            seed(out);
        }
        return out;
    }

    public static void save(Context c, ArrayList<MaterialItem> items) {
        JSONArray a = new JSONArray();
        try {
            for (MaterialItem m : items) {
                JSONObject o = new JSONObject();
                o.put("id", m.id);
                o.put("name", m.name);
                o.put("reference", m.reference);
                o.put("brand", m.brand);
                o.put("category", m.category);
                o.put("alias", m.alias);
                o.put("keywords", m.keywords);
                o.put("unit", m.unit);
                a.put(o);
            }
        } catch (Exception ignored) {}
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY, a.toString()).apply();
    }

    private static void seed(ArrayList<MaterialItem> out) {
        out.add(new MaterialItem(1, "Bouton poussoir Plexo", "069711", "Legrand", "Commande", "BP Plexo", "bouton poussoir étanche gris", "u"));
        out.add(new MaterialItem(2, "Ventouse électromagnétique 300 kg", "EF3003", "WOSY", "Contrôle d'accès", "Ventouse 300kg", "serrure magnetique porte accès", "u"));
        out.add(new MaterialItem(3, "Relais modulaire 12 V", "REL12", "", "Automatisme", "Relais 12V", "contact sec bobine", "u"));
        out.add(new MaterialItem(4, "Câble SYT1 9/10 5 paires", "SYT1-5P", "", "Câblage", "SYT 5P", "cable téléphone contrôle accès", "m"));
    }
}
