package fr.catallo.app;

import android.content.*;
import org.json.*;
import java.util.*;

public class LocalStore {
    private static final String PREF="allocat_store";
    private static final String KEY="materials";

    public static ArrayList<MaterialItem> load(Context c){
        ArrayList<MaterialItem> out=new ArrayList<>();
        String raw=c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString(KEY,"");

        if(raw==null || raw.isEmpty()){
            return out; // Catalogue volontairement vide au premier lancement
        }

        try{
            JSONArray a=new JSONArray(raw);
            for(int i=0;i<a.length();i++){
                JSONObject o=a.getJSONObject(i);

                // Migration douce depuis l'ancien champ "stock"
                int oldStock=o.optInt("stock",0);
                int camion=o.has("stockCamion") ? o.optInt("stockCamion",0) : oldStock;
                int agence=o.optInt("stockAgence",0);

                MaterialItem m=new MaterialItem(
                    o.optLong("id"),
                    o.optString("name"),
                    o.optString("reference"),
                    o.optString("brand"),
                    o.optString("category"),
                    o.optString("alias"),
                    o.optString("keywords"),
                    o.optString("unit","u"),
                    camion,
                    agence,
                    o.optInt("minStock",0)
                );
                m.favorite=o.optBoolean("favorite",false);
                out.add(m);
            }
        }catch(Exception ignored){}

        return out;
    }

    public static void save(Context c,ArrayList<MaterialItem> items){
        JSONArray a=new JSONArray();
        try{
            for(MaterialItem m:items){
                JSONObject o=new JSONObject();
                o.put("id",m.id);
                o.put("name",m.name);
                o.put("reference",m.reference);
                o.put("brand",m.brand);
                o.put("category",m.category);
                o.put("alias",m.alias);
                o.put("keywords",m.keywords);
                o.put("unit",m.unit);
                o.put("stockCamion",m.stockCamion);
                o.put("stockAgence",m.stockAgence);
                o.put("minStock",m.minStock);
                o.put("favorite",m.favorite);
                a.put(o);
            }
        }catch(Exception ignored){}

        c.getSharedPreferences(PREF,Context.MODE_PRIVATE)
            .edit().putString(KEY,a.toString()).apply();
    }

    public static void clear(Context c){
        c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().remove(KEY).apply();
    }
}
