package fr.catallo.app;

import java.util.*;

public class Worksite {
    public long id;
    public String name;
    public String note;
    public long createdAt;
    public boolean validated;

    // Default behavior for this worksite
    public boolean deductFromTruck = true;

    // Desired quantities in the worksite "cart"
    public LinkedHashMap<Long,Integer> quantities = new LinkedHashMap<>();

    // Per-product override: true = deduct, false = do not deduct.
    // Missing key => use deductFromTruck.
    public LinkedHashMap<Long,Boolean> deductOverrides = new LinkedHashMap<>();

    // Quantity already physically deducted from truck stock.
    // This makes validation idempotent and allows delta adjustments.
    public LinkedHashMap<Long,Integer> deductedQuantities = new LinkedHashMap<>();

    public Worksite(long id,String name,String note,long createdAt){
        this.id=id;
        this.name=name==null?"":name;
        this.note=note==null?"":note;
        this.createdAt=createdAt;
    }

    public boolean shouldDeduct(long materialId){
        Boolean override=deductOverrides.get(materialId);
        return override!=null ? override.booleanValue() : deductFromTruck;
    }
}
