package fr.catallo.app;

import java.util.*;

public class Worksite {
    public long id;
    public String name, note;
    public long createdAt;
    public boolean validated;
    public LinkedHashMap<Long,Integer> quantities=new LinkedHashMap<>();

    public Worksite(long id,String name,String note,long createdAt){
        this.id=id;this.name=name==null?"":name;this.note=note==null?"":note;this.createdAt=createdAt;
    }
}
