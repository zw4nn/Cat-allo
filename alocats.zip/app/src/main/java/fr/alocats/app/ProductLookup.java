package fr.alocats.app;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.*;

public class ProductLookup {
    public static class Result {
        public String name="",reference="",brand="",category="",source="",url="",code="",imageUrl="";
        public int score=0;

        public boolean found(){
            return !name.isEmpty() || !reference.isEmpty() || !brand.isEmpty();
        }

        public String label(){
            StringBuilder b=new StringBuilder();
            if(!name.isEmpty()) b.append(name);
            if(!brand.isEmpty()) b.append(b.length()==0?brand:" • "+brand);
            if(!reference.isEmpty()) b.append(" • Réf. ").append(reference);
            if(!source.isEmpty()) b.append(" • ").append(source);
            return b.length()==0 ? "Produit" : b.toString();
        }
    }

    private static String get(String u)throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();
        c.setConnectTimeout(7000);
        c.setReadTimeout(9000);
        c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent","Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 Chrome/137 Mobile Safari/537.36");
        c.setRequestProperty("Accept-Language","fr-FR,fr;q=0.9,en;q=0.5");
        c.setRequestProperty("Accept","text/html,application/xhtml+xml");

        try(InputStream in=c.getInputStream()){
            ByteArrayOutputStream out=new ByteArrayOutputStream();
            byte[] b=new byte[8192];
            int n;
            while((n=in.read(b))>0 && out.size()<1500000){
                out.write(b,0,n);
            }
            return out.toString(StandardCharsets.UTF_8.name());
        }finally{
            c.disconnect();
        }
    }

    private static String clean(String s){
        if(s==null)return "";
        return s
            .replaceAll("(?is)<script[^>]*>.*?</script>"," ")
            .replaceAll("(?is)<style[^>]*>.*?</style>"," ")
            .replaceAll("<[^>]+>"," ")
            .replace("&amp;","&")
            .replace("&quot;","\"")
            .replace("&#039;","'")
            .replace("&#39;","'")
            .replace("&nbsp;"," ")
            .replaceAll("\\s+"," ")
            .trim();
    }

    private static String first(String html,String regex){
        Matcher m=Pattern.compile(regex,Pattern.CASE_INSENSITIVE|Pattern.DOTALL).matcher(html);
        return m.find()?clean(m.group(1)):"";
    }

    private static String sourceFor(String url){
        String u=url.toLowerCase(Locale.ROOT);
        if(u.contains("gdv.fr")) return "GDV";
        if(u.contains("rexel.fr")) return "Rexel";
        if(u.contains("yesss-fr.com")) return "YESSS";
        if(u.contains("legrand.")) return "Legrand";
        if(u.contains("se.com") || u.contains("schneider-electric.")) return "Schneider Electric";
        if(u.contains("urmet.")) return "Urmet";
        if(u.contains("hager.")) return "Hager";
        return "Web";
    }

    private static String domainFor(String source){
        if("GDV".equals(source)) return "gdv.fr";
        if("Rexel".equals(source)) return "rexel.fr";
        if("YESSS".equals(source)) return "yesss-fr.com";
        return "";
    }

    private static String inferBrand(String html,String title){
        String low=(title+" "+html.substring(0,Math.min(html.length(),50000))).toLowerCase(Locale.ROOT);
        String[][] brands={
            {"legrand","Legrand"},
            {"schneider electric","Schneider Electric"},
            {"schneider","Schneider Electric"},
            {"urmet","Urmet"},
            {"hager","Hager"},
            {"abb","ABB"},
            {"yokis","Yokis"},
            {"bticino","BTicino"},
            {"comelit","Comelit"},
            {"aiphone","Aiphone"},
            {"fermax","Fermax"}
        };
        for(String[] b:brands){
            if(low.contains(b[0])) return b[1];
        }
        return "";
    }

    private static Result parse(String url,String source,String expectedCode)throws Exception{
        String h=get(url);
        Result r=new Result();
        r.url=url;
        r.source=source==null||source.isEmpty()?sourceFor(url):source;

        r.name=first(h,"<h1[^>]*>(.*?)</h1>");
        if(r.name.isEmpty()) r.name=first(h,"\"name\"\\s*:\\s*\"([^\"]{4,220})\"");
        if(r.name.isEmpty()) r.name=first(h,"<meta[^>]+property=[\"']og:title[\"'][^>]+content=[\"']([^\"']+)[\"']");
        if(r.name.isEmpty()) r.name=first(h,"<title[^>]*>(.*?)</title>");

        r.reference=first(h,"\"sku\"\\s*:\\s*\"([^\"]+)\"");
        if(r.reference.isEmpty()) r.reference=first(h,"\"mpn\"\\s*:\\s*\"([^\"]+)\"");
        if(r.reference.isEmpty()) r.reference=first(h,"(?:REF\\.?|Réf(?:érence)?)\\s*[.:]?\\s*([A-Z0-9][A-Z0-9._/-]{2,})");

        r.brand=first(h,"\"brand\"\\s*:\\s*\\{[^}]*\"name\"\\s*:\\s*\"([^\"]+)\"");
        if(r.brand.isEmpty()) r.brand=first(h,"\"brand\"\\s*:\\s*\"([^\"]+)\"");
        if(r.brand.isEmpty()) r.brand=inferBrand(h,r.name);

        r.code=first(h,"\"gtin13\"\\s*:\\s*\"([0-9]{8,14})\"");
        if(r.code.isEmpty()) r.code=first(h,"\"gtin\"\\s*:\\s*\"([0-9]{8,14})\"");
        if(r.code.isEmpty()) r.code=first(h,"EAN\\.?\\s*(?:13)?\\s*[:.]?\\s*([0-9]{8,14})");

        if(expectedCode!=null && !expectedCode.isEmpty() && h.contains(expectedCode)){
            r.code=expectedCode;
            r.score+=100;
        }

        r.imageUrl=first(h,"<meta[^>]+property=[\"']og:image[\"'][^>]+content=[\"']([^\"']+)[\"']");
        if(r.imageUrl.isEmpty())
            r.imageUrl=first(h,"<meta[^>]+content=[\"']([^\"']+)[\"'][^>]+property=[\"']og:image[\"']");
        if(r.imageUrl.isEmpty())
            r.imageUrl=first(h,"\"image\"\\s*:\\s*\"([^\"]+)\"");
        if(r.imageUrl.startsWith("//")) r.imageUrl="https:"+r.imageUrl;

        String low=(r.name+" "+h.substring(0,Math.min(h.length(),50000))).toLowerCase(Locale.ROOT);
        if(low.contains("interphon") || low.contains("vigik") || low.contains("contrôle d'accès") ||
           low.contains("controle d'acces") || low.contains("platine de rue") || low.contains("ventouse"))
            r.category="Interphonie / contrôle d'accès";
        else if(low.contains("disjonct") || low.contains("contacteur") || low.contains("modulaire") ||
                low.contains("télérupteur") || low.contains("telerupteur") || low.contains("rail din"))
            r.category="Modulaire";
        else if(low.contains("prise") || low.contains("interrupteur") || low.contains("appareillage") ||
                low.contains("odace") || low.contains("mosaic"))
            r.category="Appareillage";

        if(!r.reference.isEmpty()) r.score+=25;
        if(!r.brand.isEmpty()) r.score+=20;
        if(!r.name.isEmpty()) r.score+=20;
        if(!r.imageUrl.isEmpty()) r.score+=10;
        if(!"Web".equals(r.source)) r.score+=10;

        return r;
    }

    private static ArrayList<String> ddgLinks(String query,String domain,int limit)throws Exception{
        String q=query;
        if(domain!=null && !domain.isEmpty()) q+=" site:"+domain;

        String h=get("https://html.duckduckgo.com/html/?q="+URLEncoder.encode(q,"UTF-8"));
        LinkedHashSet<String> urls=new LinkedHashSet<>();

        Matcher m=Pattern.compile("uddg=([^&\"]+)",Pattern.CASE_INSENSITIVE).matcher(h);
        while(m.find() && urls.size()<limit){
            String u=URLDecoder.decode(m.group(1),"UTF-8");
            if(u.startsWith("http") && (domain==null || domain.isEmpty() || u.contains(domain)))
                urls.add(u);
        }
        return new ArrayList<>(urls);
    }

    private static ArrayList<String> bingLinks(String query,String domain,int limit)throws Exception{
        String q=query;
        if(domain!=null && !domain.isEmpty()) q+=" site:"+domain;

        String h=get("https://www.bing.com/search?setlang=fr-FR&q="+URLEncoder.encode(q,"UTF-8"));
        LinkedHashSet<String> urls=new LinkedHashSet<>();

        Matcher m=Pattern.compile("<li class=\"b_algo\".*?<h2><a href=\"(https?://[^\"]+)\"",Pattern.CASE_INSENSITIVE|Pattern.DOTALL).matcher(h);
        while(m.find() && urls.size()<limit){
            String u=m.group(1).replace("&amp;","&");
            if(domain==null || domain.isEmpty() || u.contains(domain)) urls.add(u);
        }

        if(urls.isEmpty()){
            Matcher any=Pattern.compile("<a href=\"(https?://[^\"]+)\"",Pattern.CASE_INSENSITIVE).matcher(h);
            while(any.find() && urls.size()<limit){
                String u=any.group(1).replace("&amp;","&");
                if(u.contains("bing.com")) continue;
                if(domain==null || domain.isEmpty() || u.contains(domain)) urls.add(u);
            }
        }

        return new ArrayList<>(urls);
    }

    private static ArrayList<String> searchLinks(String query,String domain,int limit){
        LinkedHashSet<String> all=new LinkedHashSet<>();
        try{ all.addAll(ddgLinks(query,domain,limit)); }catch(Exception ignored){}
        if(all.size()<limit){
            try{ all.addAll(bingLinks(query,domain,limit)); }catch(Exception ignored){}
        }
        ArrayList<String> out=new ArrayList<>(all);
        if(out.size()>limit) return new ArrayList<>(out.subList(0,limit));
        return out;
    }

    private static void addParsed(
        ArrayList<Result> out,
        LinkedHashSet<String> seenUrls,
        LinkedHashSet<String> seenKeys,
        String url,
        String source,
        String expectedCode
    ){
        if(url==null || !url.startsWith("http") || !seenUrls.add(url)) return;

        try{
            Result r=parse(url,source,expectedCode);
            if(!r.found()) return;

            String key=(r.reference+"|"+r.name+"|"+r.code)
                .toLowerCase(Locale.ROOT)
                .replaceAll("\\s+"," ")
                .trim();

            if(!key.isEmpty() && !seenKeys.add(key)) return;
            out.add(r);
        }catch(Exception ignored){}
    }

    public static Result lookup(String code){
        ArrayList<Result> candidates=new ArrayList<>();
        LinkedHashSet<String> seenUrls=new LinkedHashSet<>();
        LinkedHashSet<String> seenKeys=new LinkedHashSet<>();

        // 1. Exact EAN/reference across the public web — this is the important path.
        for(String u:searchLinks("\""+code+"\"","",12)){
            addParsed(candidates,seenUrls,seenKeys,u,sourceFor(u),code);
        }

        // 2. Exact query without quotes catches search engines that tokenize EANs strangely.
        if(candidates.isEmpty()){
            for(String u:searchLinks(code,"",10)){
                addParsed(candidates,seenUrls,seenKeys,u,sourceFor(u),code);
            }
        }

        // 3. Distributor-specific fallback.
        String[] sources={"GDV","Rexel","YESSS"};
        for(String source:sources){
            if(candidates.size()>=10) break;
            for(String u:searchLinks(code,domainFor(source),5)){
                addParsed(candidates,seenUrls,seenKeys,u,source,code);
            }
        }

        if(candidates.isEmpty()) return new Result();

        Collections.sort(candidates,(a,b)->Integer.compare(b.score,a.score));
        return candidates.get(0);
    }

    public static ArrayList<Result> search(String query){
        ArrayList<Result> out=new ArrayList<>();
        LinkedHashSet<String> seenUrls=new LinkedHashSet<>();
        LinkedHashSet<String> seenKeys=new LinkedHashSet<>();

        // Distributor search first for normal text queries.
        String[] sources={"GDV","Rexel","YESSS"};
        for(String source:sources){
            for(String u:searchLinks(query,domainFor(source),6)){
                if(out.size()>=12) break;
                addParsed(out,seenUrls,seenKeys,u,source,"");
            }
            if(out.size()>=12) break;
        }

        // Broad web search fills gaps and catches manufacturer pages.
        if(out.size()<8){
            for(String u:searchLinks(query,"",12)){
                if(out.size()>=12) break;
                addParsed(out,seenUrls,seenKeys,u,sourceFor(u),"");
            }
        }

        Collections.sort(out,(a,b)->Integer.compare(b.score,a.score));
        return out;
    }
}
