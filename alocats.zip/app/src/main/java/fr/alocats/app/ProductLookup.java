package fr.alocats.app;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.*;

public class ProductLookup {
    public static class Result {
        public String name="",reference="",brand="",category="",source="",url="",code="";
        public boolean found(){ return !name.isEmpty() || !reference.isEmpty() || !brand.isEmpty(); }
        public String label(){
            StringBuilder b=new StringBuilder();
            if(!name.isEmpty()) b.append(name);
            if(!brand.isEmpty()) b.append(b.length()==0?brand:" • "+brand);
            if(!reference.isEmpty()) b.append(" • Réf. ").append(reference);
            if(!source.isEmpty()) b.append(" • ").append(source);
            return b.length()==0 ? "Produit" : b.toString();
        }
    }

    private static String get(String u)throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();
        c.setConnectTimeout(7000);
        c.setReadTimeout(9000);
        c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent","Mozilla/5.0 (Android; Alocats/0.2.6)");
        c.setRequestProperty("Accept-Language","fr-FR,fr;q=0.9");
        c.setRequestProperty("Accept","text/html,application/xhtml+xml");

        try(InputStream in=c.getInputStream()){
            ByteArrayOutputStream out=new ByteArrayOutputStream();
            byte[] b=new byte[8192];
            int n;
            while((n=in.read(b))>0 && out.size()<1200000){
                out.write(b,0,n);
            }
            return out.toString(StandardCharsets.UTF_8.name());
        }finally{
            c.disconnect();
        }
    }

    private static String clean(String s){
        if(s==null)return "";
        return s
            .replaceAll("<script[^>]*>.*?</script>"," ")
            .replaceAll("<style[^>]*>.*?</style>"," ")
            .replaceAll("<[^>]+>"," ")
            .replace("&amp;","&")
            .replace("&quot;","\"")
            .replace("&#039;","'")
            .replace("&nbsp;"," ")
            .replaceAll("\\s+"," ")
            .trim();
    }

    private static String first(String html,String regex){
        Matcher m=Pattern.compile(regex,Pattern.CASE_INSENSITIVE|Pattern.DOTALL).matcher(html);
        return m.find()?clean(m.group(1)):"";
    }

    private static String sourceFor(String url){
        String u=url.toLowerCase(Locale.ROOT);
        if(u.contains("gdv.fr")) return "GDV";
        if(u.contains("rexel.fr")) return "Rexel";
        if(u.contains("yesss-fr.com")) return "YESSS";
        return "Web";
    }

    private static String domainFor(String source){
        if("GDV".equals(source)) return "gdv.fr";
        if("Rexel".equals(source)) return "rexel.fr";
        if("YESSS".equals(source)) return "yesss-fr.com";
        return "";
    }

    private static Result parse(String url,String source)throws Exception{
        String h=get(url);
        Result r=new Result();
        r.url=url;
        r.source=source;

        r.name=first(h,"<h1[^>]*>(.*?)</h1>");
        if(r.name.isEmpty()) r.name=first(h,"\"name\"\\s*:\\s*\"([^\"]{4,180})\"");
        if(r.name.isEmpty()) r.name=first(h,"<title[^>]*>(.*?)</title>");

        r.reference=first(h,"\"sku\"\\s*:\\s*\"([^\"]+)\"");
        if(r.reference.isEmpty()) r.reference=first(h,"\"mpn\"\\s*:\\s*\"([^\"]+)\"");
        if(r.reference.isEmpty()) r.reference=first(h,"Réf(?:érence)?\\s*(?:fabricant|fabriquant)?\\s*:?\\s*</?[^>]*>*\\s*([A-Z0-9][A-Z0-9._/-]{2,})");

        r.brand=first(h,"\"brand\"\\s*:\\s*\\{[^}]*\"name\"\\s*:\\s*\"([^\"]+)\"");
        if(r.brand.isEmpty()) r.brand=first(h,"\"brand\"\\s*:\\s*\"([^\"]+)\"");

        r.code=first(h,"\"gtin13\"\\s*:\\s*\"([0-9]{8,14})\"");
        if(r.code.isEmpty()) r.code=first(h,"\"gtin\"\\s*:\\s*\"([0-9]{8,14})\"");
        if(r.code.isEmpty()) r.code=first(h,"EAN\\s*(?:13)?\\s*:?\\s*([0-9]{8,14})");

        String low=(r.name+" "+h.substring(0,Math.min(h.length(),35000))).toLowerCase(Locale.ROOT);
        if(low.contains("interphon") || low.contains("vigik") || low.contains("contrôle d'accès") || low.contains("controle d'acces") || low.contains("platine de rue") || low.contains("ventouse"))
            r.category="Interphonie / contrôle d'accès";
        else if(low.contains("disjonct") || low.contains("contacteur") || low.contains("modulaire") || low.contains("télérupteur") || low.contains("telerupteur"))
            r.category="Modulaire";
        else if(low.contains("prise") || low.contains("interrupteur") || low.contains("appareillage") || low.contains("odace") || low.contains("mosaic"))
            r.category="Appareillage";

        return r;
    }

    private static ArrayList<String> ddgLinks(String query,String domain,int limit)throws Exception{
        String q=query;
        if(domain!=null && !domain.isEmpty()) q=query+" site:"+domain;

        String h=get("https://html.duckduckgo.com/html/?q="+URLEncoder.encode(q,"UTF-8"));
        LinkedHashSet<String> urls=new LinkedHashSet<>();

        Matcher m=Pattern.compile("uddg=([^&\"]+)",Pattern.CASE_INSENSITIVE).matcher(h);
        while(m.find() && urls.size()<limit){
            String u=URLDecoder.decode(m.group(1),"UTF-8");
            if((domain==null || domain.isEmpty() || u.contains(domain)) && u.startsWith("http"))
                urls.add(u);
        }

        return new ArrayList<>(urls);
    }

    public static Result lookup(String code){
        String[] sources={"GDV","Rexel","YESSS"};
        for(String source:sources){
            try{
                ArrayList<String> links=ddgLinks("\""+code+"\"",domainFor(source),3);
                for(String u:links){
                    try{
                        Result r=parse(u,source);
                        if(r.found()) return r;
                    }catch(Exception ignored){}
                }
            }catch(Exception ignored){}
        }
        return new Result();
    }

    public static ArrayList<Result> search(String query){
        ArrayList<Result> out=new ArrayList<>();
        LinkedHashSet<String> seenUrls=new LinkedHashSet<>();
        LinkedHashSet<String> seenKeys=new LinkedHashSet<>();

        String[] sources={"GDV","Rexel","YESSS"};

        for(String source:sources){
            try{
                ArrayList<String> links=ddgLinks(query,domainFor(source),6);
                for(String u:links){
                    if(out.size()>=12) break;
                    if(!seenUrls.add(u)) continue;

                    try{
                        Result r=parse(u,source);
                        if(!r.found()) continue;

                        String key=(r.reference+"|"+r.name).toLowerCase(Locale.ROOT).replaceAll("\\s+"," ").trim();
                        if(!key.isEmpty() && !seenKeys.add(key)) continue;

                        out.add(r);
                    }catch(Exception ignored){}
                }
            }catch(Exception ignored){}

            if(out.size()>=12) break;
        }

        // Fallback web général si les trois distributeurs donnent trop peu de résultats.
        if(out.size()<4){
            try{
                ArrayList<String> links=ddgLinks(query,"",8);
                for(String u:links){
                    if(out.size()>=12) break;
                    if(!seenUrls.add(u)) continue;

                    String source=sourceFor(u);
                    try{
                        Result r=parse(u,source);
                        if(!r.found()) continue;

                        String key=(r.reference+"|"+r.name).toLowerCase(Locale.ROOT).replaceAll("\\s+"," ").trim();
                        if(!key.isEmpty() && !seenKeys.add(key)) continue;

                        out.add(r);
                    }catch(Exception ignored){}
                }
            }catch(Exception ignored){}
        }

        return out;
    }
}
