package fr.alocats.app;

import android.content.*;
import org.json.*;
import java.util.*;

public class LocalStore {
    private static final String PREF="alocats_store";
    private static final String KEY="materials";

    public static ArrayList<MaterialItem> load(Context c){
        ArrayList<MaterialItem> out=new ArrayList<>();
        String raw=c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString(KEY,"");
        if(raw==null || raw.isEmpty()) return out;
        try{
            JSONArray a=new JSONArray(raw);
            for(int i=0;i<a.length();i++){
                JSONObject o=a.getJSONObject(i);
                int stock=o.has("stockCamion")?o.optInt("stockCamion",0):o.optInt("stock",0);
                MaterialItem m=new MaterialItem(o.optLong("id"),o.optString("name"),o.optString("reference"),o.optString("brand"),o.optString("category"),o.optString("alias"),o.optString("keywords"),o.optString("unit","u"),stock,o.optInt("minStock",0));
                m.favorite=o.optBoolean("favorite",false);
                out.add(m);
            }
        }catch(Exception ignored){}
        return out;
    }

    public static void save(Context c,ArrayList<MaterialItem> items){
        JSONArray a=new JSONArray();
        try{
            for(MaterialItem m:items){
                JSONObject o=new JSONObject();
                o.put("id",m.id);o.put("name",m.name);o.put("reference",m.reference);o.put("brand",m.brand);o.put("category",m.category);o.put("alias",m.alias);o.put("keywords",m.keywords);o.put("unit",m.unit);o.put("stockCamion",m.stockCamion);o.put("minStock",m.minStock);o.put("favorite",m.favorite);
                a.put(o);
            }
        }catch(Exception ignored){}
        c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putString(KEY,a.toString()).apply();
    }
}
