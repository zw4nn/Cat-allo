package fr.alocats.app;

import com.journeyapps.barcodescanner.CaptureActivity;

public class ScannerActivity extends CaptureActivity {
}
