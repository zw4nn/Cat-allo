package fr.alocats.app;

import android.content.Context;
import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONObject;
import org.w3c.dom.*;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.*;

public class CatalogueIO {
    public static final String[] HEADERS={"designation","reference","marque","categorie","alias","mots_cles","unite","stock_camion","stock_mini"};

    public static void exportJson(Context c,Uri uri,ArrayList<MaterialItem> items)throws Exception{
        JSONArray a=new JSONArray();
        for(MaterialItem m:items){
            JSONObject o=new JSONObject();
            o.put("designation",m.name);o.put("reference",m.reference);o.put("marque",m.brand);
            o.put("categorie",m.category);o.put("alias",m.alias);o.put("mots_cles",m.keywords);
            o.put("unite",m.unit);o.put("stock_camion",m.stockCamion);o.put("stock_mini",m.minStock);
            a.put(o);
        }
        JSONObject root=new JSONObject();root.put("format","alocats-catalogue");root.put("version",1);root.put("materiel",a);
        write(c,uri,root.toString(2));
    }

    public static ArrayList<MaterialItem> importJson(Context c,Uri uri)throws Exception{
        JSONObject root=new JSONObject(read(c,uri));
        JSONArray a=root.optJSONArray("materiel");
        ArrayList<MaterialItem> out=new ArrayList<>();
        if(a==null)return out;
        for(int i=0;i<a.length();i++)out.add(fromJson(a.getJSONObject(i)));
        return out;
    }

    public static void exportCsv(Context c,Uri uri,ArrayList<MaterialItem> items)throws Exception{
        StringBuilder b=new StringBuilder();
        for(int i=0;i<HEADERS.length;i++){if(i>0)b.append(';');b.append(csv(HEADERS[i]));}b.append('\n');
        for(MaterialItem m:items){
            String[] r=row(m);
            for(int i=0;i<r.length;i++){if(i>0)b.append(';');b.append(csv(r[i]));}b.append('\n');
        }
        write(c,uri,b.toString());
    }

    public static ArrayList<MaterialItem> importCsv(Context c,Uri uri)throws Exception{
        List<List<String>> t=parseCsv(read(c,uri));
        ArrayList<MaterialItem> out=new ArrayList<>();
        if(t.isEmpty())return out;
        List<String> h=t.get(0);
        for(int r=1;r<t.size();r++){
            List<String> v=t.get(r); Map<String,String> m=new HashMap<>();
            for(int i=0;i<h.size();i++)m.put(norm(h.get(i)),i<v.size()?v.get(i):"");
            if(get(m,"designation").isEmpty())continue;
            out.add(fromMap(m));
        }
        return out;
    }

    public static void exportXlsx(Context c,Uri uri,ArrayList<MaterialItem> items)throws Exception{
        OutputStream raw=c.getContentResolver().openOutputStream(uri);
        if(raw==null)throw new IOException("Impossible d'écrire le fichier");
        ZipOutputStream z=new ZipOutputStream(new BufferedOutputStream(raw));
        put(z,"[Content_Types].xml","<?xml version=\"1.0\" encoding=\"UTF-8\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/></Types>");
        put(z,"_rels/.rels","<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");
        put(z,"xl/workbook.xml","<?xml version=\"1.0\" encoding=\"UTF-8\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets><sheet name=\"Catalogue\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>");
        put(z,"xl/_rels/workbook.xml.rels","<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/></Relationships>");
        StringBuilder sh=new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>");
        sh.append("<row r=\"1\">");for(int i=0;i<HEADERS.length;i++)sh.append(cell(1,i,HEADERS[i]));sh.append("</row>");
        int rr=1;
        for(MaterialItem m:items){rr++;sh.append("<row r=\"").append(rr).append("\">");String[] row=row(m);for(int i=0;i<row.length;i++)sh.append(cell(rr,i,row[i]));sh.append("</row>");}
        sh.append("</sheetData></worksheet>");
        put(z,"xl/worksheets/sheet1.xml",sh.toString());
        z.finish();z.close();
    }

    public static ArrayList<MaterialItem> importXlsx(Context c,Uri uri)throws Exception{
        InputStream raw=c.getContentResolver().openInputStream(uri);
        if(raw==null)throw new IOException("Impossible de lire le fichier");
        HashMap<String,byte[]> files=new HashMap<>();ZipInputStream z=new ZipInputStream(new BufferedInputStream(raw));ZipEntry e;byte[] buf=new byte[8192];
        while((e=z.getNextEntry())!=null){ByteArrayOutputStream o=new ByteArrayOutputStream();int n;while((n=z.read(buf))>0)o.write(buf,0,n);files.put(e.getName(),o.toByteArray());}z.close();
        ArrayList<String> shared=new ArrayList<>();
        if(files.containsKey("xl/sharedStrings.xml")){
            Document d=parse(files.get("xl/sharedStrings.xml"));NodeList si=d.getElementsByTagNameNS("*","si");
            for(int i=0;i<si.getLength();i++){NodeList ts=((Element)si.item(i)).getElementsByTagNameNS("*","t");StringBuilder b=new StringBuilder();for(int j=0;j<ts.getLength();j++)b.append(ts.item(j).getTextContent());shared.add(b.toString());}
        }
        byte[] sb=files.get("xl/worksheets/sheet1.xml");if(sb==null)throw new IOException("Feuille Catalogue introuvable");
        Document d=parse(sb);NodeList rows=d.getElementsByTagNameNS("*","row");ArrayList<List<String>> table=new ArrayList<>();
        for(int r=0;r<rows.getLength();r++){
            Element re=(Element)rows.item(r);NodeList cells=re.getElementsByTagNameNS("*","c");TreeMap<Integer,String> vals=new TreeMap<>();
            for(int i=0;i<cells.getLength();i++){
                Element ce=(Element)cells.item(i);int col=colIndex(ce.getAttribute("r"));String type=ce.getAttribute("t"),val="";
                if("inlineStr".equals(type)){NodeList ts=ce.getElementsByTagNameNS("*","t");if(ts.getLength()>0)val=ts.item(0).getTextContent();}
                else{NodeList vs=ce.getElementsByTagNameNS("*","v");if(vs.getLength()>0){val=vs.item(0).getTextContent();if("s".equals(type)){int idx=integer(val);val=idx>=0&&idx<shared.size()?shared.get(idx):"";}}}
                vals.put(col,val);
            }
            ArrayList<String> line=new ArrayList<>();int max=vals.isEmpty()?-1:vals.lastKey();for(int i=0;i<=max;i++)line.add(vals.containsKey(i)?vals.get(i):"");table.add(line);
        }
        ArrayList<MaterialItem> out=new ArrayList<>();if(table.isEmpty())return out;List<String> h=table.get(0);
        for(int r=1;r<table.size();r++){List<String> v=table.get(r);Map<String,String> m=new HashMap<>();for(int i=0;i<h.size();i++)m.put(norm(h.get(i)),i<v.size()?v.get(i):"");if(get(m,"designation").isEmpty())continue;out.add(fromMap(m));}
        return out;
    }

    private static MaterialItem fromJson(JSONObject o){
        return new MaterialItem(System.nanoTime(),o.optString("designation"),o.optString("reference"),o.optString("marque"),o.optString("categorie"),o.optString("alias"),o.optString("mots_cles"),unit(o.optString("unite")),o.optInt("stock_camion"),o.optInt("stock_mini"));
    }
    private static MaterialItem fromMap(Map<String,String>m){return new MaterialItem(System.nanoTime(),get(m,"designation"),get(m,"reference"),get(m,"marque"),get(m,"categorie"),get(m,"alias"),get(m,"mots_cles"),unit(get(m,"unite")),integer(get(m,"stock_camion")),integer(get(m,"stock_mini")));}
    private static String[] row(MaterialItem m){return new String[]{m.name,m.reference,m.brand,m.category,m.alias,m.keywords,m.unit,String.valueOf(m.stockCamion),String.valueOf(m.minStock)};}
    private static String unit(String s){return s==null||s.trim().isEmpty()?"u":s.trim();}
    private static String get(Map<String,String>m,String k){String v=m.get(k);return v==null?"":v.trim();}
    private static int integer(String s){try{return (int)Math.round(Double.parseDouble(s.trim().replace(',','.')));}catch(Exception e){return 0;}}
    private static String norm(String s){return s==null?"":s.trim().toLowerCase(Locale.ROOT).replace("é","e").replace("è","e").replace("ê","e").replace("à","a").replace("ç","c").replace(" ","_").replace("-","_");}
    private static String csv(String s){if(s==null)s="";return "\""+s.replace("\"","\"\"")+"\"";}
    private static List<List<String>> parseCsv(String s){
        ArrayList<List<String>> rows=new ArrayList<>();ArrayList<String> row=new ArrayList<>();StringBuilder cell=new StringBuilder();boolean q=false;
        char delim=s.contains(";")?';':',';
        for(int i=0;i<s.length();i++){char ch=s.charAt(i);if(q){if(ch=='"'&&i+1<s.length()&&s.charAt(i+1)=='"'){cell.append('"');i++;}else if(ch=='"')q=false;else cell.append(ch);}else{if(ch=='"')q=true;else if(ch==delim){row.add(cell.toString());cell.setLength(0);}else if(ch=='\n'){row.add(cell.toString());cell.setLength(0);rows.add(row);row=new ArrayList<>();}else if(ch!='\r')cell.append(ch);}}
        if(cell.length()>0||!row.isEmpty()){row.add(cell.toString());rows.add(row);}return rows;
    }
    private static void write(Context c,Uri uri,String s)throws Exception{OutputStream o=c.getContentResolver().openOutputStream(uri);if(o==null)throw new IOException("Impossible d'écrire");o.write(s.getBytes(StandardCharsets.UTF_8));o.close();}
    private static String read(Context c,Uri uri)throws Exception{InputStream in=c.getContentResolver().openInputStream(uri);if(in==null)throw new IOException("Impossible de lire");ByteArrayOutputStream o=new ByteArrayOutputStream();byte[]b=new byte[8192];int n;while((n=in.read(b))>0)o.write(b,0,n);in.close();return new String(o.toByteArray(),StandardCharsets.UTF_8);}
    private static void put(ZipOutputStream z,String n,String s)throws Exception{z.putNextEntry(new ZipEntry(n));z.write(s.getBytes(StandardCharsets.UTF_8));z.closeEntry();}
    private static String cell(int r,int c,String v){return "<c r=\""+colName(c)+r+"\" t=\"inlineStr\"><is><t xml:space=\"preserve\">"+xml(v)+"</t></is></c>";}
    private static String colName(int c){StringBuilder b=new StringBuilder();c++;while(c>0){int r=(c-1)%26;b.insert(0,(char)('A'+r));c=(c-1)/26;}return b.toString();}
    private static int colIndex(String ref){int n=0;for(int i=0;i<ref.length();i++){char c=ref.charAt(i);if(Character.isLetter(c))n=n*26+(Character.toUpperCase(c)-'A'+1);else break;}return Math.max(0,n-1);}
    private static String xml(String s){if(s==null)return "";return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&apos;");}
    private static Document parse(byte[]b)throws Exception{DocumentBuilderFactory f=DocumentBuilderFactory.newInstance();f.setNamespaceAware(true);return f.newDocumentBuilder().parse(new ByteArrayInputStream(b));}
}
