package fr.alocats.app;

import android.content.Context;
import android.net.Uri;
import androidx.documentfile.provider.DocumentFile;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;

public class BackupManager {
    private static final String PREF="alocats_backup";
    private static final String KEY_URI="folder_uri";
    private static final String KEY_USER="user_name";

    public static void setUserName(Context c,String name){
        c.getSharedPreferences(PREF,Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_USER,name==null?"":name.trim())
            .apply();
    }

    public static String getUserName(Context c){
        return c.getSharedPreferences(PREF,Context.MODE_PRIVATE)
            .getString(KEY_USER,"")
            .trim();
    }

    private static String safeUserName(String name){
        String s=name==null?"":name.trim().toLowerCase(Locale.ROOT);
        s=java.text.Normalizer.normalize(s,java.text.Normalizer.Form.NFD)
            .replaceAll("\\p{M}+","");
        s=s.replaceAll("[^a-z0-9]+","-");
        s=s.replaceAll("^-+|-+$","");
        return s.isEmpty()?"utilisateur":s;
    }

    public static void setFolder(Context c,Uri uri){
        c.getSharedPreferences(PREF,Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_URI,uri.toString())
            .apply();
    }

    public static Uri getFolder(Context c){
        String raw=c.getSharedPreferences(PREF,Context.MODE_PRIVATE)
            .getString(KEY_URI,"");

        if(raw==null || raw.trim().isEmpty()) return null;

        try{
            return Uri.parse(raw);
        }catch(Exception e){
            return null;
        }
    }

    public static String folderLabel(Context c){
        Uri uri=getFolder(c);
        if(uri==null) return "Non défini";

        try{
            DocumentFile dir=DocumentFile.fromTreeUri(c,uri);
            if(dir!=null && dir.getName()!=null) return dir.getName();
        }catch(Exception ignored){}

        return "Dossier sélectionné";
    }

    public static String save(
        Context c,
        ArrayList<MaterialItem> materials,
        ArrayList<Worksite> worksites
    ) throws Exception {

        String userName=getUserName(c);
        if(userName.isEmpty())
            throw new IOException("Aucun nom d’utilisateur défini dans les réglages");

        Uri tree=getFolder(c);
        if(tree==null) throw new IOException("Aucun dossier de sauvegarde défini");

        DocumentFile dir=DocumentFile.fromTreeUri(c,tree);
        if(dir==null || !dir.canWrite())
            throw new IOException("Le dossier de sauvegarde n'est plus accessible");

        JSONObject root=new JSONObject();
        root.put("format","alocats-backup");
        root.put("version",1);
        root.put("createdAt",System.currentTimeMillis());
        root.put("userName",userName);

        JSONArray mats=new JSONArray();
        for(MaterialItem m:materials){
            JSONObject o=new JSONObject();
            o.put("id",m.id);
            o.put("designation",m.name);
            o.put("reference",m.reference);
            o.put("marque",m.brand);
            o.put("categorie",m.category);
            o.put("alias",m.alias);
            o.put("mots_cles",m.keywords);
            o.put("unite",m.unit);
            o.put("stock_camion",m.stockCamion);
            o.put("stock_mini",m.minStock);
            mats.put(o);
        }
        root.put("materiel",mats);

        JSONArray ws=new JSONArray();
        for(Worksite w:worksites){
            JSONObject o=new JSONObject();
            o.put("id",w.id);
            o.put("name",w.name);
            o.put("note",w.note);
            o.put("createdAt",w.createdAt);
            o.put("validated",w.validated);
            o.put("deductFromTruck",w.deductFromTruck);

            JSONObject quantities=new JSONObject();
            for(Map.Entry<Long,Integer> e:w.quantities.entrySet())
                quantities.put(String.valueOf(e.getKey()),e.getValue());
            o.put("quantities",quantities);

            JSONObject overrides=new JSONObject();
            for(Map.Entry<Long,Boolean> e:w.deductOverrides.entrySet())
                overrides.put(String.valueOf(e.getKey()),e.getValue());
            o.put("deductOverrides",overrides);

            JSONObject deducted=new JSONObject();
            for(Map.Entry<Long,Integer> e:w.deductedQuantities.entrySet())
                deducted.put(String.valueOf(e.getKey()),e.getValue());
            o.put("deductedQuantities",deducted);

            ws.put(o);
        }
        root.put("chantiers",ws);

        String stamp=new SimpleDateFormat(
            "yyyy-MM-dd_HH-mm-ss",
            Locale.FRANCE
        ).format(new Date());

        String filename="alocats-backup_"+safeUserName(userName)+"_"+stamp+".json";

        DocumentFile file=dir.createFile("application/json",filename);
        if(file==null)
            throw new IOException("Impossible de créer le fichier de sauvegarde");

        OutputStream out=c.getContentResolver().openOutputStream(file.getUri(),"w");
        if(out==null)
            throw new IOException("Impossible d'ouvrir le fichier de sauvegarde");

        out.write(root.toString(2).getBytes(StandardCharsets.UTF_8));
        out.flush();
        out.close();

        return file.getName()==null ? filename : file.getName();
    }
}
