# Alocats v0.2.6

Ajout sans changement de version :
- recherche web texte libre depuis le catalogue
- exemples : `prise Schneider Odace`, `S520052`, `platine Urmet`
- recherche ciblée en priorité :
  1. GDV
  2. Rexel
  3. YESSS
  4. web public en secours
- jusqu'à 12 résultats proposés
- sélection d'un résultat puis fiche catalogue préremplie
- nom, marque, référence, catégorie et EAN/code récupérés quand disponibles
- toutes les informations restent modifiables avant enregistrement

Conservé :
- scan code-barres / QR
- 10 chantiers maximum
- gestion directe du stock camion
- autosave
- Félix
- package fr.alocats.app
- versionCode 17
- versionName 0.2.6
