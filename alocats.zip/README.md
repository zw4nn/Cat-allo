# Alocats v0.2.4

Nouveautés :
- logo launcher réduit de 25 % supplémentaires par rapport à la v0.2.3
- ajout du nom de l'utilisateur dans Réglages > Sauvegarde
- le nom est conservé dans les préférences de l'application
- le nom est écrit dans le JSON de sauvegarde (`userName`)
- le nom est intégré au nom du fichier :
  `alocats-backup-lucas_2026-08-21_10-53-00.json`
- un nom est requis avant de créer une sauvegarde
- les anciennes installations sans nom proposent de le configurer avant "Sauvegarder et quitter"

Compatibilité :
- applicationId : fr.alocats.app
- versionCode : 15
- versionName : 0.2.4
- clé de signature existante conservée
