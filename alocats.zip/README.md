# Alocats v0.2.8

Scanner :
- suppression de la gestion manuelle de la permission caméra
- ZXing gère désormais sa permission caméra lui-même
- activité dédiée `ScannerActivity`
- lancement du scanner protégé par try/catch

Recherche web :
- conservation de la dernière recherche et de ses résultats en mémoire
- depuis une fiche produit : bouton `Retour aux résultats`
- aucun besoin de relancer la recherche pour consulter plusieurs produits
- bouton `Nouvelle recherche` depuis la liste

Conservé :
- images produits web
- gestion directe stock camion
- 10 chantiers maximum
- autosave
- Félix
- package fr.alocats.app
- versionName 0.2.8
- versionCode 19
