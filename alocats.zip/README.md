# Alocats v0.2.9 — scanner

Correctifs scanner :
- suppression de ScannerActivity personnalisée
- retour à l'activité CaptureActivity officielle de ZXing Embedded
- permission caméra laissée à ZXing
- accélération matérielle explicitement activée dans l'application
  (`android:hardwareAccelerated="true"`), requise pour le TextureView du scanner

Recherche web :
- résultats de la dernière recherche conservés
- retour aux résultats conservé
- images produits conservées

Version :
- applicationId : fr.alocats.app
- versionName : 0.2.9
- versionCode : 20
