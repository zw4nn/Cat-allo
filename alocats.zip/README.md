# Alocats v0.2.3

Renommage complet :
- nom application : Alocats
- applicationId : fr.alocats.app
- namespace : fr.alocats.app
- package Java : fr.alocats.app
- sources : app/src/main/java/fr/alocats/app
- sauvegardes et exports renommés alocats-*
- Félix permanent conservé
- stock camion, chantiers, filtres, import/export et sauvegarde conservés

Important : le nouveau applicationId signifie qu’Android considère Alocats comme une nouvelle application.

Version : 0.2.3 / versionCode 14
