# Alocats v0.3.1 — recherche produit renforcée

Recherche après scan :
- recherche exacte de l'EAN/référence sur le web public en premier
- deux moteurs HTML utilisés en cascade : DuckDuckGo + Bing
- pages fabricants et revendeurs prises en compte
- GDV / Rexel / YESSS utilisés en complément
- résultats scorés selon :
  - présence exacte du code
  - désignation
  - marque
  - référence fabricant
  - image
  - source spécialisée
- meilleur résultat proposé automatiquement
- photo affichée lorsqu'elle est disponible
- bouton `Voir d'autres résultats`
- fallback vers la recherche web complète si aucun résultat fiable

Corrections :
- les `\n` ne sont plus affichés littéralement dans les boîtes de dialogue
- image web conservée lors d'un ajout après scan

Cas de test utilisé :
- EAN 3245064124003
- Legrand 412400
- télérupteur CX³ silencieux

Version :
- applicationId : fr.alocats.app
- versionName : 0.3.1
- versionCode : 22
