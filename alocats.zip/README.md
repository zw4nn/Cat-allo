# Alocats v0.2.5

Autosave :
- déclenché automatiquement quand l'activité passe en arrière-plan (`onStop`)
- actif uniquement si un nom utilisateur et un dossier de sauvegarde sont configurés
- silencieux : aucune popup ni toast
- écrase toujours le même fichier :
  `alocats-autosave-<utilisateur>.json`
- le JSON contient `backupType: "auto"`
- les sauvegardes manuelles restent datées et ne sont jamais écrasées

Exemple :
- autosave : `alocats-autosave-lucas.json`
- manuel : `alocats-backup-lucas_2026-08-21_11-30-00.json`

Compatibilité :
- applicationId : fr.alocats.app
- versionCode : 16
- versionName : 0.2.5
- signature existante conservée
