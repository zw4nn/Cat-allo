# Alocats v0.3.0 — Google Code Scanner

Le scanner ZXing Embedded a été complètement retiré.

Nouveau scanner :
- Google Code Scanner via Google Play Services
- aucune permission CAMERA demandée par Alocats
- la caméra et l'interface de scan sont gérées par Google Play Services
- fermeture du scanner sans erreur si l'utilisateur annule
- message propre si le service n'est pas disponible
- saisie manuelle du code disponible en secours

Recherche web :
- résultats conservés en mémoire
- Retour aux résultats
- images produits conservées

Version :
- applicationId : fr.alocats.app
- versionName : 0.3.0
- versionCode : 21
