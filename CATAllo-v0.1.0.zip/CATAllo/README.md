# CAT'Allo — v0.1.0

Application Android pro pour catalogue de matériel et préparation de comptes rendus de chantier.

## V0.1.0
- UI mobile-first Material 3
- logo CAT'Allo intégré et utilisé comme icône
- recherche par nom, référence, marque, nom court et mots-clés
- produits courants ⭐
- ajout rapide et quantités
- compte rendu copiable
- ajout de produits
- import/export CSV
- version visible dans l'application
- GitHub Actions pour générer l'APK

## CSV
`nom_complet,reference,marque,categorie,nom_court,mots_cles,unite,courant`

## Depuis un téléphone
1. Créer un dépôt GitHub vide `CATAllo`.
2. Décompresser l'archive.
3. Envoyer **tout le contenu du dossier CATAllo** dans le dépôt, y compris `.github/workflows/android.yml`.
4. Dans GitHub : **Actions → Build CAT'Allo APK → Run workflow**.
5. Attendre la fin du workflow.
6. Dans le workflow terminé : **Artifacts → CATAllo-v0.1.0-debug** pour récupérer l'APK.

Le prochain objectif est une vraie base locale persistante, l'édition complète des produits et la signature Release. La clé de signature devra être créée une seule fois et conservée pour toutes les versions futures.
