package fr.catallo.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import java.util.Locale

private val Pink = Color(0xFFE9368B)
private val PinkDark = Color(0xFFB91F69)
private val Ink = Color(0xFF17181C)
private val Soft = Color(0xFFF7F7FA)
private const val VERSION = "0.1.0"

data class Product(val id: Long, val name: String, val reference: String, val brand: String, val category: String, val shortName: String, val keywords: String, val unit: String = "pièce", val common: Boolean = false)
data class SelectedProduct(val product: Product, val quantity: Double = 1.0)

class MainViewModel : ViewModel() {
    var products by mutableStateOf(listOf(
        Product(1,"Bouton poussoir Plexo gris","069681","Legrand","Appareillage","BP Plexo","bp;plexo;poussoir;gris",common=true),
        Product(2,"Support Batibox Mosaïc gris","080251","Legrand","Appareillage","Support Mosaïc gris","support;batibox;mosaique;gris",common=true),
        Product(3,"Ventouse électromagnétique","EF3003","","Contrôle d'accès","Ventouse","ventouse;ef3003",common=true),
        Product(4,"Relais 12 V","REL12V","","Contrôle","Relais 12 V","relais;12v"),
        Product(5,"Câble U1000 R2V 3G1,5","3G1.5","","Câble","Câble 3G1,5","cable;3g1.5;r2v","m",true)
    ))
    var query by mutableStateOf("")
    var selected by mutableStateOf(listOf<SelectedProduct>())
    var showCatalog by mutableStateOf(false)
    var showReport by mutableStateOf(false)
    val filtered: List<Product> get() {
        val q=query.trim().lowercase(Locale.getDefault())
        if(q.isEmpty()) return products.filter { it.common }
        return products.filter { listOf(it.name,it.reference,it.brand,it.category,it.shortName,it.keywords).joinToString(" ").lowercase(Locale.getDefault()).contains(q) }
    }
    fun add(p:Product){ val e=selected.find{it.product.id==p.id}; selected=if(e==null) selected+SelectedProduct(p) else selected.map{if(it.product.id==p.id)it.copy(quantity=it.quantity+1)else it} }
    fun change(p:Product,d:Double){ selected=selected.mapNotNull{if(it.product.id!=p.id)it else {val q=it.quantity+d;if(q<=0)null else it.copy(quantity=q)}} }
    fun toggleCommon(p:Product){products=products.map{if(it.id==p.id)it.copy(common=!p.common)else it}}
    fun addProduct(n:String,r:String,b:String,s:String,k:String){val id=(products.maxOfOrNull{it.id}?:0)+1;products=products+Product(id,n,r,b,"Divers",s.ifBlank{n},k)}
    fun reportText()=buildString{append("Matériel installé :\n\n");selected.forEach{val q=if(it.quantity%1.0==0.0)it.quantity.toInt().toString() else it.quantity.toString();val r=if(it.product.reference.isBlank())"" else " — Réf. ${it.product.reference}";val b=if(it.product.brand.isBlank())"" else " — ${it.product.brand}";append("- $q × ${it.product.name}$r$b\n")}}.trim()
}

class MainActivity:ComponentActivity(){override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{CatAlloApp()}}}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun CatAlloApp(vm:MainViewModel=viewModel()){
    val context=LocalContext.current;var menu by remember{mutableStateOf(false)}
    val exporter=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")){u->if(u!=null)exportCsv(context,u,vm.products)}
    val importer=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){u->if(u!=null)vm.products=importCsv(context,u,vm.products)}
    MaterialTheme(colorScheme=lightColorScheme(primary=Pink,secondary=PinkDark,background=Soft,surface=Color.White,onSurface=Ink)){
        Scaffold(containerColor=Soft,topBar={TopAppBar(colors=TopAppBarDefaults.topAppBarColors(containerColor=Soft),title={},navigationIcon={Image(painterResource(R.drawable.catallo_logo),"CAT'Allo",Modifier.size(46.dp).clip(RoundedCornerShape(12.dp)),ContentScale.Crop)},actions={Box{IconButton({menu=true}){Icon(Icons.Default.MoreVert,"Menu")};DropdownMenu(menu,{menu=false}){
            DropdownMenuItem(text={Text("Gérer le catalogue")}, leadingIcon={Icon(Icons.Default.MoreVert,null)}, onClick={menu=false;vm.showCatalog=true})
            DropdownMenuItem(text={Text("Importer un CSV")}, leadingIcon={Icon(Icons.Default.FileUpload,null)}, onClick={menu=false;importer.launch(arrayOf("text/*","text/csv"))})
            DropdownMenuItem(text={Text("Exporter le catalogue")}, leadingIcon={Icon(Icons.Default.FileDownload,null)}, onClick={menu=false;exporter.launch("catallo_catalogue.csv")})
        }}})},bottomBar={if(vm.selected.isNotEmpty())Surface(shadowElevation=12.dp,tonalElevation=4.dp){Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("Compte rendu",fontWeight=FontWeight.Bold);Text("${vm.selected.size} référence(s) · ${fmt(vm.selected.sumOf{it.quantity})}",style=MaterialTheme.typography.bodySmall)};Button({vm.showReport=true},shape=RoundedCornerShape(14.dp)){Text("Voir")}}}}}){pad->Column(Modifier.fillMaxSize().padding(pad).padding(horizontal=16.dp)){
        Row(Modifier.fillMaxWidth().padding(top=8.dp,bottom=8.dp), verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("CAT’Allo",fontSize=28.sp,fontWeight=FontWeight.ExtraBold,color=Ink);Text("Catalogue · Matériel · Chantiers",color=Color.Gray,fontSize=12.sp)};Surface(color=Color(0xFFFFE4F0),shape=RoundedCornerShape(10.dp)){Text("v$VERSION",color=PinkDark,fontWeight=FontWeight.Bold,Modifier.padding(horizontal=10.dp,vertical=6.dp),fontSize=12.sp)}}
        OutlinedTextField(vm.query,{vm.query=it},Modifier.fillMaxWidth(),placeholder={Text("Rechercher un produit…")},leadingIcon={Icon(Icons.Default.Search,null)},trailingIcon={if(vm.query.isNotEmpty())IconButton({vm.query=""}){Icon(Icons.Default.Close,"Effacer")}},singleLine=true,shape=RoundedCornerShape(16.dp))
        Text(if(vm.query.isBlank())"Produits courants" else "Résultats de recherche",style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold,Modifier.padding(top=18.dp,bottom=10.dp))
        LazyColumn(contentPadding=PaddingValues(bottom=100.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){items(vm.filtered,key={it.id}){p->ProductCard(p,{vm.add(p)},{vm.toggleCommon(p)})};if(vm.query.isNotBlank()&&vm.filtered.isEmpty())item{Surface(Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp),color=Color.White){Column(Modifier.padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally){Text("Aucun produit trouvé",fontWeight=FontWeight.Bold);Text("Nom, référence ou mot-clé…",color=Color.Gray)}}}}
    }}
    if(vm.showCatalog)CatalogDialog(vm)
    if(vm.showReport)ReportDialog(vm,context)
    }
}

@Composable fun ProductCard(p:Product,onAdd:()->Unit,onStar:()->Unit){ElevatedCard(Modifier.fillMaxWidth(),shape=RoundedCornerShape(17.dp)){Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment=Alignment.CenterVertically){Surface(Modifier.size(42.dp),shape=RoundedCornerShape(12.dp),color=Color(0xFFFFE8F2)){Box(contentAlignment=Alignment.Center){Text(p.shortName.take(1).uppercase(),color=PinkDark,fontWeight=FontWeight.ExtraBold)}};Column(Modifier.weight(1f).padding(start=12.dp)){Text(p.shortName,fontWeight=FontWeight.Bold);Text(p.name,style=MaterialTheme.typography.bodySmall,maxLines=1);Text(listOf(p.brand,p.reference).filter{it.isNotBlank()}.joinToString(" · "),style=MaterialTheme.typography.labelSmall,color=Color.Gray)};IconButton(onStar){Icon(if(p.common)Icons.Default.Star else Icons.Outlined.StarBorder,"Produit courant",tint=if(p.common)Pink else Color.Gray)};FilledIconButton(onAdd,colors=IconButtonDefaults.filledIconButtonColors(containerColor=Pink)){Icon(Icons.Default.Add,"Ajouter")}}}}

@Composable fun ReportDialog(vm:MainViewModel,context:Context){AlertDialog(onDismissRequest={vm.showReport=false},title={Text("Matériel installé")},text={LazyColumn(verticalArrangement=Arrangement.spacedBy(4.dp)){items(vm.selected,key={it.product.id}){i->Row(verticalAlignment=Alignment.CenterVertically){IconButton({vm.change(i.product,-1.0)}){Icon(Icons.Default.Remove,"Retirer")};Text("${fmt(i.quantity)} × ${i.product.shortName}",Modifier.weight(1f));IconButton({vm.change(i.product,1.0)}){Icon(Icons.Default.Add,"Ajouter")}}}},confirmButton={Button({val cm=context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager;cm.setPrimaryClip(ClipData.newPlainText("CAT'Allo",vm.reportText()));vm.showReport=false}){Text("Copier")}},dismissButton={TextButton({vm.selected=emptyList();vm.showReport=false}){Text("Vider")}})}

@Composable fun CatalogDialog(vm:MainViewModel){var n by remember{mutableStateOf("")};var r by remember{mutableStateOf("")};var b by remember{mutableStateOf("")};var s by remember{mutableStateOf("")};var k by remember{mutableStateOf("")};AlertDialog(onDismissRequest={vm.showCatalog=false},title={Text("Catalogue")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Text("Ajoute une référence à ton catalogue.",color=Color.Gray);OutlinedTextField(n,{n=it},label={Text("Nom complet")},singleLine=true);OutlinedTextField(r,{r=it},label={Text("Référence")},singleLine=true);OutlinedTextField(b,{b=it},label={Text("Marque")},singleLine=true);OutlinedTextField(s,{s=it},label={Text("Nom court")},singleLine=true);OutlinedTextField(k,{k=it},label={Text("Mots-clés séparés par ;")})}},confirmButton={Button(enabled=n.isNotBlank(), onClick={vm.addProduct(n,r,b,s,k);n="";r="";b="";s="";k=""}){Text("Ajouter")}},dismissButton={TextButton({vm.showCatalog=false}){Text("Fermer")}})}

fun fmt(q:Double)=if(q%1.0==0.0)q.toInt().toString() else String.format(Locale.getDefault(),"%.2f",q)
fun esc(s:String)="\"${s.replace("\"","\"\"")}\""
fun exportCsv(c:Context,u:Uri,ps:List<Product>){val x=buildString{appendLine("nom_complet,reference,marque,categorie,nom_court,mots_cles,unite,courant");ps.forEach{p->appendLine(listOf(p.name,p.reference,p.brand,p.category,p.shortName,p.keywords,p.unit,if(p.common)"1"else"0").joinToString(",",transform=::esc))}};c.contentResolver.openOutputStream(u)?.bufferedWriter()?.use{it.write(x)}}
fun importCsv(c:Context,u:Uri,current:List<Product>):List<Product>{return try{val lines=c.contentResolver.openInputStream(u)?.bufferedReader()?.readLines().orEmpty().drop(1);var id=(current.maxOfOrNull{it.id}?:0)+1;val imp=lines.mapNotNull{line->val a=parse(line);if(a.size<8||a[0].isBlank())null else Product(id++,a[0],a[1],a[2],a[3],a[4].ifBlank{a[0]},a[5],a[6].ifBlank{"pièce"},a[7]=="1")};if(imp.isEmpty())current else imp}catch(_:Exception){current}}
fun parse(line:String):List<String>{val r=mutableListOf<String>();val s=StringBuilder();var q=false;var i=0;while(i<line.length){val c=line[i];if(c=='"'){if(q&&i+1<line.length&&line[i+1]=='"'){s.append('"');i++}else q=!q}else if(c==','&&!q){r+=s.toString();s.clear()}else s.append(c);i++};r+=s.toString();return r}
